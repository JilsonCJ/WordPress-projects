<?php
/**
 * Plugin Name: WP Attack Shield
 * Plugin URI: https://example.com/wp-attack-shield
 * Description: Hardens WordPress against common attacks with upload protection, login throttling, request filtering, security headers, data-leak reduction, and malware scanning.
 * Version: 1.0.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author: Codex
 * License: GPL-2.0-or-later
 * Text Domain: wp-attack-shield
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('DISALLOW_FILE_EDIT')) {
    define('DISALLOW_FILE_EDIT', true);
}

final class WPAS_WP_Attack_Shield
{
    private const VERSION = '1.0.0';
    private const OPTION = 'wpas_settings';
    private const EVENTS = 'wpas_events';
    private const SCAN_RESULTS = 'wpas_scan_results';
    private const HASHES = 'wpas_file_hashes';
    private const NONCE_SCAN = 'wpas_run_scan';

    private static ?self $instance = null;
    private array $settings = [];

    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct()
    {
        $this->settings = wp_parse_args((array) get_option(self::OPTION, []), self::defaults());

        register_activation_hook(__FILE__, [__CLASS__, 'activate']);
        register_deactivation_hook(__FILE__, [__CLASS__, 'deactivate']);

        add_action('admin_menu', [$this, 'add_admin_page']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_post_wpas_run_scan', [$this, 'handle_run_scan']);
        add_action('wpas_daily_scan', [$this, 'run_scan']);

        if ($this->enabled('request_firewall')) {
            add_action('init', [$this, 'request_firewall'], 0);
        }

        if ($this->enabled('upload_guard')) {
            add_filter('wp_handle_upload_prefilter', [$this, 'protect_uploads']);
            add_filter('upload_mimes', [$this, 'restrict_upload_mimes']);
        }

        if ($this->enabled('login_guard')) {
            add_filter('authenticate', [$this, 'block_throttled_login'], 1, 3);
            add_action('wp_login_failed', [$this, 'record_failed_login']);
            add_action('wp_login', [$this, 'clear_login_failures'], 10, 2);
        }

        if ($this->enabled('xmlrpc_guard')) {
            add_filter('xmlrpc_enabled', '__return_false');
            add_filter('xmlrpc_methods', [$this, 'remove_xmlrpc_methods']);
            add_filter('wp_headers', [$this, 'remove_pingback_header']);
        }

        if ($this->enabled('privacy_guard')) {
            add_action('template_redirect', [$this, 'block_author_enumeration'], 0);
            add_filter('rest_endpoints', [$this, 'hide_public_user_rest_routes']);
            add_filter('the_generator', '__return_empty_string');
            remove_action('wp_head', 'wp_generator');
        }

        if ($this->enabled('security_headers')) {
            add_action('send_headers', [$this, 'send_security_headers']);
        }
    }

    public static function defaults(): array
    {
        return [
            'request_firewall' => 1,
            'upload_guard' => 1,
            'login_guard' => 1,
            'xmlrpc_guard' => 1,
            'privacy_guard' => 1,
            'security_headers' => 1,
            'daily_scan' => 1,
            'max_login_failures' => 5,
            'lockout_minutes' => 20,
            'blocked_upload_extensions' => 'php,phtml,phar,php3,php4,php5,php7,php8,inc,sh,cgi,pl,py,asp,aspx,jsp,exe,dll,bat,cmd,com,scr,jar,svg',
        ];
    }

    public static function activate(): void
    {
        if (!get_option(self::OPTION)) {
            add_option(self::OPTION, self::defaults());
        }

        self::write_uploads_protection_files();
        if (!wp_next_scheduled('wpas_daily_scan')) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'wpas_daily_scan');
        }
    }

    public static function deactivate(): void
    {
        wp_clear_scheduled_hook('wpas_daily_scan');
    }

    public function add_admin_page(): void
    {
        add_options_page(
            __('WP Attack Shield', 'wp-attack-shield'),
            __('WP Attack Shield', 'wp-attack-shield'),
            'manage_options',
            'wpas-settings',
            [$this, 'render_admin_page']
        );
    }

    public function register_settings(): void
    {
        register_setting('wpas_settings_group', self::OPTION, [
            'type' => 'array',
            'sanitize_callback' => [$this, 'sanitize_settings'],
            'default' => self::defaults(),
        ]);
    }

    public function sanitize_settings(array $input): array
    {
        $defaults = self::defaults();

        if (!empty($input['daily_scan']) && !wp_next_scheduled('wpas_daily_scan')) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'wpas_daily_scan');
        }

        if (empty($input['daily_scan'])) {
            wp_clear_scheduled_hook('wpas_daily_scan');
        }

        return [
            'request_firewall' => empty($input['request_firewall']) ? 0 : 1,
            'upload_guard' => empty($input['upload_guard']) ? 0 : 1,
            'login_guard' => empty($input['login_guard']) ? 0 : 1,
            'xmlrpc_guard' => empty($input['xmlrpc_guard']) ? 0 : 1,
            'privacy_guard' => empty($input['privacy_guard']) ? 0 : 1,
            'security_headers' => empty($input['security_headers']) ? 0 : 1,
            'daily_scan' => empty($input['daily_scan']) ? 0 : 1,
            'max_login_failures' => max(2, min(20, absint($input['max_login_failures'] ?? $defaults['max_login_failures']))),
            'lockout_minutes' => max(5, min(1440, absint($input['lockout_minutes'] ?? $defaults['lockout_minutes']))),
            'blocked_upload_extensions' => sanitize_text_field($input['blocked_upload_extensions'] ?? $defaults['blocked_upload_extensions']),
        ];
    }

    public function render_admin_page(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $settings = wp_parse_args((array) get_option(self::OPTION, []), self::defaults());
        $results = (array) get_option(self::SCAN_RESULTS, []);
        $events = array_slice((array) get_option(self::EVENTS, []), 0, 12);
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('WP Attack Shield', 'wp-attack-shield'); ?></h1>
            <p><?php esc_html_e('Hardens common WordPress attack surfaces. Use it with updates, backups, strong passwords, HTTPS, and reputable hosting.', 'wp-attack-shield'); ?></p>

            <form method="post" action="options.php">
                <?php settings_fields('wpas_settings_group'); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php esc_html_e('Protection modules', 'wp-attack-shield'); ?></th>
                        <td>
                            <?php $this->checkbox('request_firewall', __('Request firewall for common exploit payloads', 'wp-attack-shield'), $settings); ?><br>
                            <?php $this->checkbox('upload_guard', __('Upload guard for executable and suspicious files', 'wp-attack-shield'), $settings); ?><br>
                            <?php $this->checkbox('login_guard', __('Login throttling against brute-force attempts', 'wp-attack-shield'), $settings); ?><br>
                            <?php $this->checkbox('xmlrpc_guard', __('Disable XML-RPC and pingback exposure', 'wp-attack-shield'), $settings); ?><br>
                            <?php $this->checkbox('privacy_guard', __('Reduce user/version data leakage', 'wp-attack-shield'), $settings); ?><br>
                            <?php $this->checkbox('security_headers', __('Send browser security headers', 'wp-attack-shield'), $settings); ?><br>
                            <?php $this->checkbox('daily_scan', __('Run daily malware and file-change scan', 'wp-attack-shield'), $settings); ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="wpas-max-login-failures"><?php esc_html_e('Login failures before lockout', 'wp-attack-shield'); ?></label></th>
                        <td>
                            <input id="wpas-max-login-failures" type="number" min="2" max="20" name="<?php echo esc_attr(self::OPTION); ?>[max_login_failures]" value="<?php echo esc_attr($settings['max_login_failures']); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="wpas-lockout-minutes"><?php esc_html_e('Lockout minutes', 'wp-attack-shield'); ?></label></th>
                        <td>
                            <input id="wpas-lockout-minutes" type="number" min="5" max="1440" name="<?php echo esc_attr(self::OPTION); ?>[lockout_minutes]" value="<?php echo esc_attr($settings['lockout_minutes']); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="wpas-blocked-ext"><?php esc_html_e('Blocked upload extensions', 'wp-attack-shield'); ?></label></th>
                        <td>
                            <input id="wpas-blocked-ext" class="regular-text" type="text" name="<?php echo esc_attr(self::OPTION); ?>[blocked_upload_extensions]" value="<?php echo esc_attr($settings['blocked_upload_extensions']); ?>">
                            <p class="description"><?php esc_html_e('Comma-separated. SVG is blocked by default because it can contain scriptable content.', 'wp-attack-shield'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>

            <hr>
            <h2><?php esc_html_e('Security scan', 'wp-attack-shield'); ?></h2>
            <p><?php echo esc_html($this->scan_summary($results)); ?></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="wpas_run_scan">
                <?php wp_nonce_field(self::NONCE_SCAN); ?>
                <?php submit_button(__('Run scan now', 'wp-attack-shield'), 'secondary'); ?>
            </form>

            <?php if (!empty($results['findings'])) : ?>
                <table class="widefat striped">
                    <thead><tr><th><?php esc_html_e('Type', 'wp-attack-shield'); ?></th><th><?php esc_html_e('File', 'wp-attack-shield'); ?></th><th><?php esc_html_e('Details', 'wp-attack-shield'); ?></th></tr></thead>
                    <tbody>
                    <?php foreach (array_slice((array) $results['findings'], 0, 50) as $finding) : ?>
                        <tr>
                            <td><?php echo esc_html($finding['type'] ?? ''); ?></td>
                            <td><code><?php echo esc_html($finding['file'] ?? ''); ?></code></td>
                            <td><?php echo esc_html($finding['detail'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <h2><?php esc_html_e('Recent blocked events', 'wp-attack-shield'); ?></h2>
            <?php if (empty($events)) : ?>
                <p><?php esc_html_e('No blocked events recorded yet.', 'wp-attack-shield'); ?></p>
            <?php else : ?>
                <table class="widefat striped">
                    <thead><tr><th><?php esc_html_e('When', 'wp-attack-shield'); ?></th><th><?php esc_html_e('Type', 'wp-attack-shield'); ?></th><th><?php esc_html_e('IP', 'wp-attack-shield'); ?></th><th><?php esc_html_e('Details', 'wp-attack-shield'); ?></th></tr></thead>
                    <tbody>
                    <?php foreach ($events as $event) : ?>
                        <tr>
                            <td><?php echo esc_html($event['time'] ?? ''); ?></td>
                            <td><?php echo esc_html($event['type'] ?? ''); ?></td>
                            <td><?php echo esc_html($event['ip'] ?? ''); ?></td>
                            <td><?php echo esc_html($event['detail'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
    }

    private function checkbox(string $key, string $label, array $settings): void
    {
        ?>
        <label>
            <input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[<?php echo esc_attr($key); ?>]" value="1" <?php checked($settings[$key] ?? 0, 1); ?>>
            <?php echo esc_html($label); ?>
        </label>
        <?php
    }

    public function request_firewall(): void
    {
        if (is_admin() || wp_doing_ajax() || wp_doing_cron()) {
            return;
        }

        $haystack = strtolower(
            wp_unslash(($_SERVER['REQUEST_URI'] ?? '') . ' ' . ($_SERVER['QUERY_STRING'] ?? '') . ' ' . ($_SERVER['HTTP_USER_AGENT'] ?? ''))
        );

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $post_sample = substr(wp_json_encode(wp_unslash($_POST)), 0, 8000);
            $haystack .= ' ' . strtolower((string) $post_sample);
        }

        $patterns = [
            '/\.\.\//',
            '/wp-config\.php/',
            '/(?:union(?:\s|%20)+select|information_schema|sleep\s*\(|benchmark\s*\()/',
            '/(?:<script|javascript:|onerror\s*=|onload\s*=)/',
            '/(?:base64_decode|gzinflate|shell_exec|passthru|proc_open|popen|assert\s*\(|eval\s*\()/',
            '/(?:php:\/\/input|data:\/\/|expect:\/\/|file:\/\/)/',
            '/(?:\/etc\/passwd|cmd\.exe|powershell)/',
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $haystack)) {
                $this->log_event('request_blocked', 'Matched firewall pattern: ' . $pattern);
                status_header(403);
                exit('Forbidden');
            }
        }
    }

    public function protect_uploads(array $file): array
    {
        $name = (string) ($file['name'] ?? '');
        $tmp = (string) ($file['tmp_name'] ?? '');
        $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $blocked = $this->blocked_extensions();

        if ($extension && in_array($extension, $blocked, true)) {
            $file['error'] = __('This file type is blocked by WP Attack Shield.', 'wp-attack-shield');
            $this->log_event('upload_blocked', 'Blocked extension: ' . $extension . ' in ' . $name);
            return $file;
        }

        if (preg_match('/\.(php|phtml|phar|inc)\./i', $name)) {
            $file['error'] = __('Suspicious double-extension upload blocked.', 'wp-attack-shield');
            $this->log_event('upload_blocked', 'Double extension: ' . $name);
            return $file;
        }

        if (is_readable($tmp)) {
            $sample = file_get_contents($tmp, false, null, 0, 4096);
            if (is_string($sample) && preg_match('/<\?(php|=)|<script\b|base64_decode\s*\(|eval\s*\(/i', $sample)) {
                $file['error'] = __('Suspicious file content blocked.', 'wp-attack-shield');
                $this->log_event('upload_blocked', 'Suspicious content: ' . $name);
            }
        }

        return $file;
    }

    public function restrict_upload_mimes(array $mimes): array
    {
        foreach ($this->blocked_extensions() as $extension) {
            unset($mimes[$extension]);
        }

        return $mimes;
    }

    public function block_throttled_login($user, string $username, string $password)
    {
        $key = $this->login_key($username);
        $failures = (int) get_transient($key);

        if ($failures >= (int) $this->settings['max_login_failures']) {
            $this->log_event('login_blocked', 'Locked out username: ' . $username);
            return new WP_Error('wpas_locked', __('Too many failed login attempts. Please try again later.', 'wp-attack-shield'));
        }

        return $user;
    }

    public function record_failed_login(string $username): void
    {
        $key = $this->login_key($username);
        $failures = (int) get_transient($key);
        $ttl = (int) $this->settings['lockout_minutes'] * MINUTE_IN_SECONDS;
        set_transient($key, $failures + 1, $ttl);
        $this->log_event('login_failed', 'Failed login for username: ' . $username);
    }

    public function clear_login_failures(string $user_login, WP_User $user): void
    {
        delete_transient($this->login_key($user_login));
    }

    public function remove_xmlrpc_methods(array $methods): array
    {
        unset($methods['pingback.ping'], $methods['system.multicall']);
        return $methods;
    }

    public function remove_pingback_header(array $headers): array
    {
        unset($headers['X-Pingback']);
        return $headers;
    }

    public function block_author_enumeration(): void
    {
        if (!is_admin() && isset($_GET['author']) && !is_user_logged_in()) {
            $this->log_event('author_enum_blocked', 'Blocked ?author scan');
            status_header(403);
            exit('Forbidden');
        }
    }

    public function hide_public_user_rest_routes(array $endpoints): array
    {
        if (!is_user_logged_in()) {
            unset($endpoints['/wp/v2/users'], $endpoints['/wp/v2/users/(?P<id>[\d]+)']);
        }

        return $endpoints;
    }

    public function send_security_headers(): void
    {
        if (headers_sent()) {
            return;
        }

        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Permissions-Policy: geolocation=(), microphone=(), camera=()');

        if (is_ssl()) {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        }
    }

    public function handle_run_scan(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to run scans.', 'wp-attack-shield'));
        }

        check_admin_referer(self::NONCE_SCAN);
        $this->run_scan();
        wp_safe_redirect(wp_get_referer() ?: admin_url('options-general.php?page=wpas-settings'));
        exit;
    }

    public function run_scan(): void
    {
        $roots = array_filter([
            WP_CONTENT_DIR . '/uploads',
            WP_CONTENT_DIR . '/plugins',
            get_theme_root(),
        ], 'is_dir');

        $old_hashes = (array) get_option(self::HASHES, []);
        $new_hashes = [];
        $findings = [];
        $max_files = 2500;
        $scanned = 0;

        foreach ($roots as $root) {
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)
            );

            foreach ($iterator as $file) {
                if ($scanned >= $max_files || !$file->isFile()) {
                    continue;
                }

                $path = $file->getPathname();
                $relative = wp_normalize_path(str_replace(ABSPATH, '', $path));
                $extension = strtolower($file->getExtension());

                if ($file->getSize() > 2 * MB_IN_BYTES) {
                    continue;
                }

                $scanned++;
                $hash = md5_file($path);
                $new_hashes[$relative] = $hash;

                if (isset($old_hashes[$relative]) && $old_hashes[$relative] !== $hash) {
                    $findings[] = [
                        'type' => 'changed',
                        'file' => $relative,
                        'detail' => __('File changed since previous scan.', 'wp-attack-shield'),
                    ];
                }

                if ($this->is_executable_in_uploads($path, $extension)) {
                    $findings[] = [
                        'type' => 'dangerous_upload',
                        'file' => $relative,
                        'detail' => __('Executable file found inside uploads.', 'wp-attack-shield'),
                    ];
                }

                if (in_array($extension, ['php', 'phtml', 'phar', 'inc', 'js', 'html', 'htm'], true)) {
                    $sample = file_get_contents($path, false, null, 0, 120000);
                    if (is_string($sample) && $this->looks_suspicious($sample)) {
                        $findings[] = [
                            'type' => 'suspicious_code',
                            'file' => $relative,
                            'detail' => __('Potential malware or obfuscated code pattern found. Review manually before deleting.', 'wp-attack-shield'),
                        ];
                    }
                }
            }
        }

        update_option(self::HASHES, $new_hashes, false);
        update_option(self::SCAN_RESULTS, [
            'time' => current_time('mysql'),
            'scanned' => $scanned,
            'findings' => $findings,
            'limited' => $scanned >= $max_files,
        ], false);
    }

    private function looks_suspicious(string $content): bool
    {
        $patterns = [
            '/eval\s*\(\s*(base64_decode|gzinflate|str_rot13|gzuncompress)/i',
            '/(?:shell_exec|passthru|proc_open|popen|system)\s*\(/i',
            '/preg_replace\s*\(.+\/e[\'"]\s*,/is',
            '/(?:c99shell|r57shell|FilesMan|WSOsetcookie|b374k)/i',
            '/\$\w+\s*=\s*[\'"][A-Za-z0-9+\/]{300,}={0,2}[\'"]/',
            '/assert\s*\(\s*\$_(?:POST|GET|REQUEST|COOKIE)/i',
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $content)) {
                return true;
            }
        }

        return false;
    }

    private function scan_summary(array $results): string
    {
        if (empty($results)) {
            return __('No scan has been run yet.', 'wp-attack-shield');
        }

        $count = count((array) ($results['findings'] ?? []));
        $scanned = absint($results['scanned'] ?? 0);
        $time = sanitize_text_field($results['time'] ?? '');

        return sprintf(
            /* translators: 1: file count, 2: finding count, 3: scan time */
            __('Last scan checked %1$d files and found %2$d item(s) at %3$s.', 'wp-attack-shield'),
            $scanned,
            $count,
            $time
        );
    }

    private function is_executable_in_uploads(string $path, string $extension): bool
    {
        $uploads = wp_get_upload_dir();
        $uploads_dir = wp_normalize_path($uploads['basedir'] ?? '');
        $normalized = wp_normalize_path($path);

        return $uploads_dir && strpos($normalized, $uploads_dir) === 0 && in_array($extension, ['php', 'phtml', 'phar', 'inc', 'cgi', 'pl', 'py', 'sh'], true);
    }

    private function blocked_extensions(): array
    {
        $items = explode(',', (string) $this->settings['blocked_upload_extensions']);
        return array_values(array_filter(array_map(static function (string $extension): string {
            return strtolower(ltrim(trim($extension), '.'));
        }, $items)));
    }

    private function login_key(string $username): string
    {
        return 'wpas_login_' . md5(strtolower($username) . '|' . $this->client_ip());
    }

    private function client_ip(): string
    {
        return sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    }

    private function log_event(string $type, string $detail): void
    {
        $events = (array) get_option(self::EVENTS, []);
        array_unshift($events, [
            'time' => current_time('mysql'),
            'type' => sanitize_key($type),
            'ip' => $this->client_ip(),
            'detail' => sanitize_text_field($detail),
        ]);

        update_option(self::EVENTS, array_slice($events, 0, 100), false);
    }

    private function enabled(string $key): bool
    {
        return !empty($this->settings[$key]);
    }

    private static function write_uploads_protection_files(): void
    {
        $uploads = wp_get_upload_dir();
        $directory = $uploads['basedir'] ?? '';

        if (!$directory || !is_dir($directory) || !is_writable($directory)) {
            return;
        }

        $htaccess = trailingslashit($directory) . '.htaccess';
        $htaccess_rules = "# WP Attack Shield\n<FilesMatch \"\\.(php|phtml|phar|php[0-9]?|inc|cgi|pl|py|sh)$\">\n    Require all denied\n</FilesMatch>\nOptions -Indexes\n";

        if (!file_exists($htaccess) || strpos((string) file_get_contents($htaccess), 'WP Attack Shield') === false) {
            file_put_contents($htaccess, "\n" . $htaccess_rules, FILE_APPEND | LOCK_EX);
        }

        $web_config = trailingslashit($directory) . 'web.config';
        $web_config_rules = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<configuration><system.webServer><handlers><remove name=\"PHP_via_FastCGI\" /></handlers><security><requestFiltering><fileExtensions><add fileExtension=\".php\" allowed=\"false\" /><add fileExtension=\".phtml\" allowed=\"false\" /><add fileExtension=\".phar\" allowed=\"false\" /></fileExtensions></requestFiltering></security></system.webServer></configuration>\n";

        if (!file_exists($web_config)) {
            file_put_contents($web_config, $web_config_rules, LOCK_EX);
        }

        $index = trailingslashit($directory) . 'index.html';
        if (!file_exists($index)) {
            file_put_contents($index, '', LOCK_EX);
        }
    }
}

WPAS_WP_Attack_Shield::instance();
