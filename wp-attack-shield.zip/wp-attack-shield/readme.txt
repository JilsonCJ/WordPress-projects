=== WP Attack Shield ===
Contributors: codex
Tags: security, firewall, malware, upload protection, brute force
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later

WP Attack Shield hardens WordPress against common attacks with upload protection, login throttling, request filtering, security headers, data-leak reduction, and malware scanning.

== Description ==

No WordPress plugin can promise complete security against every attack. A real security setup also needs trusted hosting, HTTPS, strong passwords, least-privilege user roles, regular updates, offsite backups, and monitoring.

This plugin reduces common attack surfaces that affect WordPress sites:

* Brute-force login attempts.
* Malicious uploads such as PHP shells, double extensions, executable files, and scriptable SVG.
* Malware patterns such as obfuscated PHP, base64/eval loaders, and shell command functions.
* Suspicious exploit requests including traversal, SQL injection, XSS strings, stream wrappers, and probes for config files.
* XML-RPC and pingback abuse.
* Public author/user enumeration.
* WordPress version leakage.
* Browser-side risk from missing common security headers.
* PHP execution inside uploads on Apache/IIS where server rules are honored.
* Unexpected changes in plugin, theme, and upload files.

== Features ==

* Lightweight request firewall.
* Upload prefilter that blocks dangerous file extensions and suspicious file content.
* Login lockout after repeated failed attempts by username and IP.
* XML-RPC disabled by default.
* Public REST user routes hidden from logged-out visitors.
* Author enumeration blocked for anonymous visitors.
* WordPress generator/version output removed.
* `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`, and HTTPS-only HSTS headers.
* Uploads folder hardening with `.htaccess`, `web.config`, and `index.html` where writable.
* Admin scan tool and daily scheduled scan.
* Recent blocked event log in Settings > WP Attack Shield.

== Installation ==

1. Upload the `wp-attack-shield` folder to `/wp-content/plugins/`, or upload the ZIP from WordPress Admin > Plugins > Add New > Upload Plugin.
2. Activate WP Attack Shield.
3. Go to Settings > WP Attack Shield.
4. Keep protection modules enabled unless a specific site feature needs an exception.
5. Run the first scan and review any findings manually.

== How It Works ==

Request firewall:
The plugin checks public requests for common attack strings such as path traversal, SQL injection probes, XSS payloads, stream wrappers, attempts to read `wp-config.php`, and obvious PHP command execution payloads. Matching requests receive a 403 response.

Upload guard:
The plugin blocks executable extensions, double-extension tricks, scriptable SVG uploads, and files whose first bytes contain suspicious PHP or JavaScript patterns.

Login guard:
The plugin counts failed login attempts for each username and IP combination. After the configured threshold, it temporarily blocks further login attempts.

Data leakage guard:
The plugin hides public user REST endpoints from logged-out visitors, blocks `?author=` scans, removes the generator/version tag, and removes the pingback header.

XML-RPC guard:
The plugin disables XML-RPC and removes pingback/multicall methods to reduce remote abuse and amplification attacks.

Security headers:
The plugin sends common browser hardening headers. HSTS is sent only on HTTPS.

Malware and file-change scanner:
The plugin scans uploads, plugins, and themes for suspicious code patterns, executable files inside uploads, and files that changed since the previous scan. Findings are reported in the admin page; the plugin does not delete files automatically because false positives are possible.

Uploads folder protection:
On activation, the plugin tries to add server rules that deny executable scripts inside uploads. This works only when the web server honors `.htaccess` or `web.config` rules.

== Important Limitations ==

* It cannot patch vulnerable themes, plugins, hosting, PHP, or WordPress core.
* It cannot clean every malware infection automatically.
* It cannot stop attacks that happen before WordPress loads.
* It cannot replace a WAF/CDN, backups, server file permissions, and update discipline.
* Review scan results before deleting any file.

== Changelog ==

= 1.0.0 =
Initial release.
