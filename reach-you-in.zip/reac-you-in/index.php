<?php get_header(); ?>
<?php ryi_page_hero(is_home() ? 'Digital Marketing Blogs' : get_bloginfo('name'), 'Insights on digital marketing, social media, influencer campaigns, advertising, design, and technology.', 'Blogs'); ?>
<section class="section">
    <div class="container cards-grid">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <article class="service-card reveal">
                <?php if (has_post_thumbnail()) : ?><a class="case-thumb" href="<?php the_permalink(); ?>"><?php the_post_thumbnail('medium_large'); ?></a><?php endif; ?>
                <p class="eyebrow"><?php echo esc_html(get_the_date()); ?></p>
                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                <p><?php echo esc_html(get_the_excerpt() ?: wp_trim_words(get_the_content(), 26)); ?></p>
                <a href="<?php the_permalink(); ?>">Read More -></a>
            </article>
        <?php endwhile; else : ?>
            <article class="service-card reveal"><h2>No posts yet.</h2><p>Add blog posts from Posts in the WordPress dashboard.</p></article>
        <?php endif; ?>
    </div>
    <div class="container pagination-wrap"><?php the_posts_pagination(); ?></div>
</section>
<?php get_footer(); ?>
