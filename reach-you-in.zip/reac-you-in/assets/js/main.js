(function(){
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.querySelector('.site-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function(){
      var open = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!open));
      nav.classList.toggle('is-open', !open);
      document.body.classList.toggle('nav-open', !open);
    });
  }

  var revealItems = document.querySelectorAll('.reveal, .service-card, .case-card, .benefit, details');
  if ('IntersectionObserver' in window) {
    var observer = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, {threshold: 0.12});
    revealItems.forEach(function(item){ observer.observe(item); });
  } else {
    revealItems.forEach(function(item){ item.classList.add('is-visible'); });
  }

  document.querySelectorAll('.service-card, .case-card, .benefit').forEach(function(card){
    card.addEventListener('pointermove', function(event){
      var rect = card.getBoundingClientRect();
      card.style.setProperty('--mx', ((event.clientX - rect.left) / rect.width * 100).toFixed(1) + '%');
      card.style.setProperty('--my', ((event.clientY - rect.top) / rect.height * 100).toFixed(1) + '%');
    });
  });

  document.querySelectorAll('.client-slider.has-many').forEach(function(slider){
    var track = slider.querySelector('.client-track');
    if (!track || track.dataset.ready === 'true') {
      return;
    }
    var slides = Array.prototype.slice.call(track.querySelectorAll('.client-slide'));
    if (slides.length < 2) {
      return;
    }
    track.dataset.ready = 'true';
    track.style.transition = 'transform 900ms cubic-bezier(.77,0,.18,1)';
    var realCount = slides.length;
    var index = 0;
    setInterval(function(){
      index = (index + 1) % realCount;
      track.style.transform = 'translateX(-' + (index * 100) + '%)';
    }, 3600);
  });
})();
