(function($){
  $('.ryi-upload').on('click', function(){
    var field = $(this).closest('.ryi-media-field');
    var frame = wp.media({title:'Choose media', button:{text:'Use this media'}, multiple:false});
    frame.on('select', function(){
      var attachment = frame.state().get('selection').first().toJSON();
      field.find('.ryi-media-id').val(attachment.id);
      field.find('.ryi-media-preview').html('<img src="'+attachment.url+'" alt="">');
    });
    frame.open();
  });
  $('.ryi-clear').on('click', function(){
    var field = $(this).closest('.ryi-media-field');
    field.find('.ryi-media-id').val('');
    field.find('.ryi-media-preview').empty();
  });
})(jQuery);
