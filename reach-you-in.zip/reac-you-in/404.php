<?php get_header(); ryi_page_hero('Page Not Found', 'The page you are looking for may have moved.', '404'); ?>
<section class="section"><div class="container reveal"><?php echo ryi_button('Go Home', home_url('/')); ?></div></section>
<?php get_footer(); ?>
