<?php
/**
 * Reac you in theme bootstrap.
 *
 * @package ReacYouIn
 */

if (!defined('ABSPATH')) {
    exit;
}

define('RYI_VERSION', '1.0.0');
define('RYI_DIR', get_template_directory());
define('RYI_URI', get_template_directory_uri());

require_once RYI_DIR . '/inc/helpers.php';
require_once RYI_DIR . '/inc/admin.php';
require_once RYI_DIR . '/inc/content.php';

function ryi_setup_theme() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height' => 90,
        'width' => 260,
        'flex-height' => true,
        'flex-width' => true,
    ));
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
    add_theme_support('automatic-feed-links');

    register_nav_menus(array(
        'primary' => __('Primary Navigation', 'reac-you-in'),
        'footer' => __('Footer Navigation', 'reac-you-in'),
    ));
}
add_action('after_setup_theme', 'ryi_setup_theme');

function ryi_enqueue_assets() {
    wp_enqueue_style('ryi-main', RYI_URI . '/assets/css/main.css', array(), RYI_VERSION);
    wp_enqueue_style('ryi-corrections', RYI_URI . '/assets/css/corrections.css', array('ryi-main'), RYI_VERSION);
    wp_enqueue_script('ryi-main', RYI_URI . '/assets/js/main.js', array(), RYI_VERSION, true);
}
add_action('wp_enqueue_scripts', 'ryi_enqueue_assets');

function ryi_admin_assets($hook) {
    if ($hook !== 'toplevel_page_ryi-settings') {
        return;
    }
    wp_enqueue_media();
    wp_enqueue_style('ryi-admin', RYI_URI . '/assets/css/admin.css', array(), RYI_VERSION);
    wp_enqueue_script('ryi-admin', RYI_URI . '/assets/js/admin.js', array('jquery'), RYI_VERSION, true);
}
add_action('admin_enqueue_scripts', 'ryi_admin_assets');

function ryi_register_post_types() {
    register_post_type('ryi_case', array(
        'labels' => array(
            'name' => __('Case Studies', 'reac-you-in'),
            'singular_name' => __('Case Study', 'reac-you-in'),
            'add_new_item' => __('Add New Case Study Video', 'reac-you-in'),
            'edit_item' => __('Edit Case Study', 'reac-you-in'),
        ),
        'public' => true,
        'menu_icon' => 'dashicons-video-alt3',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'has_archive' => true,
        'rewrite' => array('slug' => 'case-study'),
        'show_in_rest' => true,
    ));

    register_post_type('ryi_job', array(
        'labels' => array(
            'name' => __('Careers / Vacancies', 'reac-you-in'),
            'singular_name' => __('Job Vacancy', 'reac-you-in'),
            'add_new_item' => __('Post New Job Vacancy', 'reac-you-in'),
            'edit_item' => __('Edit Job Vacancy', 'reac-you-in'),
        ),
        'public' => true,
        'menu_icon' => 'dashicons-businessperson',
        'supports' => array('title', 'editor', 'excerpt'),
        'has_archive' => true,
        'rewrite' => array('slug' => 'careers-openings'),
        'show_in_rest' => true,
    ));

    register_post_type('ryi_client', array(
        'labels' => array(
            'name' => __('Client Logos', 'reac-you-in'),
            'singular_name' => __('Client Logo', 'reac-you-in'),
            'add_new_item' => __('Upload New Client Logo', 'reac-you-in'),
            'edit_item' => __('Edit Client Logo', 'reac-you-in'),
        ),
        'public' => true,
        'menu_icon' => 'dashicons-images-alt2',
        'supports' => array('title', 'thumbnail', 'page-attributes'),
        'has_archive' => false,
        'rewrite' => array('slug' => 'clients'),
        'show_in_rest' => true,
    ));
}
add_action('init', 'ryi_register_post_types');

function ryi_add_meta_boxes() {
    add_meta_box('ryi_case_video', __('Case Study Video', 'reac-you-in'), 'ryi_case_video_meta_box', 'ryi_case', 'normal', 'high');
    add_meta_box('ryi_job_details', __('Job Details', 'reac-you-in'), 'ryi_job_details_meta_box', 'ryi_job', 'normal', 'high');
}
add_action('add_meta_boxes', 'ryi_add_meta_boxes');

function ryi_case_video_meta_box($post) {
    wp_nonce_field('ryi_save_case_video', 'ryi_case_video_nonce');
    $video = get_post_meta($post->ID, '_ryi_video_url', true);
    $label = get_post_meta($post->ID, '_ryi_case_label', true);
    $views = get_post_meta($post->ID, '_ryi_video_views', true);
    ?>
    <p><label for="ryi_case_label"><strong><?php esc_html_e('Case Study Label', 'reac-you-in'); ?></strong></label></p>
    <input class="widefat" type="text" name="ryi_case_label" id="ryi_case_label" value="<?php echo esc_attr($label); ?>" placeholder="Brand Visibility, Social Media, Paid Advertising">
    <p><label for="ryi_video_url"><strong><?php esc_html_e('Video URL', 'reac-you-in'); ?></strong></label></p>
    <input class="widefat" type="url" name="ryi_video_url" id="ryi_video_url" value="<?php echo esc_url($video); ?>" placeholder="https://www.youtube.com/watch?v=...">
    <p><label for="ryi_video_views"><strong><?php esc_html_e('Video Views', 'reac-you-in'); ?></strong></label></p>
    <input class="widefat" type="text" name="ryi_video_views" id="ryi_video_views" value="<?php echo esc_attr($views); ?>" placeholder="1.2M views / 85K views / 12,450 views">
    <p class="description"><?php esc_html_e('Use the featured image as the video preview thumbnail. Add YouTube, Instagram, Facebook, or direct video URL here.', 'reac-you-in'); ?></p>
    <?php
}

function ryi_job_details_meta_box($post) {
    wp_nonce_field('ryi_save_job_details', 'ryi_job_details_nonce');
    $location = get_post_meta($post->ID, '_ryi_job_location', true);
    $type = get_post_meta($post->ID, '_ryi_job_type', true);
    ?>
    <p><label for="ryi_job_location"><strong><?php esc_html_e('Location', 'reac-you-in'); ?></strong></label></p>
    <input class="widefat" type="text" name="ryi_job_location" id="ryi_job_location" value="<?php echo esc_attr($location); ?>" placeholder="Remote / Kochi / Hybrid">
    <p><label for="ryi_job_type"><strong><?php esc_html_e('Job Type', 'reac-you-in'); ?></strong></label></p>
    <input class="widefat" type="text" name="ryi_job_type" id="ryi_job_type" value="<?php echo esc_attr($type); ?>" placeholder="Full-time / Internship / Contract">
    <?php
}

function ryi_save_meta($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (isset($_POST['ryi_case_video_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['ryi_case_video_nonce'])), 'ryi_save_case_video')) {
        update_post_meta($post_id, '_ryi_video_url', isset($_POST['ryi_video_url']) ? esc_url_raw(wp_unslash($_POST['ryi_video_url'])) : '');
        update_post_meta($post_id, '_ryi_case_label', isset($_POST['ryi_case_label']) ? sanitize_text_field(wp_unslash($_POST['ryi_case_label'])) : '');
        update_post_meta($post_id, '_ryi_video_views', isset($_POST['ryi_video_views']) ? sanitize_text_field(wp_unslash($_POST['ryi_video_views'])) : '');
    }
    if (isset($_POST['ryi_job_details_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['ryi_job_details_nonce'])), 'ryi_save_job_details')) {
        update_post_meta($post_id, '_ryi_job_location', isset($_POST['ryi_job_location']) ? sanitize_text_field(wp_unslash($_POST['ryi_job_location'])) : '');
        update_post_meta($post_id, '_ryi_job_type', isset($_POST['ryi_job_type']) ? sanitize_text_field(wp_unslash($_POST['ryi_job_type'])) : '');
    }
}
add_action('save_post', 'ryi_save_meta');

function ryi_handle_contact() {
    if (!isset($_POST['ryi_contact_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['ryi_contact_nonce'])), 'ryi_contact')) {
        wp_safe_redirect(add_query_arg('contact', 'invalid', wp_get_referer() ?: home_url('/contact-us/')));
        exit;
    }

    $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
    $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
    $phone = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';
    $service = isset($_POST['service']) ? sanitize_text_field(wp_unslash($_POST['service'])) : '';
    $message = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';

    if (!$name || !$email || !$message || !is_email($email)) {
        wp_safe_redirect(add_query_arg('contact', 'missing', wp_get_referer() ?: home_url('/contact-us/')));
        exit;
    }

    $to = ryi_option('contact_email', get_option('admin_email'));
    $subject = sprintf(__('New website enquiry from %s', 'reac-you-in'), $name);
    $body = "Name: {$name}\nEmail: {$email}\nPhone: {$phone}\nService: {$service}\n\nMessage:\n{$message}";
    $headers = array('Reply-To: ' . $name . ' <' . $email . '>');
    wp_mail($to, $subject, $body, $headers);

    wp_safe_redirect(add_query_arg('contact', 'sent', wp_get_referer() ?: home_url('/contact-us/')));
    exit;
}
add_action('admin_post_ryi_contact', 'ryi_handle_contact');
add_action('admin_post_nopriv_ryi_contact', 'ryi_handle_contact');

function ryi_activate_theme() {
    ryi_register_post_types();
    ryi_create_default_pages();
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'ryi_activate_theme');

function ryi_repair_pages_request() {
    if (!current_user_can('manage_options') || !isset($_GET['ryi_repair_pages'])) {
        return;
    }
    check_admin_referer('ryi_repair_pages');
    ryi_activate_theme();
    wp_safe_redirect(admin_url('admin.php?page=ryi-settings&pages=repaired'));
    exit;
}
add_action('admin_init', 'ryi_repair_pages_request');
