<?php get_header(); ?>
<?php while (have_posts()) : the_post(); ?>
    <?php ryi_page_hero(get_the_title(), get_the_excerpt(), get_post_type() === 'ryi_case' ? 'Case Study' : (get_post_type() === 'ryi_job' ? 'Career' : 'Blog')); ?>
    <section class="section">
        <article class="container content-body reveal">
            <?php if (has_post_thumbnail()) : ?><div class="single-thumb"><?php the_post_thumbnail('large'); ?></div><?php endif; ?>
            <?php if (get_post_type() === 'ryi_case') { echo ryi_video_embed(get_post_meta(get_the_ID(), '_ryi_video_url', true)); } ?>
            <?php if (get_post_type() === 'ryi_case' && get_post_meta(get_the_ID(), '_ryi_video_views', true)) : ?><p class="views-badge"><?php echo esc_html(get_post_meta(get_the_ID(), '_ryi_video_views', true)); ?></p><?php endif; ?>
            <?php if (get_post_type() === 'ryi_job') : ?><p class="eyebrow"><?php echo esc_html(get_post_meta(get_the_ID(), '_ryi_job_type', true)); ?> - <?php echo esc_html(get_post_meta(get_the_ID(), '_ryi_job_location', true)); ?></p><?php endif; ?>
            <?php the_content(); ?>
            <p><?php echo ryi_button('Contact Us', home_url('/contact-us/')); ?></p>
        </article>
    </section>
<?php endwhile; ?>
<?php get_footer(); ?>
