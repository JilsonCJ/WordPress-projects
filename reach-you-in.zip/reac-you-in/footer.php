<?php
/**
 * Site footer.
 *
 * @package ReacYouIn
 */
?>
</main>
<footer class="site-footer section-dark">
    <div class="container footer-grid">
        <div class="footer-brand reveal">
            <h2><?php echo esc_html(ryi_option('brand_name', 'Reach you in')); ?></h2>
            <p class="lead">Digital Marketing Built Around Your Business Goals.</p>
            <p>We help businesses grow their digital presence through strategic marketing, social media, influencer campaigns, paid advertising, creative design, and technical solutions.</p>
            <div class="social-links">
                <a href="<?php echo esc_url(ryi_option('facebook', '#')); ?>">Facebook</a>
                <a href="<?php echo esc_url(ryi_option('instagram', '#')); ?>">Instagram</a>
                <a href="<?php echo esc_url(ryi_option('linkedin', '#')); ?>">LinkedIn</a>
                <a href="<?php echo esc_url(ryi_option('youtube', '#')); ?>">YouTube</a>
            </div>
        </div>
        <div class="footer-col reveal delay-1">
            <h3>Quick Links</h3>
            <a href="<?php echo esc_url(home_url('/about-us/')); ?>">About Us</a>
            <a href="<?php echo esc_url(home_url('/our-team/')); ?>">Our Team</a>
            <a href="<?php echo esc_url(home_url('/why-us/')); ?>">Why Us</a>
            <a href="<?php echo esc_url(home_url('/case-studies/')); ?>">Case Studies</a>
            <a href="<?php echo esc_url(home_url('/blogs/')); ?>">Blogs</a>
            <a href="<?php echo esc_url(home_url('/careers/')); ?>">Careers</a>
            <a href="<?php echo esc_url(home_url('/contact-us/')); ?>">Contact Us</a>
        </div>
        <div class="footer-col reveal delay-2">
            <h3>Our Services</h3>
            <?php foreach (ryi_services() as $service) : ?>
                <a href="<?php echo esc_url(home_url('/services/' . $service['slug'] . '/')); ?>"><?php echo esc_html($service['kicker']); ?></a>
            <?php endforeach; ?>
        </div>
        <div class="footer-col reveal delay-3">
            <h3>Let's Connect</h3>
            <p>Have a project in mind? Tell us what you're trying to achieve and let's explore how we can help your business grow.</p>
            <?php echo ryi_button('Contact Us', home_url('/contact-us/'), 'light'); ?>
        </div>
    </div>
    <div class="container footer-bottom">
        <p>&copy; <?php echo esc_html(date_i18n('Y')); ?> <?php echo esc_html(ryi_option('brand_name', 'Reach you in')); ?>. All Rights Reserved.</p>
        <p><a href="#">Privacy Policy</a> | <a href="#">Terms & Conditions</a> | <a href="#">Sitemap</a></p>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
