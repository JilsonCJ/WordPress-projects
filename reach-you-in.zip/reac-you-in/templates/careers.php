<?php
/**
 * Template Name: Careers
 */
get_header();
ryi_page_hero('Careers at Reach you in', 'Post new job vacancies from the Careers / Vacancies section in the WordPress dashboard.', 'Careers');
?>
<section class="section">
    <div class="container section-heading reveal"><h2>Open Vacancies</h2><p>Join a coordinated growth team working across marketing, influencers, social media, advertising, creative, and technology.</p></div>
    <div class="container cards-grid">
        <?php
        $jobs = new WP_Query(array('post_type' => 'ryi_job', 'posts_per_page' => -1));
        if ($jobs->have_posts()) :
            while ($jobs->have_posts()) : $jobs->the_post();
                ?>
                <article class="service-card reveal">
                    <p class="eyebrow"><?php echo esc_html(get_post_meta(get_the_ID(), '_ryi_job_type', true) ?: 'Opening'); ?> - <?php echo esc_html(get_post_meta(get_the_ID(), '_ryi_job_location', true) ?: 'Flexible'); ?></p>
                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <p><?php echo esc_html(get_the_excerpt() ?: wp_trim_words(get_the_content(), 26)); ?></p>
                    <a href="<?php echo esc_url(home_url('/contact-us/?service=Careers')); ?>">Apply / Enquire -></a>
                </article>
                <?php
            endwhile;
            wp_reset_postdata();
        else :
            ?>
            <article class="service-card reveal"><h2>No current vacancies posted.</h2><p>Use the WordPress dashboard to publish job vacancies whenever hiring opens.</p></article>
        <?php endif; ?>
    </div>
</section>
<?php get_footer(); ?>
