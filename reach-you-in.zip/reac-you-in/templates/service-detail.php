<?php
/**
 * Template Name: Service Detail
 */
get_header();
$slug = get_post_field('post_name', get_queried_object_id());
$service = ryi_service_by_slug($slug);
if (!$service) {
    $service = ryi_service_by_slug(str_replace('services-', '', $slug));
}
$service = $service ?: ryi_services()[0];
$details = array(
    'influencer-marketing' => array(
        'hero' => 'Influencer Marketing That Puts Your Brand in Front of the Right Audience',
        'sub' => 'Turn creator influence into brand awareness, engagement, and growth.',
        'sections' => array('More Than Finding an Influencer. We Build the Right Campaign.', 'A Wider Creator Network. More Campaign Possibilities.', 'Your Budget Should Work Smarter', 'Ready to Put Your Brand in Front of the Right People?'),
        'items' => array('Understand', 'Discover', 'Match', 'Create', 'Launch', 'Measure'),
    ),
    'social-media-marketing' => array(
        'hero' => 'Social Media Marketing That Makes Your Brand Impossible to Ignore',
        'sub' => 'Build a stronger social presence, connect with your audience, and grow your brand.',
        'sections' => array('Everything Your Brand Needs to Grow on Social Media', 'We Do Not Post Just to Fill Your Feed', 'Attract, Engage, Build Trust, Convert, Grow', 'Your Audience Is Already on Social Media. Let\'s Reach Them.'),
        'items' => array('Social Media Strategy', 'Content Planning', 'Creative Content', 'Audience Engagement', 'Campaign Management', 'Performance Optimization'),
    ),
    'paid-advertising' => array(
        'hero' => 'Paid Advertising That Puts Your Business in Front of Potential Customers',
        'sub' => 'Reach the right audience, test what works, and optimize for better performance.',
        'sections' => array('From Campaign Strategy to Performance Optimization', 'Make Every Advertising Decision Count', 'Research to Scale', 'Ready to Turn Your Advertising Budget Into Opportunities?'),
        'items' => array('Audience Targeting', 'Campaign Strategy', 'Ad Creative', 'Platform Campaigns', 'Performance Monitoring', 'Continuous Optimization'),
    ),
    'technical-solutions' => array(
        'hero' => 'Technical Solutions That Make Your Digital Marketing Work Better',
        'sub' => 'Build the technology behind a stronger digital presence.',
        'sections' => array('Technology Built Around Your Digital Requirements', 'Where Digital Marketing Meets Technology', 'Look at the Bigger Digital Picture', 'Have a Digital Problem? Let\'s Find the Right Solution.'),
        'items' => array('Website Solutions', 'Performance Optimization', 'Analytics & Tracking', 'Marketing Integrations', 'Technical Troubleshooting', 'Digital Infrastructure'),
    ),
    'graphic-designing' => array(
        'hero' => 'Graphic Design That Makes Your Brand Impossible to Miss',
        'sub' => 'Turn ideas into visuals people notice, understand, and remember.',
        'sections' => array('Creative Design for Every Digital Touchpoint', 'Beautiful Design Is Good. Effective Design Is Better.', 'Your Brand Should Look Consistent Everywhere', 'Give Your Brand the Visual Impact It Deserves'),
        'items' => array('Social Media Graphics', 'Advertising Creatives', 'Branding & Visual Identity', 'Marketing Materials', 'Website Graphics', 'Campaign Creatives'),
    ),
    'poster-designing' => array(
        'hero' => 'Poster Designing That Makes Your Message Stand Out',
        'sub' => 'Promote products, offers, events, announcements, and campaigns with sharp visual communication.',
        'sections' => array('Poster Design for Promotions, Events, and Campaigns', 'Fast Attention With Clear Message Hierarchy', 'Campaign Posters Built for Digital Channels', 'Ready to Create Posters People Notice?'),
        'items' => array('Promotional Posters', 'Event Posters', 'Offer Creatives', 'Announcement Designs', 'Campaign Posters', 'Social Poster Adaptations'),
    ),
    'ai-content-creation' => array(
        'hero' => 'AI-Powered Content Creation, Guided by Human Creativity',
        'sub' => 'Create more content, move faster, and keep your brand original.',
        'sections' => array('AI Content for Every Stage of Your Marketing', 'AI Creates Faster. Humans Make It Better.', 'Faster Production With Brand Quality', 'Create More. Create Faster. Create Smarter.'),
        'items' => array('Marketing Copy', 'Social Media Content', 'Blog & Website Content', 'Advertising Copy', 'Content Ideas', 'Scripts & Creative Concepts'),
    ),
);
$data = $details[$service['slug']];
ryi_page_hero($data['hero'], $data['sub'], $service['kicker']);
?>
<section class="section">
    <div class="container section-heading reveal"><h2><?php echo esc_html($data['sections'][0]); ?></h2><p>We shape the service around your brand, audience, budget, market, and campaign goals.</p></div>
    <div class="container cards-grid">
        <?php foreach ($data['items'] as $item) : ?><article class="service-card reveal"><h3><?php echo esc_html($item); ?></h3><p>Planned and executed with clear objectives, consistent communication, and performance awareness.</p></article><?php endforeach; ?>
    </div>
</section>
<section class="section section-soft">
    <div class="container split">
        <div class="reveal"><h2><?php echo esc_html($data['sections'][1]); ?></h2><p>We do not treat this as a disconnected task. It becomes part of your wider digital marketing strategy.</p><?php echo ryi_button('Discuss Your Goals', home_url('/contact-us/')); ?></div>
        <div class="quote-block reveal delay-2"><?php echo esc_html($data['sections'][2]); ?></div>
    </div>
</section>
<section class="section section-dark">
    <div class="container split">
        <div class="reveal"><h2>Recommended Internal Path</h2><p>Homepage to service page, related service, case study, and contact. That structure helps visitors and search engines understand your services.</p></div>
        <div class="stack-list reveal delay-2"><div><span>01</span>Service Strategy</div><div><span>02</span>Related Creative</div><div><span>03</span>Case Study Proof</div><div><span>04</span>Contact Conversion</div></div>
    </div>
</section>
<section class="final-cta section-dark grid-bg"><div class="container reveal"><h2><?php echo esc_html($data['sections'][3]); ?></h2><p>Tell us what you want to achieve and we will help identify the right path forward.</p><?php echo ryi_button('Get a Free Consultation', home_url('/contact-us/'), 'light'); ?></div></section>
<?php get_footer(); ?>
