<?php
/**
 * Template Name: About Us
 */
get_header();
ryi_page_hero('Built to Make Digital Marketing More Accessible, Powerful, and Results-Driven', 'Strong team, extensive influencer network, affordable campaigns, high reach, and complete digital services.', 'About Us');
?>
<section class="section">
    <?php ryi_text_animation(array('Accessible', 'Powerful', 'Results', 'Network'), 'marquee'); ?>
    <div class="container split">
        <div class="reveal">
            <h2>Our Story - Who We Are</h2>
            <p>We are a team of digital marketers, creative specialists, designers, strategists, and technical professionals working together to help businesses grow in the digital world.</p>
            <p>Our approach brings strategy, creativity, influencer relationships, advertising, design, and technology together under one team, giving businesses access to the expertise they need without the complexity of managing multiple agencies.</p>
        </div>
        <div class="mission-vision-grid reveal delay-2">
            <article class="mission-card">
                <span>Mission</span>
                <h3>Smarter Digital Marketing for Real Business Growth</h3>
                <p>Help businesses reach more people, build stronger brands, and create more opportunities through strategy, creativity, technology, and relevant audience connections.</p>
            </article>
            <article class="mission-card mission-card-dark">
                <span>Vision</span>
                <h3>A More Accessible Digital Growth Ecosystem</h3>
                <p>Build a marketing ecosystem where businesses of every size can access high-quality marketing, powerful networks, creative talent, and technology at competitive prices.</p>
            </article>
        </div>
    </div>
</section>
<section class="section section-dark">
    <?php ryi_text_animation(array('Creators', 'Reach', 'Markets', 'Influence'), 'orbit'); ?>
    <div class="container section-heading reveal"><h2>A Global Network That Helps Your Brand Reach Further</h2><p>The right connection can change the reach of a campaign.</p></div>
    <div class="container benefits-grid">
        <?php foreach (array('Audience' => 'Find creators whose followers match your target customers.', 'Location' => 'Reach audiences in the markets that matter to your business.', 'Industry' => 'Connect your brand with creators relevant to your niche.', 'Campaign Goals' => 'Choose partnerships based on awareness, engagement, promotion, or conversions.') as $title => $copy) : ?>
            <article class="benefit reveal"><h3><?php echo esc_html($title); ?></h3><p><?php echo esc_html($copy); ?></p></article>
        <?php endforeach; ?>
    </div>
</section>
<section class="section section-soft">
    <?php ryi_text_animation(array('Value', 'Budget', 'Reach', 'Smarter'), 'typing'); ?>
    <div class="container split">
        <div class="reveal"><h2>Competitive Pricing Without Compromising on Reach</h2><p>Great marketing should not require an unreasonable budget. We focus on smarter ways to allocate your investment using network access, creative capability, and campaign expertise.</p><?php echo ryi_button('Get a Campaign Quote', home_url('/contact-us/')); ?></div>
        <div class="stack-list reveal delay-2">
            <?php foreach (array('Strong Network', 'Flexible Campaigns', 'Creative In-House Expertise', 'Strategic Selection', 'Optimized Spending') as $i => $item) : ?><div><span><?php echo esc_html('0' . ($i + 1)); ?></span><?php echo esc_html($item); ?></div><?php endforeach; ?>
        </div>
    </div>
</section>
<section class="section">
    <?php ryi_text_animation(array('Strategists', 'Designers', 'Ads', 'Tech'), 'stack'); ?>
    <div class="container section-heading reveal"><h2>A Team With the Skills to Handle the Entire Digital Journey</h2></div>
    <div class="container cards-grid">
        <?php foreach (array('Marketing Strategists', 'Influencer Specialists', 'Social Media Experts', 'Advertising Specialists', 'Graphic Designers', 'Technical Specialists') as $role) : ?>
            <article class="service-card reveal"><h3><?php echo esc_html($role); ?></h3><p>Specialists who coordinate around your campaign objective, audience, budget, and long-term growth.</p></article>
        <?php endforeach; ?>
    </div>
</section>
<section class="final-cta section-dark grid-bg"><div class="container reveal"><h2>Your Brand Has Potential. Let's Help More People Discover It.</h2><p>Whether you need influencer marketing, social media marketing, paid advertising, creative design, or technical solutions, our team is ready to help.</p><?php echo ryi_button('Get a Free Consultation', home_url('/contact-us/'), 'light'); ?></div></section>
<?php get_footer(); ?>
