<?php
/**
 * Template Name: Why Us
 */
get_header();
ryi_page_hero('Why Choose Us for Your Digital Marketing?', 'More reach. More expertise. More value. One team.', 'Why Us');
?>
<section class="section">
    <div class="container section-heading reveal"><h2>What Makes Our Digital Marketing Company Different?</h2><p>Choose a partner based on value, expertise, flexibility, and opportunity.</p></div>
    <div class="container cards-grid">
        <?php foreach (array('Extensive Influencer Network', 'Value-Focused Pricing', 'Audience-Focused Marketing', 'Strategy + Execution', 'Creative + Marketing Together', 'Technical Capability') as $item) : ?>
            <article class="service-card reveal"><h3><?php echo esc_html($item); ?></h3><p>Our approach keeps your campaign coordinated, relevant, practical, and designed around real business goals.</p></article>
        <?php endforeach; ?>
    </div>
</section>
<section class="section section-soft">
    <div class="container reveal"><h2>How We Compare With Typical Digital Marketing Options</h2><div class="table-wrap"><table><thead><tr><th>What You Need</th><th>Traditional Agency</th><th>Freelancer</th><th>Specialized Provider</th><th>Our Approach</th></tr></thead><tbody>
        <?php foreach (array('Marketing Strategy', 'Influencer Marketing', 'Broad Creator Network', 'Social Media Marketing', 'Paid Advertising', 'Graphic Design', 'Technical Solutions', 'One Coordinated Team') as $row) : ?><tr><td><?php echo esc_html($row); ?></td><td>Varies</td><td>Limited</td><td>Sometimes</td><td><strong>Yes</strong></td></tr><?php endforeach; ?>
    </tbody></table></div></div>
</section>
<section class="section section-dark">
    <div class="container split">
        <div class="reveal"><h2>Affordable Doesn't Have to Mean Basic</h2><p>The real question is what value your marketing investment can create. We focus on smart planning, flexible solutions, network advantage, in-house capability, and continuous improvement.</p><?php echo ryi_button('Request a Custom Quote', home_url('/contact-us/'), 'light'); ?></div>
        <div class="quote-block reveal delay-2">Don't Spend More. Spend Smarter.</div>
    </div>
</section>
<section class="section">
    <div class="container section-heading reveal"><h2>Why Businesses Can Trust Our Approach</h2></div>
    <div class="container benefits-grid">
        <?php foreach (array('We Listen Before We Recommend', 'No One-Size-Fits-All Marketing', 'Clear Communication', 'Multiple Areas of Expertise', 'Meaningful Metrics', 'Thinking Beyond One Campaign') as $item) : ?><article class="benefit reveal"><h3><?php echo esc_html($item); ?></h3><p>Every recommendation is connected to your objectives, audience, market, and budget.</p></article><?php endforeach; ?>
    </div>
</section>
<section class="final-cta section-dark grid-bg"><div class="container reveal"><h2>Why Settle for Separate Services When You Can Have One Connected Team?</h2><p>Influencer network, social media expertise, paid advertising, creative designers, technical capabilities, and digital strategy working toward your business growth.</p><?php echo ryi_button('Get a Free Consultation', home_url('/contact-us/'), 'light'); ?></div></section>
<?php get_footer(); ?>
