<?php
/**
 * Template Name: Services
 */
get_header();
ryi_page_hero('Everything You Need to Build a Stronger Digital Brand', 'One partner. Multiple digital marketing solutions designed around your business objectives.', 'Services');
?>
<section class="section">
    <div class="container cards-grid">
        <?php foreach (ryi_services() as $service) : ?>
            <article class="service-card reveal">
                <span class="card-icon"><?php echo esc_html($service['icon']); ?></span>
                <p class="eyebrow"><?php echo esc_html($service['kicker']); ?></p>
                <h2><?php echo esc_html($service['title']); ?></h2>
                <p><?php echo esc_html($service['copy']); ?></p>
                <a href="<?php echo esc_url(home_url('/services/' . $service['slug'] . '/')); ?>">Open Service -></a>
            </article>
        <?php endforeach; ?>
    </div>
</section>
<section class="section section-dark">
    <div class="container split">
        <div class="reveal"><h2>Integrated Digital Marketing Services</h2><p>Influencer marketing, social media, paid advertising, graphic design, AI content, and technical solutions become stronger when they are planned together.</p></div>
        <div class="signal-board reveal delay-2"><span>Awareness</span><span>Engagement</span><span>Leads</span><span>Trust</span><span>Creative</span><span>Performance</span></div>
    </div>
</section>
<?php get_footer(); ?>
