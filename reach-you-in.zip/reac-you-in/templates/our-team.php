<?php
/**
 * Template Name: Our Team
 */
get_header();
ryi_page_hero('Meet the Team Behind Your Digital Growth', 'Strategy, creativity, technology, advertising, and execution working together as one coordinated growth unit.', 'Our Team');
?>
<section class="section">
    <div class="container section-heading reveal"><h2>Different Experts. One Powerful Digital Marketing Team.</h2><p>Your business should not have to manage multiple disconnected agencies for every marketing requirement.</p></div>
    <div class="container cards-grid">
        <?php
        $roles = array(
            'Digital Marketing Strategists' => 'Strategy, campaign planning, audience research, and growth planning.',
            'Influencer Marketing Specialists' => 'Creator discovery, campaign planning, partnerships, and campaign management.',
            'Social Media Specialists' => 'Social strategy, content planning, engagement, and campaigns.',
            'Paid Advertising Specialists' => 'Campaign setup, targeting, creative testing, and performance optimization.',
            'Creative & Graphic Designers' => 'Brand creatives, social media graphics, advertising creatives, and poster design.',
            'Technical Specialists' => 'Websites, tracking, integrations, and technical solutions.',
        );
        foreach ($roles as $title => $copy) : ?>
            <article class="service-card reveal"><h3><?php echo esc_html($title); ?></h3><p><?php echo esc_html($copy); ?></p></article>
        <?php endforeach; ?>
    </div>
</section>
<section class="section section-dark">
    <div class="container split">
        <div class="reveal"><h2>Your Project Doesn't Move Through Silos. It Moves as One Team.</h2><p>Campaigns often involve strategy, creators, designers, advertising specialists, and technical experts. Our team brings those areas together.</p><?php echo ryi_button('Work With Our Team', home_url('/contact-us/'), 'light'); ?></div>
        <div class="stack-list reveal delay-2">
            <?php foreach (array('Understand', 'Plan', 'Create', 'Launch', 'Analyze', 'Improve') as $i => $step) : ?><div><span><?php echo esc_html('0' . ($i + 1)); ?></span><?php echo esc_html($step); ?></div><?php endforeach; ?>
        </div>
    </div>
</section>
<section class="section section-soft">
    <div class="container section-heading reveal"><h2>Experts Who Care About Your Brand as Much as the Campaign</h2><p>Successful client relationships are built on communication, creativity, transparency, and accountability.</p></div>
    <div class="container benefits-grid">
        <?php foreach (array('Who are you trying to reach?', 'What are you trying to achieve?', 'What makes your business different?', 'Where can your budget create opportunity?', 'How can we make your brand stand out?', 'What should improve next?') as $question) : ?>
            <article class="benefit reveal"><h3><?php echo esc_html($question); ?></h3><p>We ask better questions so the work has stronger direction.</p></article>
        <?php endforeach; ?>
    </div>
</section>
<section class="final-cta section-dark grid-bg"><div class="container reveal"><h2>Ready to Put the Right Team Behind Your Brand?</h2><p>Let's build something that gets noticed.</p><?php echo ryi_button('Contact Our Team', home_url('/contact-us/'), 'light'); ?></div></section>
<?php get_footer(); ?>
