<?php
/**
 * Template Name: Contact Us
 */
get_header();
ryi_page_hero('A Better Digital Presence Starts With One Conversation.', 'Tell us about your business, your challenges, and what you want to achieve.', 'Contact Us');
?>
<section class="section">
    <div class="container split contact-layout">
        <div class="reveal">
            <h2>Let's Build Your Digital Growth Strategy.</h2>
            <p>Use the form and your enquiry will be mailed to the address configured in the Reach you in back panel.</p>
            <div class="contact-detail"><strong>Email</strong><span><?php echo esc_html(ryi_option('contact_email')); ?></span></div>
            <div class="contact-detail"><strong>Phone</strong><span><?php echo esc_html(ryi_option('phone')); ?></span></div>
            <div class="contact-detail"><strong>Service Area</strong><span><?php echo esc_html(ryi_option('address')); ?></span></div>
        </div>
        <?php echo ryi_contact_form(); ?>
    </div>
</section>
<?php get_footer(); ?>
