<article class="case-card reveal">
    <a class="case-thumb video-preview" href="<?php the_permalink(); ?>">
        <?php if (has_post_thumbnail()) : ?>
            <?php the_post_thumbnail('medium_large'); ?>
        <?php else : ?>
            <span class="video-placeholder">Social Video</span>
        <?php endif; ?>
        <span class="play-dot">Play</span>
    </a>
    <p class="eyebrow"><?php echo esc_html(get_post_meta(get_the_ID(), '_ryi_case_label', true) ?: 'Case Study'); ?></p>
    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
    <p><?php echo esc_html(get_the_excerpt() ?: wp_trim_words(get_the_content(), 22)); ?></p>
    <?php if (get_post_meta(get_the_ID(), '_ryi_video_views', true)) : ?>
        <p class="views-badge"><?php echo esc_html(get_post_meta(get_the_ID(), '_ryi_video_views', true)); ?></p>
    <?php endif; ?>
    <a href="<?php the_permalink(); ?>">View Case Study -></a>
</article>
