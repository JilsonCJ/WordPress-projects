<?php
/**
 * Template Name: Case Studies
 */
get_header();
ryi_page_hero('From Business Challenges to Digital Opportunities', 'Upload viral videos, titles, thumbnails, labels, and descriptions from the Case Studies admin area.', 'Case Studies');
?>
<section class="section">
    <?php ryi_text_animation(array('Social Videos', 'Views', 'Viral Reach', 'Campaign Proof'), 'marquee'); ?>
    <div class="container case-grid">
        <?php
        $cases = new WP_Query(array('post_type' => 'ryi_case', 'posts_per_page' => -1));
        if ($cases->have_posts()) :
            while ($cases->have_posts()) : $cases->the_post();
                get_template_part('templates/part', 'case-card');
            endwhile;
            wp_reset_postdata();
        else :
            foreach (array('Brand Visibility', 'Social Media', 'Paid Advertising', 'Creative Design') as $case) : ?>
                <article class="case-card reveal"><a class="case-thumb video-preview" href="#"><span class="video-placeholder">Social Video</span><span class="play-dot">Play</span></a><p class="eyebrow"><?php echo esc_html($case); ?></p><h3><?php echo esc_html($case); ?> Growth Story</h3><p>Add social media video previews, views, screenshots, leads generated, traffic growth, or advertising metrics.</p><p class="views-badge">Add views in admin</p></article>
            <?php endforeach;
        endif;
        ?>
    </div>
</section>
<?php get_footer(); ?>
