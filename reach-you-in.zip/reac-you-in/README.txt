Reach you in WordPress Theme
Version: 1.0.0

Installation
1. In WordPress admin, go to Appearance > Themes > Add New > Upload Theme.
2. Upload reac-you-in.zip.
3. Activate the theme.
4. The theme creates the main pages, primary menu, front page, and blog page automatically.

Back Panel
Use WordPress admin > Reach you in to change:
- Logo and brand text
- Header consultation link
- Home hero title, subtitle, body, image, and video URL
- Contact receiving email address
- Phone and address/service area
- Social media links

Editable Content
- Pages: edit normal page text from Pages.
- Blogs: add posts from Posts.
- Careers: post vacancies from Careers / Vacancies.
- Case Studies: upload titles, descriptions, thumbnails, and viral video URLs from Case Studies.
- Contact form: messages are mailed to the email saved in Reach you in > Contact.
- Client logos: upload logo posts from Client Logos, using Featured Image.
- Repair pages: use Reach you in > Create / Repair Theme Pages if pages are not visible after upload.

Animation
Every front-end page uses multiple global animations:
- Hero grid motion
- Floating visual panels
- Scroll reveal
- Interactive card hover light
- Pulsing signal lines

Recommended Plugins
No plugin is required. For SMTP reliability, install any trusted SMTP plugin and configure your sending mail account.
