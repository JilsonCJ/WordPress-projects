<?php
/**
 * Template Name: Home Page
 */
get_header();
?>
<section class="hero section-dark grid-bg">
    <?php ryi_text_animation(array('Reach', 'Create', 'Convert', 'Grow'), 'typing'); ?>
    <div class="container hero-grid">
        <div class="hero-copy reveal">
            <p class="eyebrow">Strategy - Creativity - Technology - Results</p>
            <h1><?php echo esc_html(ryi_option('hero_title')); ?></h1>
            <p class="lead"><?php echo esc_html(ryi_option('hero_subtitle')); ?></p>
            <p><?php echo esc_html(ryi_option('hero_body')); ?></p>
            <div class="hero-actions">
                <?php echo ryi_button('Get a Free Consultation', ryi_option('consultation_url', home_url('/contact-us/'))); ?>
                <?php echo ryi_button('Explore Our Services', home_url('/services/'), 'ghost'); ?>
            </div>
        </div>
        <div class="hero-visual reveal delay-2">
            <?php
            $image_id = absint(ryi_option('hero_image_id', 0));
            if ($image_id) {
                echo wp_get_attachment_image($image_id, 'large');
            } else {
                ?>
                <div class="signal-board">
                    <span>Digital Marketing Company</span>
                    <span>Social Media Marketing</span>
                    <span>Influencer Marketing</span>
                    <span>Paid Advertising</span>
                    <span>Technical Solutions</span>
                    <span>Graphic Designing</span>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
</section>

<section class="section intro">
    <?php ryi_text_animation(array('Story', 'Audience', 'Attention', 'Opportunity'), 'marquee'); ?>
    <div class="container split">
        <div class="reveal">
            <p class="eyebrow">See How We Help Brands Grow</p>
            <h2>Your Business Has a Story. Let's Put It in Front of the Right People.</h2>
            <p>Having a website or social media account isn't enough anymore. Your customers are constantly discovering brands, comparing businesses, watching content, and making decisions online.</p>
            <p>Our team combines marketing strategy, creative thinking, advertising, design, and technology to build digital experiences that connect businesses with their audiences.</p>
            <?php echo ryi_button('Let\'s Discuss Your Business', home_url('/contact-us/')); ?>
        </div>
        <div class="video-card reveal delay-2">
            <?php echo ryi_video_embed(ryi_option('home_video_url')); ?>
            <?php if (!ryi_option('home_video_url')) : ?><div class="play-placeholder">WATCH OUR VIDEO</div><?php endif; ?>
        </div>
    </div>
    <div class="container process-grid">
        <?php
        $steps = array(
            'Understand' => 'We learn about your business, audience and goals.',
            'Strategize' => 'We build a strategy around your opportunities.',
            'Create' => 'We develop content, campaigns and creative solutions.',
            'Launch' => 'We put the strategy into action.',
            'Measure' => 'We monitor meaningful performance data.',
            'Optimize' => 'We improve campaigns based on what we learn.',
        );
        $i = 1;
        foreach ($steps as $title => $copy) :
            ?>
            <article class="process-card reveal">
                <span><?php echo esc_html(str_pad((string) $i, 2, '0', STR_PAD_LEFT)); ?></span>
                <h3><?php echo esc_html($title); ?></h3>
                <p><?php echo esc_html($copy); ?></p>
            </article>
            <?php $i++; endforeach; ?>
    </div>
</section>

<section class="section section-soft">
    <?php ryi_text_animation(array('Influence', 'Social', 'Ads', 'Design'), 'stack'); ?>
    <div class="container section-heading reveal">
        <p class="eyebrow">One Partner. Multiple Digital Marketing Solutions.</p>
        <h2>Everything You Need to Build a Stronger Digital Brand</h2>
        <p>From building awareness to generating leads and strengthening your brand identity, our services are designed to work together around your business objectives.</p>
    </div>
    <div class="container cards-grid">
        <?php foreach (ryi_services() as $service) : ?>
            <article class="service-card reveal">
                <span class="card-icon"><?php echo esc_html($service['icon']); ?></span>
                <p class="eyebrow"><?php echo esc_html($service['kicker']); ?></p>
                <h3><?php echo esc_html($service['title']); ?></h3>
                <p><?php echo esc_html($service['copy']); ?></p>
                <a href="<?php echo esc_url(home_url('/services/' . $service['slug'] . '/')); ?>">Explore <?php echo esc_html($service['kicker']); ?> -></a>
            </article>
        <?php endforeach; ?>
    </div>
    <div class="center reveal"><?php echo ryi_button('View All Services', home_url('/services/')); ?></div>
</section>

<section class="section section-dark">
    <?php ryi_text_animation(array('Business First', 'Strategy', 'Purpose', 'Data'), 'orbit'); ?>
    <div class="container split">
        <div class="reveal">
            <p class="eyebrow">Why Businesses Choose Us</p>
            <h2>We Don't Just Deliver Marketing. We Build Digital Growth Strategies.</h2>
            <p>The right marketing partner should understand more than platforms and advertisements. They should understand your business.</p>
            <div class="hero-actions"><?php echo ryi_button('Why Choose Us', home_url('/why-us/'), 'light'); ?><?php echo ryi_button('Talk to Our Team', home_url('/contact-us/'), 'ghost-light'); ?></div>
        </div>
        <div class="stack-list reveal delay-2">
            <?php foreach (array('Business First', 'Strategy Before Execution', 'Creative That Has a Purpose', 'Data-Informed Decisions', 'Marketing + Technology', 'Long-Term Partnership') as $index => $item) : ?>
                <div><span><?php echo esc_html('0' . ($index + 1)); ?></span><?php echo esc_html($item); ?></div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section">
    <?php ryi_text_animation(array('Videos', 'Views', 'Proof', 'Growth'), 'typing'); ?>
    <div class="container section-heading reveal">
        <p class="eyebrow">Real Businesses. Real Challenges. Strategic Solutions.</p>
        <h2>From Business Challenges to Digital Opportunities</h2>
    </div>
    <div class="container case-grid">
        <?php
        $cases = new WP_Query(array('post_type' => 'ryi_case', 'posts_per_page' => 4));
        if ($cases->have_posts()) :
            while ($cases->have_posts()) : $cases->the_post();
                get_template_part('templates/part', 'case-card');
            endwhile;
            wp_reset_postdata();
        else :
            foreach (array('Brand Visibility', 'Social Media', 'Paid Advertising', 'Creative Design') as $case) :
                ?>
                <article class="case-card reveal">
                    <p class="eyebrow"><?php echo esc_html($case); ?></p>
                    <h3><?php echo esc_html($case === 'Brand Visibility' ? 'Building a Stronger Online Presence' : ($case === 'Social Media' ? 'Creating Meaningful Audience Engagement' : ($case === 'Paid Advertising' ? 'Turning Advertising Into Opportunities' : 'Making Brands Visually Memorable'))); ?></h3>
                    <p>Strategic digital marketing designed to create stronger recognition, engagement, and business opportunity.</p>
                    <a href="<?php echo esc_url(home_url('/case-studies/')); ?>">View Case Study -></a>
                </article>
                <?php
            endforeach;
        endif;
        ?>
    </div>
</section>

<?php echo ryi_client_slider(); ?>

<section class="section section-soft">
    <?php ryi_text_animation(array('Visibility', 'Trust', 'Leads', 'Engagement'), 'marquee'); ?>
    <div class="container section-heading reveal">
        <h2>Your Goals. Our Expertise. One Digital Growth Strategy.</h2>
        <p>Whether you're a startup building your first digital presence or an established business looking to improve marketing performance, we create solutions around your stage of growth.</p>
    </div>
    <div class="container benefits-grid">
        <?php foreach (array('Increase Visibility', 'Build Brand Trust', 'Generate Leads', 'Improve Engagement', 'Strengthen Your Brand', 'Improve Digital Performance') as $benefit) : ?>
            <article class="benefit reveal"><h3><?php echo esc_html($benefit); ?></h3><p>Reach relevant audiences, communicate consistently, and improve the digital moments that influence business growth.</p></article>
        <?php endforeach; ?>
    </div>
</section>

<section class="section faq">
    <?php ryi_text_animation(array('Questions', 'Answers', 'Clarity', 'Next Step'), 'stack'); ?>
    <div class="container section-heading reveal"><h2>Frequently Asked Questions</h2></div>
    <div class="container faq-list">
        <?php
        $faqs = array(
            'What does a digital marketing company do?' => 'A digital marketing company helps businesses attract and connect with potential customers through online channels.',
            'What digital marketing services do you provide?' => 'Our core services include Influencer Marketing, Social Media Marketing, Paid Advertising, Technical Solutions, Graphic Designing, and AI Content Creation.',
            'Can you create a strategy specifically for my business?' => 'Yes. We consider your business objectives, audience, industry, competition, and current digital presence.',
            'Is digital marketing useful for small businesses?' => 'Absolutely. A focused digital strategy can help small businesses build visibility, credibility, and opportunity online.',
            'How do you measure digital marketing success?' => 'We evaluate metrics such as reach, engagement, website traffic, leads, conversions, advertising performance, and relevant KPIs.',
            'How do I get started?' => 'Contact our team and tell us about your business. We will discuss the services and strategy that fit your needs.',
        );
        foreach ($faqs as $q => $a) : ?>
            <details class="reveal"><summary><?php echo esc_html($q); ?></summary><p><?php echo esc_html($a); ?></p></details>
        <?php endforeach; ?>
    </div>
</section>

<section class="final-cta section-dark grid-bg">
    <div class="container reveal">
        <h2>Your Next Customer Is Already Online. Are They Finding You?</h2>
        <p>Build a stronger presence. Reach the right audience. Create meaningful connections. Turn attention into opportunities.</p>
        <div class="hero-actions"><?php echo ryi_button('Get a Free Consultation', home_url('/contact-us/'), 'light'); ?><?php echo ryi_button('Contact Us', home_url('/contact-us/'), 'ghost-light'); ?></div>
    </div>
</section>
<?php get_footer(); ?>
