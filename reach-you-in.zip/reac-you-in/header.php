<?php
/**
 * Site header.
 *
 * @package ReacYouIn
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#content"><?php esc_html_e('Skip to content', 'reac-you-in'); ?></a>
<header class="site-header">
    <div class="container nav-wrap">
        <a class="site-brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php echo esc_attr(get_bloginfo('name')); ?>">
            <?php ryi_logo(); ?>
        </a>
        <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="site-navigation">
            <span></span><span></span><span></span>
        </button>
        <nav id="site-navigation" class="site-nav" aria-label="<?php esc_attr_e('Primary navigation', 'reac-you-in'); ?>">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container' => false,
                'fallback_cb' => 'ryi_fallback_menu',
                'menu_class' => 'menu',
            ));
            ?>
        </nav>
        <a class="header-cta" href="<?php echo esc_url(ryi_option('consultation_url', home_url('/contact-us/'))); ?>">Get a Free Consultation</a>
    </div>
</header>
<main id="content" class="site-main">
