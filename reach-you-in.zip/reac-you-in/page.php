<?php get_header(); ?>
<?php while (have_posts()) : the_post(); ?>
    <?php ryi_page_hero(get_the_title(), wp_trim_words(wp_strip_all_tags(get_the_content()), 22), 'Page'); ?>
    <section class="section"><div class="container content-body reveal"><?php the_content(); ?></div></section>
<?php endwhile; ?>
<?php get_footer(); ?>
