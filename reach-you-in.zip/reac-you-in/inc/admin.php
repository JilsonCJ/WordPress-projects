<?php
/**
 * Theme settings panel.
 *
 * @package ReacYouIn
 */

if (!defined('ABSPATH')) {
    exit;
}

function ryi_admin_menu() {
    add_menu_page(
        __('Reach you in Panel', 'reac-you-in'),
        __('Reach you in', 'reac-you-in'),
        'manage_options',
        'ryi-settings',
        'ryi_settings_page',
        'dashicons-megaphone',
        3
    );
}
add_action('admin_menu', 'ryi_admin_menu');

function ryi_register_settings() {
    register_setting('ryi_options_group', 'ryi_options', 'ryi_sanitize_options');
}
add_action('admin_init', 'ryi_register_settings');

function ryi_sanitize_options($input) {
    $defaults = ryi_defaults();
    $clean = array();
    foreach ($defaults as $key => $value) {
        if (in_array($key, array('consultation_url', 'home_video_url', 'facebook', 'instagram', 'linkedin', 'youtube'), true)) {
            $clean[$key] = isset($input[$key]) ? esc_url_raw($input[$key]) : '';
        } elseif ($key === 'contact_email') {
            $clean[$key] = isset($input[$key]) ? sanitize_email($input[$key]) : get_option('admin_email');
        } else {
            $clean[$key] = isset($input[$key]) ? sanitize_textarea_field($input[$key]) : $value;
        }
    }
    $clean['logo_id'] = isset($input['logo_id']) ? absint($input['logo_id']) : 0;
    $clean['hero_image_id'] = isset($input['hero_image_id']) ? absint($input['hero_image_id']) : 0;
    return $clean;
}

function ryi_field($key, $label, $type = 'text') {
    $options = ryi_options();
    $value = isset($options[$key]) ? $options[$key] : '';
    ?>
    <label class="ryi-field">
        <span><?php echo esc_html($label); ?></span>
        <?php if ($type === 'textarea') : ?>
            <textarea name="ryi_options[<?php echo esc_attr($key); ?>]" rows="4"><?php echo esc_textarea($value); ?></textarea>
        <?php else : ?>
            <input type="<?php echo esc_attr($type); ?>" name="ryi_options[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($value); ?>">
        <?php endif; ?>
    </label>
    <?php
}

function ryi_media_field($key, $label) {
    $options = ryi_options();
    $id = isset($options[$key]) ? absint($options[$key]) : 0;
    $preview = $id ? wp_get_attachment_image_url($id, 'medium') : '';
    ?>
    <div class="ryi-field ryi-media-field">
        <span><?php echo esc_html($label); ?></span>
        <input type="hidden" class="ryi-media-id" name="ryi_options[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($id); ?>">
        <div class="ryi-media-preview"><?php if ($preview) : ?><img src="<?php echo esc_url($preview); ?>" alt=""><?php endif; ?></div>
        <button type="button" class="button ryi-upload">Choose / Upload</button>
        <button type="button" class="button ryi-clear">Remove</button>
    </div>
    <?php
}

function ryi_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    ?>
    <div class="wrap ryi-admin">
        <h1><?php esc_html_e('Reach you in Back Panel', 'reac-you-in'); ?></h1>
        <?php if (isset($_GET['pages']) && $_GET['pages'] === 'repaired') : ?>
            <div class="notice notice-success"><p>Pages, menus, and theme routes have been created or repaired.</p></div>
        <?php endif; ?>
        <p class="description">Change logo, hero content, home video, contact email, social media links, and key site defaults. Blogs use Posts. Case videos use Case Studies. Client logos use Client Logos. Vacancies use Careers / Vacancies. Page text can be edited from Pages.</p>
        <p><a class="button button-secondary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=ryi-settings&ryi_repair_pages=1'), 'ryi_repair_pages')); ?>">Create / Repair Theme Pages</a></p>
        <form method="post" action="options.php">
            <?php settings_fields('ryi_options_group'); ?>
            <div class="ryi-admin-grid">
                <section class="ryi-card">
                    <h2>Brand</h2>
                    <?php ryi_field('brand_name', 'Brand / Logo Text'); ?>
                    <?php ryi_media_field('logo_id', 'Upload Logo'); ?>
                    <?php ryi_field('consultation_url', 'Header CTA Link', 'url'); ?>
                </section>
                <section class="ryi-card">
                    <h2>Home Hero</h2>
                    <?php ryi_field('hero_title', 'Hero Title', 'textarea'); ?>
                    <?php ryi_field('hero_subtitle', 'Hero Subtitle', 'textarea'); ?>
                    <?php ryi_field('hero_body', 'Hero Body', 'textarea'); ?>
                    <?php ryi_media_field('hero_image_id', 'Hero / Home Image'); ?>
                    <?php ryi_field('home_video_url', 'Home Video URL', 'url'); ?>
                </section>
                <section class="ryi-card">
                    <h2>Contact</h2>
                    <?php ryi_field('contact_email', 'Receive Contact Form Emails At', 'email'); ?>
                    <?php ryi_field('phone', 'Phone'); ?>
                    <?php ryi_field('address', 'Address / Service Area', 'textarea'); ?>
                </section>
                <section class="ryi-card">
                    <h2>Social Media</h2>
                    <?php ryi_field('facebook', 'Facebook URL', 'url'); ?>
                    <?php ryi_field('instagram', 'Instagram URL', 'url'); ?>
                    <?php ryi_field('linkedin', 'LinkedIn URL', 'url'); ?>
                    <?php ryi_field('youtube', 'YouTube URL', 'url'); ?>
                </section>
            </div>
            <?php submit_button('Save Back Panel Settings'); ?>
        </form>
    </div>
    <?php
}
