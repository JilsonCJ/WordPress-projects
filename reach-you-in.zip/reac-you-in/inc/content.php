<?php
/**
 * Activation content.
 *
 * @package ReacYouIn
 */

if (!defined('ABSPATH')) {
    exit;
}

function ryi_create_page($title, $slug, $template = '', $parent_id = 0) {
    $path = $parent_id ? get_post_field('post_name', $parent_id) . '/' . $slug : $slug;
    $existing = get_page_by_path($path);
    if ($existing) {
        if ($template) {
            update_post_meta($existing->ID, '_wp_page_template', $template);
        }
        return $existing->ID;
    }
    $id = wp_insert_post(array(
        'post_title' => $title,
        'post_name' => $slug,
        'post_type' => 'page',
        'post_status' => 'publish',
        'post_content' => '',
        'post_parent' => absint($parent_id),
    ));
    if (!is_wp_error($id) && $template) {
        update_post_meta($id, '_wp_page_template', $template);
    }
    return $id;
}

function ryi_create_default_pages() {
    $front_id = ryi_create_page('Home', 'home', 'front-page.php');
    ryi_create_page('About Us', 'about-us', 'templates/about-us.php');
    ryi_create_page('Our Team', 'our-team', 'templates/our-team.php');
    $services_id = ryi_create_page('Services', 'services', 'templates/services.php');
    ryi_create_page('Why Us', 'why-us', 'templates/why-us.php');
    ryi_create_page('Case Studies', 'case-studies', 'templates/case-studies.php');
    $blogs_id = ryi_create_page('Blogs', 'blogs', '');
    ryi_create_page('Careers', 'careers', 'templates/careers.php');
    ryi_create_page('Contact Us', 'contact-us', 'templates/contact-us.php');
    foreach (ryi_services() as $service) {
        ryi_create_page($service['kicker'], $service['slug'], 'templates/service-detail.php', $services_id);
    }
    if ($front_id && !is_wp_error($front_id)) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $front_id);
    }
    if ($blogs_id && !is_wp_error($blogs_id)) {
        update_option('page_for_posts', $blogs_id);
    }

    $menu = wp_get_nav_menu_object('Reach you in Main Menu');
    $menu_id = $menu ? $menu->term_id : wp_create_nav_menu('Reach you in Main Menu');
    if (!is_wp_error($menu_id)) {
        $about = get_page_by_path('about-us');
        $team = get_page_by_path('our-team');
        $why = get_page_by_path('why-us');
        $cases = get_page_by_path('case-studies');
        $careers = get_page_by_path('careers');
        $contact = get_page_by_path('contact-us');
        $menu_pages = array(
            'Home' => $front_id,
            'About Us' => $about ? $about->ID : 0,
            'Our Team' => $team ? $team->ID : 0,
            'Services' => $services_id,
            'Why Us' => $why ? $why->ID : 0,
            'Case Studies' => $cases ? $cases->ID : 0,
            'Blogs' => $blogs_id,
            'Careers' => $careers ? $careers->ID : 0,
            'Contact Us' => $contact ? $contact->ID : 0,
        );
        $existing_items = wp_get_nav_menu_items($menu_id);
        if (empty($existing_items)) {
            foreach ($menu_pages as $label => $page_id) {
                if ($page_id) {
                    wp_update_nav_menu_item($menu_id, 0, array('menu-item-title' => $label, 'menu-item-object-id' => $page_id, 'menu-item-object' => 'page', 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish'));
                }
            }
        }
        set_theme_mod('nav_menu_locations', array('primary' => $menu_id, 'footer' => $menu_id));
    }
}
