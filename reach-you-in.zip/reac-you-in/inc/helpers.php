<?php
/**
 * Front-end helpers.
 *
 * @package ReacYouIn
 */

if (!defined('ABSPATH')) {
    exit;
}

function ryi_defaults() {
    return array(
        'brand_name' => 'Reach you in',
        'contact_email' => get_option('admin_email'),
        'phone' => '+91 00000 00000',
        'address' => 'Digital-first team serving growing businesses worldwide',
        'consultation_url' => home_url('/contact-us/'),
        'home_video_url' => '',
        'hero_title' => 'We Turn Digital Marketing Into Business Growth',
        'hero_subtitle' => 'Strategy that connects. Creativity that stands out. Marketing that moves your business forward.',
        'hero_body' => 'We help businesses build powerful digital brands, reach the right audience, generate quality leads, and create meaningful growth through influencer marketing, social media marketing, paid advertising, creative design, and technical solutions.',
        'facebook' => '#',
        'instagram' => '#',
        'linkedin' => '#',
        'youtube' => '#',
    );
}

function ryi_options() {
    $saved = get_option('ryi_options', array());
    return wp_parse_args(is_array($saved) ? $saved : array(), ryi_defaults());
}

function ryi_option($key, $fallback = '') {
    $options = ryi_options();
    return isset($options[$key]) && $options[$key] !== '' ? $options[$key] : $fallback;
}

function ryi_logo() {
    $options = ryi_options();
    if (!empty($options['logo_id'])) {
        echo wp_get_attachment_image(absint($options['logo_id']), 'medium', false, array('class' => 'site-logo-img'));
        return;
    }
    if (has_custom_logo()) {
        the_custom_logo();
        return;
    }
    echo '<span class="site-logo-text">' . esc_html(ryi_option('brand_name', 'Reach you in')) . '</span>';
}

function ryi_button($label, $url = '', $variant = '') {
    $class = 'btn' . ($variant ? ' btn-' . sanitize_html_class($variant) : '');
    return '<a class="' . esc_attr($class) . '" href="' . esc_url($url ?: '#') . '">' . esc_html($label) . '</a>';
}

function ryi_text_animation($words = array(), $style = 'typing') {
    $words = $words ?: array('Strategy', 'Creativity', 'Technology', 'Growth');
    $class = 'text-animation text-animation-' . sanitize_html_class($style);
    echo '<div class="' . esc_attr($class) . '" aria-hidden="true">';
    foreach ($words as $word) {
        echo '<span>' . esc_html($word) . '</span>';
    }
    echo '</div>';
}

function ryi_client_slider() {
    $clients = new WP_Query(array(
        'post_type' => 'ryi_client',
        'posts_per_page' => -1,
        'orderby' => 'menu_order date',
        'order' => 'DESC',
    ));

    $items = array();
    if ($clients->have_posts()) {
        while ($clients->have_posts()) {
            $clients->the_post();
            if (has_post_thumbnail()) {
                $items[] = array(
                    'title' => get_the_title(),
                    'image' => get_the_post_thumbnail(get_the_ID(), 'medium', array('loading' => 'lazy')),
                );
            }
        }
        wp_reset_postdata();
    }

    if (!$items) {
        for ($i = 1; $i <= 18; $i++) {
            $items[] = array('title' => 'Client ' . $i, 'image' => '<span>Client ' . $i . '</span>');
        }
    }

    $slides = array_chunk($items, 9);
    ob_start();
    ?>
    <section class="section client-section section-dark">
        <?php ryi_text_animation(array('Trusted Brands', 'Growth Partners', 'Campaign Reach', 'Client Results'), 'marquee'); ?>
        <div class="container section-heading reveal">
            <p class="eyebrow">Our Clients</p>
            <h2>Brands We Help Move Forward</h2>
            <p>Upload client logos from the Client Logos section in the WordPress dashboard. The slider shows 9 logos at a time and loops automatically.</p>
        </div>
        <div class="container client-slider reveal <?php echo count($slides) > 1 ? 'has-many' : 'has-one'; ?>" style="--slide-count: <?php echo esc_attr(max(1, count($slides))); ?>;">
            <div class="client-track">
                <?php foreach ($slides as $slide) : ?>
                    <div class="client-slide">
                        <?php foreach ($slide as $client) : ?>
                            <div class="client-logo" title="<?php echo esc_attr($client['title']); ?>"><?php echo wp_kses_post($client['image']); ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}

function ryi_services() {
    return array(
        array('slug' => 'influencer-marketing', 'kicker' => 'Influencer Marketing', 'title' => 'Turn Influence Into Brand Trust', 'copy' => 'Connect with relevant creators and communities to introduce your brand to audiences that matter.', 'icon' => 'IM'),
        array('slug' => 'social-media-marketing', 'kicker' => 'Social Media Marketing', 'title' => 'Make Your Brand Impossible to Ignore', 'copy' => 'Build a consistent and engaging social media presence with strategic content, creative campaigns, audience engagement, and performance optimization.', 'icon' => 'SM'),
        array('slug' => 'paid-advertising', 'kicker' => 'Paid Advertising', 'title' => 'Reach the Right People at the Right Time', 'copy' => 'Put your business in front of potential customers with targeted paid advertising campaigns designed around your marketing objectives.', 'icon' => 'AD'),
        array('slug' => 'technical-solutions', 'kicker' => 'Technical Solutions', 'title' => 'Technology That Supports Your Marketing', 'copy' => 'Practical technical solutions for websites, tracking, integrations, performance, digital infrastructure, and marketing workflows.', 'icon' => 'TS'),
        array('slug' => 'graphic-designing', 'kicker' => 'Graphic Designing', 'title' => 'Give Your Brand a Visual Identity People Remember', 'copy' => 'Professional visual content that communicates your message clearly across social media, campaigns, and brand materials.', 'icon' => 'GD'),
        array('slug' => 'poster-designing', 'kicker' => 'Poster Designing', 'title' => 'Make Your Message Stand Out', 'copy' => 'Promote products, offers, events, announcements, and campaigns with sharp poster designs created to capture attention quickly.', 'icon' => 'PD'),
        array('slug' => 'ai-content-creation', 'kicker' => 'AI Content Creation', 'title' => 'Create More Content With Human-Led Quality', 'copy' => 'AI-assisted content workflows guided by strategy, brand voice, SEO thinking, and human review.', 'icon' => 'AI'),
    );
}

function ryi_fallback_menu() {
    $items = array(
        'Home' => home_url('/'),
        'About Us' => home_url('/about-us/'),
        'Our Team' => home_url('/our-team/'),
        'Services' => home_url('/services/'),
        'Why Us' => home_url('/why-us/'),
        'Case Studies' => home_url('/case-studies/'),
        'Blogs' => home_url('/blogs/'),
        'Careers' => home_url('/careers/'),
        'Contact Us' => home_url('/contact-us/'),
    );
    echo '<ul class="menu">';
    foreach ($items as $label => $url) {
        echo '<li><a href="' . esc_url($url) . '">' . esc_html($label) . '</a></li>';
    }
    echo '</ul>';
}

function ryi_service_by_slug($slug) {
    foreach (ryi_services() as $service) {
        if ($service['slug'] === $slug) {
            return $service;
        }
    }
    return null;
}

function ryi_page_hero($title, $subtitle = '', $kicker = 'Digital Growth Partner') {
    ?>
    <section class="sub-hero section-dark grid-bg banner-motion">
        <div class="container hero-grid">
            <div class="hero-copy reveal">
                <p class="eyebrow"><?php echo esc_html($kicker); ?></p>
                <h1><?php echo esc_html($title); ?></h1>
                <?php if ($subtitle) : ?>
                    <p class="lead"><?php echo esc_html($subtitle); ?></p>
                <?php endif; ?>
                <div class="hero-actions">
                    <?php echo ryi_button('Get a Free Consultation', ryi_option('consultation_url', home_url('/contact-us/'))); ?>
                    <?php echo ryi_button('Talk to Our Team', home_url('/contact-us/'), 'ghost-light'); ?>
                </div>
            </div>
            <div class="hero-panel reveal delay-2" aria-hidden="true">
                <span>Strategy</span><span>Creative</span><span>Influence</span><span>Technology</span>
            </div>
        </div>
    </section>
    <?php
}

function ryi_contact_form() {
    ob_start();
    $status = isset($_GET['contact']) ? sanitize_key(wp_unslash($_GET['contact'])) : '';
    if ($status === 'sent') {
        echo '<div class="notice success">Thank you. Your message has been sent.</div>';
    } elseif ($status === 'missing' || $status === 'invalid') {
        echo '<div class="notice error">Please check the required fields and try again.</div>';
    }
    ?>
    <form class="contact-form reveal" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="ryi_contact">
        <?php wp_nonce_field('ryi_contact', 'ryi_contact_nonce'); ?>
        <label>Name <input type="text" name="name" required></label>
        <label>Email <input type="email" name="email" required></label>
        <label>Phone <input type="text" name="phone"></label>
        <label>Service
            <select name="service">
                <option>Digital Marketing Services</option>
                <option>Influencer Marketing</option>
                <option>Social Media Marketing</option>
                <option>Paid Advertising</option>
                <option>Technical Solutions</option>
                <option>Graphic Designing</option>
                <option>Poster Designing</option>
                <option>AI Content Creation</option>
                <option>Careers</option>
            </select>
        </label>
        <label class="full">Message <textarea name="message" rows="6" required></textarea></label>
        <button class="btn full" type="submit">Send Message</button>
    </form>
    <?php
    return ob_get_clean();
}

function ryi_video_embed($url) {
    if (!$url) {
        return '';
    }
    $embed = wp_oembed_get($url);
    if ($embed) {
        return '<div class="video-frame">' . $embed . '</div>';
    }
    return '<div class="video-frame"><video controls src="' . esc_url($url) . '"></video></div>';
}
