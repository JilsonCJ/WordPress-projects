=== High Speed Performance Booster ===
Contributors: codex
Tags: performance, speed, cache, lazy load, optimization
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later

High Speed Performance Booster improves front-end performance with safe page caching, script deferring, image lazy loading, browser cache headers, resource hints, and WordPress cleanup.

== Description ==

This plugin is designed to reduce lag for normal visitors without changing theme files. It only caches public GET requests for visitors who are not logged in and avoids common dynamic pages such as cart, checkout, account, admin, login, REST API, search, preview, and password-protected pages.

Features:

* Static HTML page cache for anonymous visitors.
* Automatic cache clearing when posts, comments, or themes change.
* Defer non-critical JavaScript while keeping core dependencies like jQuery untouched.
* Add lazy loading and async decoding to images.
* Add resource hints for common external services.
* Send public browser cache headers.
* Remove small default WordPress front-end extras such as emoji scripts and embeds.
* Admin settings page under Settings > High Speed Booster.

== Installation ==

1. Upload the `high-speed-performance-booster` folder to `/wp-content/plugins/`.
2. Activate the plugin in WordPress Admin > Plugins.
3. Go to Settings > High Speed Booster.
4. Keep dynamic paths such as checkout, cart, account, login, and API paths in the exclusion list.
5. Clear the cache after major design or content changes.

== How It Works ==

Page cache:
When a public visitor opens a normal page, the plugin saves the final HTML into `wp-content/uploads/hspb-page-cache`. The next anonymous visitor gets that saved HTML immediately, so WordPress, the database, the theme, and other plugins do much less work.

Safe exclusions:
The plugin does not cache admin pages, logged-in users, POST requests, query-string URLs, search pages, preview pages, 404 pages, password-protected posts, WooCommerce cart sessions, checkout, account pages, logins, and REST API paths.

JavaScript deferring:
The plugin adds `defer` to non-critical script tags. This lets the browser load JavaScript without blocking the page from rendering. Important dependencies such as jQuery and WordPress core packages are skipped.

Image optimization:
Images receive `loading="lazy"` and `decoding="async"` so off-screen images wait until needed and do not block the first page view.

Browser cache headers:
For public cacheable pages, the plugin sends cache headers so browsers can reuse files and pages for a controlled amount of time.

Cleanup:
The plugin removes several small WordPress front-end extras that many sites do not need, reducing HTTP requests and page weight.

== Frequently Asked Questions ==

= Will this make every site instantly perfect? =

No. It improves common bottlenecks, but hosting quality, theme code, image size, database health, ads, tracking scripts, and page builder output still matter.

= Is it safe for WooCommerce? =

It avoids common WooCommerce cart, checkout, account, and session cookies. For stores, test carefully and add any custom dynamic pages to the exclusion list.

= Where is the cache stored? =

In `wp-content/uploads/hspb-page-cache`.

= How do I clear the cache? =

Go to Settings > High Speed Booster and click Clear page cache.

== Changelog ==

= 1.0.0 =
Initial release.
