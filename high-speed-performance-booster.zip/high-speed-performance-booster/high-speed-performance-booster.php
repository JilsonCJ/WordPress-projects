<?php
/**
 * Plugin Name: High Speed Performance Booster
 * Plugin URI: https://example.com/high-speed-performance-booster
 * Description: Improves front-end speed with safe page caching, asset optimization, browser cache headers, lazy loading, cleanup, and admin controls.
 * Version: 1.0.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author: Codex
 * License: GPL-2.0-or-later
 * Text Domain: high-speed-performance-booster
 */

if (!defined('ABSPATH')) {
    exit;
}

final class HSPB_High_Speed_Performance_Booster
{
    private const VERSION = '1.0.0';
    private const OPTION = 'hspb_settings';
    private const CACHE_DIR = 'hspb-page-cache';
    private const NONCE = 'hspb_clear_cache';

    private static ?self $instance = null;
    private array $settings = [];
    private ?string $cache_file = null;

    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct()
    {
        $this->settings = wp_parse_args((array) get_option(self::OPTION, []), self::defaults());

        register_activation_hook(__FILE__, [__CLASS__, 'activate']);
        register_deactivation_hook(__FILE__, [__CLASS__, 'deactivate']);

        add_action('admin_menu', [$this, 'add_admin_page']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_post_hspb_clear_cache', [$this, 'handle_clear_cache']);
        add_action('save_post', [$this, 'clear_cache']);
        add_action('deleted_post', [$this, 'clear_cache']);
        add_action('trashed_post', [$this, 'clear_cache']);
        add_action('comment_post', [$this, 'clear_cache']);
        add_action('wp_set_comment_status', [$this, 'clear_cache']);
        add_action('switch_theme', [$this, 'clear_cache']);

        if ($this->enabled('cleanup')) {
            $this->register_cleanup_hooks();
        }

        if ($this->enabled('lazy_load')) {
            add_filter('wp_get_attachment_image_attributes', [$this, 'add_image_loading_attributes'], 10, 3);
            add_filter('the_content', [$this, 'add_lazy_loading_to_content'], 20);
        }

        if ($this->enabled('defer_scripts')) {
            add_filter('script_loader_tag', [$this, 'defer_script_tag'], 10, 3);
        }

        if ($this->enabled('resource_hints')) {
            add_filter('wp_resource_hints', [$this, 'add_resource_hints'], 10, 2);
        }

        if ($this->enabled('cache_headers')) {
            add_action('send_headers', [$this, 'send_cache_headers']);
        }

        if ($this->enabled('page_cache')) {
            add_action('template_redirect', [$this, 'serve_cached_page'], 0);
            add_action('template_redirect', [$this, 'start_page_cache'], 1);
            add_action('shutdown', [$this, 'store_page_cache'], 0);
        }
    }

    public static function defaults(): array
    {
        return [
            'page_cache' => 1,
            'cache_ttl' => HOUR_IN_SECONDS,
            'defer_scripts' => 1,
            'lazy_load' => 1,
            'resource_hints' => 1,
            'cache_headers' => 1,
            'cleanup' => 1,
            'exclude_paths' => "/cart\n/checkout\n/my-account\n/wp-json\n/wp-admin\n/wp-login.php",
        ];
    }

    public static function activate(): void
    {
        if (!get_option(self::OPTION)) {
            add_option(self::OPTION, self::defaults());
        }

        self::ensure_cache_directory();
    }

    public static function deactivate(): void
    {
        self::clear_cache_static();
    }

    public function add_admin_page(): void
    {
        add_options_page(
            __('High Speed Booster', 'high-speed-performance-booster'),
            __('High Speed Booster', 'high-speed-performance-booster'),
            'manage_options',
            'hspb-settings',
            [$this, 'render_admin_page']
        );
    }

    public function register_settings(): void
    {
        register_setting('hspb_settings_group', self::OPTION, [
            'type' => 'array',
            'sanitize_callback' => [$this, 'sanitize_settings'],
            'default' => self::defaults(),
        ]);
    }

    public function sanitize_settings(array $input): array
    {
        $defaults = self::defaults();

        return [
            'page_cache' => empty($input['page_cache']) ? 0 : 1,
            'cache_ttl' => max(300, min(DAY_IN_SECONDS, absint($input['cache_ttl'] ?? $defaults['cache_ttl']))),
            'defer_scripts' => empty($input['defer_scripts']) ? 0 : 1,
            'lazy_load' => empty($input['lazy_load']) ? 0 : 1,
            'resource_hints' => empty($input['resource_hints']) ? 0 : 1,
            'cache_headers' => empty($input['cache_headers']) ? 0 : 1,
            'cleanup' => empty($input['cleanup']) ? 0 : 1,
            'exclude_paths' => sanitize_textarea_field($input['exclude_paths'] ?? $defaults['exclude_paths']),
        ];
    }

    public function render_admin_page(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $settings = wp_parse_args((array) get_option(self::OPTION, []), self::defaults());
        $cache_size = size_format($this->directory_size($this->cache_directory()));
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('High Speed Performance Booster', 'high-speed-performance-booster'); ?></h1>
            <p><?php esc_html_e('Enable practical performance improvements for anonymous visitors without changing your theme files.', 'high-speed-performance-booster'); ?></p>

            <form method="post" action="options.php">
                <?php settings_fields('hspb_settings_group'); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php esc_html_e('Page cache', 'high-speed-performance-booster'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[page_cache]" value="1" <?php checked($settings['page_cache'], 1); ?>>
                                <?php esc_html_e('Serve cached HTML to visitors who are not logged in.', 'high-speed-performance-booster'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="hspb-cache-ttl"><?php esc_html_e('Cache lifetime', 'high-speed-performance-booster'); ?></label></th>
                        <td>
                            <input id="hspb-cache-ttl" type="number" min="300" max="<?php echo esc_attr(DAY_IN_SECONDS); ?>" step="60" name="<?php echo esc_attr(self::OPTION); ?>[cache_ttl]" value="<?php echo esc_attr($settings['cache_ttl']); ?>">
                            <p class="description"><?php esc_html_e('Seconds. Default is 3600. Cache clears automatically when posts, comments, or theme settings change.', 'high-speed-performance-booster'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Front-end optimizations', 'high-speed-performance-booster'); ?></th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[defer_scripts]" value="1" <?php checked($settings['defer_scripts'], 1); ?>> <?php esc_html_e('Defer non-critical JavaScript', 'high-speed-performance-booster'); ?></label><br>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[lazy_load]" value="1" <?php checked($settings['lazy_load'], 1); ?>> <?php esc_html_e('Add lazy loading and async decoding to images', 'high-speed-performance-booster'); ?></label><br>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[resource_hints]" value="1" <?php checked($settings['resource_hints'], 1); ?>> <?php esc_html_e('Add resource hints for common external domains', 'high-speed-performance-booster'); ?></label><br>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[cache_headers]" value="1" <?php checked($settings['cache_headers'], 1); ?>> <?php esc_html_e('Send browser cache headers for public pages', 'high-speed-performance-booster'); ?></label><br>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[cleanup]" value="1" <?php checked($settings['cleanup'], 1); ?>> <?php esc_html_e('Remove small WordPress front-end extras like emoji scripts and embeds', 'high-speed-performance-booster'); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="hspb-exclude-paths"><?php esc_html_e('Never cache these paths', 'high-speed-performance-booster'); ?></label></th>
                        <td>
                            <textarea id="hspb-exclude-paths" name="<?php echo esc_attr(self::OPTION); ?>[exclude_paths]" rows="8" cols="60"><?php echo esc_textarea($settings['exclude_paths']); ?></textarea>
                            <p class="description"><?php esc_html_e('One path or URL fragment per line. Keep carts, checkouts, account pages, APIs, and logins excluded.', 'high-speed-performance-booster'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>

            <hr>
            <h2><?php esc_html_e('Cache tools', 'high-speed-performance-booster'); ?></h2>
            <p><?php printf(esc_html__('Current cache size: %s', 'high-speed-performance-booster'), esc_html($cache_size)); ?></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="hspb_clear_cache">
                <?php wp_nonce_field(self::NONCE); ?>
                <?php submit_button(__('Clear page cache', 'high-speed-performance-booster'), 'secondary'); ?>
            </form>
        </div>
        <?php
    }

    public function handle_clear_cache(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to clear this cache.', 'high-speed-performance-booster'));
        }

        check_admin_referer(self::NONCE);
        $this->clear_cache();
        wp_safe_redirect(add_query_arg('hspb-cache-cleared', '1', wp_get_referer() ?: admin_url('options-general.php?page=hspb-settings')));
        exit;
    }

    public function register_cleanup_hooks(): void
    {
        remove_action('wp_head', 'print_emoji_detection_script', 7);
        remove_action('admin_print_scripts', 'print_emoji_detection_script');
        remove_action('wp_print_styles', 'print_emoji_styles');
        remove_action('admin_print_styles', 'print_emoji_styles');
        remove_action('wp_head', 'wp_generator');
        remove_action('wp_head', 'wlwmanifest_link');
        remove_action('wp_head', 'rsd_link');
        remove_action('wp_head', 'wp_shortlink_wp_head');
        remove_action('wp_head', 'adjacent_posts_rel_link_wp_head');
        add_action('wp_footer', [$this, 'dequeue_embed_script']);
    }

    public function dequeue_embed_script(): void
    {
        if (!is_singular()) {
            wp_deregister_script('wp-embed');
        }
    }

    public function add_image_loading_attributes(array $attr): array
    {
        if (empty($attr['loading'])) {
            $attr['loading'] = 'lazy';
        }

        if (empty($attr['decoding'])) {
            $attr['decoding'] = 'async';
        }

        return $attr;
    }

    public function add_lazy_loading_to_content(string $content): string
    {
        if (stripos($content, '<img') === false) {
            return $content;
        }

        return preg_replace_callback('/<img\b(?![^>]*\bloading=)([^>]*)>/i', static function (array $matches): string {
            $tag = $matches[0];

            if (stripos($tag, ' loading=') === false) {
                $tag = preg_replace('/<img\b/i', '<img loading="lazy"', $tag, 1);
            }

            if (stripos($tag, ' decoding=') === false) {
                $tag = preg_replace('/<img\b/i', '<img decoding="async"', $tag, 1);
            }

            return $tag;
        }, $content) ?: $content;
    }

    public function defer_script_tag(string $tag, string $handle, string $src): string
    {
        if (is_admin() || !$src || stripos($tag, ' defer') !== false || stripos($tag, ' async') !== false) {
            return $tag;
        }

        $skip_handles = [
            'jquery',
            'jquery-core',
            'jquery-migrate',
            'wp-polyfill',
            'wp-hooks',
            'wp-i18n',
            'wp-element',
            'wp-components',
        ];

        if (in_array($handle, $skip_handles, true)) {
            return $tag;
        }

        return str_replace(' src=', ' defer src=', $tag);
    }

    public function add_resource_hints(array $urls, string $relation_type): array
    {
        if ($relation_type !== 'dns-prefetch' && $relation_type !== 'preconnect') {
            return $urls;
        }

        $extra = [
            'https://fonts.gstatic.com',
            'https://fonts.googleapis.com',
            'https://www.google-analytics.com',
            'https://www.googletagmanager.com',
        ];

        foreach ($extra as $url) {
            if (!in_array($url, $urls, true)) {
                $urls[] = $url;
            }
        }

        return $urls;
    }

    public function send_cache_headers(): void
    {
        if (!$this->can_cache_request()) {
            return;
        }

        $ttl = absint($this->settings['cache_ttl']);
        header('Cache-Control: public, max-age=' . $ttl . ', stale-while-revalidate=60');
        header('X-High-Speed-Booster: active');
    }

    public function serve_cached_page(): void
    {
        if (!$this->can_cache_request()) {
            return;
        }

        $file = $this->cache_file();
        if (!$file || !is_readable($file)) {
            return;
        }

        $ttl = absint($this->settings['cache_ttl']);
        if ((filemtime($file) + $ttl) < time()) {
            @unlink($file);
            return;
        }

        status_header(200);
        header('Content-Type: text/html; charset=' . get_option('blog_charset'));
        header('X-High-Speed-Booster-Cache: hit');
        readfile($file);
        exit;
    }

    public function start_page_cache(): void
    {
        if (!$this->can_cache_request()) {
            return;
        }

        $this->cache_file = $this->cache_file();
        if (!$this->cache_file) {
            return;
        }

        ob_start();
    }

    public function store_page_cache(): void
    {
        if (!$this->cache_file || !ob_get_level()) {
            return;
        }

        $html = ob_get_contents();
        if (!is_string($html) || strlen($html) < 255) {
            return;
        }

        $status = http_response_code();
        if ($status !== 200) {
            return;
        }

        self::ensure_cache_directory();
        file_put_contents($this->cache_file, $html, LOCK_EX);
    }

    public function clear_cache(): void
    {
        self::clear_cache_static();
    }

    private function can_cache_request(): bool
    {
        if (is_admin() || wp_doing_ajax() || wp_doing_cron() || is_user_logged_in()) {
            return false;
        }

        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        if ($method !== 'GET') {
            return false;
        }

        if (!empty($_GET) || is_search() || is_404() || is_preview() || post_password_required()) {
            return false;
        }

        if (!empty($_COOKIE)) {
            foreach (array_keys($_COOKIE) as $cookie_name) {
                if (preg_match('/^(wordpress_logged_in_|wp-postpass_|woocommerce_cart_hash|woocommerce_items_in_cart|wp_woocommerce_session_)/', (string) $cookie_name)) {
                    return false;
                }
            }
        }

        $uri = strtok($_SERVER['REQUEST_URI'] ?? '/', '?') ?: '/';
        foreach ($this->excluded_paths() as $path) {
            if ($path !== '' && stripos($uri, $path) !== false) {
                return false;
            }
        }

        return true;
    }

    private function excluded_paths(): array
    {
        $lines = preg_split('/\R/', (string) $this->settings['exclude_paths']) ?: [];
        return array_values(array_filter(array_map(static function (string $line): string {
            return trim($line);
        }, $lines)));
    }

    private function cache_file(): ?string
    {
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        $host = $_SERVER['HTTP_HOST'] ?? parse_url(home_url(), PHP_URL_HOST);
        $scheme = is_ssl() ? 'https' : 'http';
        $key = md5($scheme . '://' . $host . $uri);
        $directory = $this->cache_directory();

        return $directory ? trailingslashit($directory) . $key . '.html' : null;
    }

    private function enabled(string $key): bool
    {
        return !empty($this->settings[$key]);
    }

    private function cache_directory(): string
    {
        $upload = wp_upload_dir(null, false);
        return trailingslashit($upload['basedir']) . self::CACHE_DIR;
    }

    private static function ensure_cache_directory(): void
    {
        $upload = wp_upload_dir(null, false);
        $directory = trailingslashit($upload['basedir']) . self::CACHE_DIR;

        if (!is_dir($directory)) {
            wp_mkdir_p($directory);
        }

        $index = trailingslashit($directory) . 'index.html';
        if (!file_exists($index)) {
            file_put_contents($index, '');
        }
    }

    private static function clear_cache_static(): void
    {
        $upload = wp_upload_dir(null, false);
        $directory = trailingslashit($upload['basedir']) . self::CACHE_DIR;

        if (!is_dir($directory)) {
            return;
        }

        $files = glob(trailingslashit($directory) . '*.html') ?: [];
        foreach ($files as $file) {
            if (is_file($file) && basename($file) !== 'index.html') {
                @unlink($file);
            }
        }
    }

    private function directory_size(string $directory): int
    {
        if (!is_dir($directory)) {
            return 0;
        }

        $size = 0;
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, FilesystemIterator::SKIP_DOTS)
        );

        foreach ($files as $file) {
            if ($file->isFile()) {
                $size += $file->getSize();
            }
        }

        return $size;
    }
}

HSPB_High_Speed_Performance_Booster::instance();
