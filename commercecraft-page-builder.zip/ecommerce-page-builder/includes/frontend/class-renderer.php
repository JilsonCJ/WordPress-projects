<?php
/**
 * Frontend renderer.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Frontend;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Renderer {

	public static function init(): void {
		add_action( 'wp_head', array( self::class, 'output_global_css' ), 99 );
	}

	public static function output_global_css(): void {
		$css = ccpb()->design_system()->get_css_variables();

		if ( $css ) {
			echo '<style id="ccpb-globals">' . esc_html( $css ) . '</style>';
		}
	}
}
