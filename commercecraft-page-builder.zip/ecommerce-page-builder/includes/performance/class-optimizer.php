<?php
/**
 * Performance optimization.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Performance;

use CommerceCraft\Core\Document;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Optimizer {

	public static function init(): void {
		add_filter( 'wp_get_attachment_image_attributes', array( self::class, 'lazy_load_images' ), 10, 3 );
		add_action( 'wp_enqueue_scripts', array( self::class, 'defer_scripts' ), 999 );
	}

	/**
	 * @param array<string, string> $attr Attributes.
	 * @return array<string, string>
	 */
	public static function lazy_load_images( array $attr, \WP_Post $attachment, $size ): array {
		if ( is_singular() && Document::is_ccpb_enabled( get_the_ID() ) ) {
			$attr['loading'] = 'lazy';
			$attr['decoding'] = 'async';
		}

		return $attr;
	}

	public static function defer_scripts(): void {
		if ( ! is_singular() || ! Document::is_ccpb_enabled( get_the_ID() ) ) {
			return;
		}

		wp_script_add_data( 'ccpb-frontend', 'strategy', 'defer' );
	}
}
