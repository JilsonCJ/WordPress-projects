<?php
/**
 * Widget registry and rendering.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Widgets;

use CommerceCraft\Widgets\Content\Accordion;
use CommerceCraft\Widgets\Content\Button;
use CommerceCraft\Widgets\Content\Divider;
use CommerceCraft\Widgets\Content\Gallery;
use CommerceCraft\Widgets\Content\Heading;
use CommerceCraft\Widgets\Content\Html;
use CommerceCraft\Widgets\Content\Icon;
use CommerceCraft\Widgets\Content\Image;
use CommerceCraft\Widgets\Content\Rich_Text;
use CommerceCraft\Widgets\Content\Shortcode;
use CommerceCraft\Widgets\Content\Spacer;
use CommerceCraft\Widgets\Content\Tabs;
use CommerceCraft\Widgets\Content\Text;
use CommerceCraft\Widgets\Content\Video;
use CommerceCraft\Widgets\Ecommerce\Add_To_Cart;
use CommerceCraft\Widgets\Ecommerce\Category_Grid;
use CommerceCraft\Widgets\Ecommerce\Cross_Sells;
use CommerceCraft\Widgets\Ecommerce\Featured_Products;
use CommerceCraft\Widgets\Ecommerce\Mini_Cart;
use CommerceCraft\Widgets\Ecommerce\Product_Card;
use CommerceCraft\Widgets\Ecommerce\Product_Grid;
use CommerceCraft\Widgets\Ecommerce\Product_List;
use CommerceCraft\Widgets\Ecommerce\Product_Slider;
use CommerceCraft\Widgets\Ecommerce\Related_Products;
use CommerceCraft\Widgets\Ecommerce\Sale_Products;
use CommerceCraft\Widgets\Ecommerce\Upsells;
use CommerceCraft\Widgets\Extensions\Account_Dashboard;
use CommerceCraft\Widgets\Extensions\Cart_Drawer;
use CommerceCraft\Widgets\Extensions\Checkout_Billing;
use CommerceCraft\Widgets\Extensions\Checkout_Payment;
use CommerceCraft\Widgets\Extensions\Checkout_Shipping;
use CommerceCraft\Widgets\Extensions\Counter;
use CommerceCraft\Widgets\Extensions\Coupon_Box;
use CommerceCraft\Widgets\Extensions\Exit_Intent_Popup;
use CommerceCraft\Widgets\Extensions\Faq;
use CommerceCraft\Widgets\Extensions\Free_Shipping_Progress;
use CommerceCraft\Widgets\Extensions\Icon_Box;
use CommerceCraft\Widgets\Extensions\Login_Form;
use CommerceCraft\Widgets\Extensions\Pricing_Table;
use CommerceCraft\Widgets\Extensions\Progress_Bar;
use CommerceCraft\Widgets\Extensions\Social_Proof;
use CommerceCraft\Widgets\Extensions\Team;
use CommerceCraft\Widgets\Extensions\Testimonials;
use CommerceCraft\Widgets\Extensions\Timeline;
use CommerceCraft\Widgets\Extensions\Wishlist;
use CommerceCraft\Widgets\Forms\Contact_Form;
use CommerceCraft\Widgets\Forms\Newsletter_Form;
use CommerceCraft\Widgets\Layout\Column;
use CommerceCraft\Widgets\Layout\Container;
use CommerceCraft\Widgets\Layout\Row;
use CommerceCraft\Widgets\Marketing\Announcement_Bar;
use CommerceCraft\Widgets\Marketing\Countdown;
use CommerceCraft\Widgets\Marketing\Newsletter;
use CommerceCraft\Widgets\Marketing\Trust_Badges;
use CommerceCraft\Widgets\Navigation\Breadcrumbs;
use CommerceCraft\Widgets\Navigation\Footer_Builder;
use CommerceCraft\Widgets\Navigation\Header_Builder;
use CommerceCraft\Widgets\Navigation\Search;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Widget_Manager
 */
class Widget_Manager {

	/** @var array<string, Widget_Base> */
	private array $widgets = array();

	public function register( Widget_Base $widget ): void {
		$this->widgets[ $widget->get_name() ] = $widget;
	}

	public function get( string $name ): ?Widget_Base {
		return $this->widgets[ $name ] ?? null;
	}

	/**
	 * @return array<string, Widget_Base>
	 */
	public function get_all(): array {
		return $this->widgets;
	}

	public function register_defaults(): void {
		require_once CCPB_PLUGIN_DIR . 'includes/widgets/ecommerce/class-product-extensions.php';
		require_once CCPB_PLUGIN_DIR . 'includes/widgets/extensions/class-extended-widgets.php';

		$widgets = array(
			// Layout.
			new Container(),
			new Row(),
			new Column(),

			// Content.
			new Heading(),
			new Text(),
			new Rich_Text(),
			new Image(),
			new Gallery(),
			new Video(),
			new Button(),
			new Icon(),
			new Divider(),
			new Spacer(),
			new Tabs(),
			new Accordion(),
			new Html(),
			new Shortcode(),

			// Ecommerce.
			new Product_Grid(),
			new Product_Slider(),
			new Product_List(),
			new Featured_Products(),
			new Sale_Products(),
			new Related_Products(),
			new Upsells(),
			new Cross_Sells(),
			new Product_Card(),
			new Category_Grid(),
			new Add_To_Cart(),
			new Mini_Cart(),

			// Cart/Checkout placeholders via widgets.
			// Marketing.
			new Announcement_Bar(),
			new Countdown(),
			new Newsletter(),
			new Trust_Badges(),

			// Navigation.
			new Header_Builder(),
			new Footer_Builder(),
			new Breadcrumbs(),
			new Search(),

			// Forms.
			new Contact_Form(),
			new Newsletter_Form(),

			// Cart.
			new Cart_Drawer(),
			new Free_Shipping_Progress(),
			new Coupon_Box(),

			// Checkout.
			new Checkout_Billing(),
			new Checkout_Shipping(),
			new Checkout_Payment(),

			// Customer.
			new Login_Form(),
			new Account_Dashboard(),
			new Wishlist(),

			// Extended content.
			new Testimonials(),
			new Pricing_Table(),
			new Counter(),
			new Faq(),
			new Progress_Bar(),
			new Icon_Box(),
			new Team(),
			new Timeline(),
			new Social_Proof(),
			new Exit_Intent_Popup(),
		);

		foreach ( $widgets as $widget ) {
			$this->register( $widget );
		}

		do_action( 'ccpb/register_widgets', $this );
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public function get_editor_config(): array {
		$config = array();

		foreach ( $this->widgets as $widget ) {
			$config[] = $widget->to_editor_config();
		}

		return apply_filters( 'ccpb/editor_widgets', $config );
	}

	/**
	 * @param array<int, mixed> $elements Elements tree.
	 */
	public function render_tree( array $elements, int $post_id = 0 ): string {
		$html = '';

		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) || empty( $element['type'] ) ) {
				continue;
			}

			$widget = $this->get( (string) $element['type'] );

			if ( $widget ) {
				$html .= $widget->render( $element, $post_id );
			}
		}

		return $html;
	}
}
