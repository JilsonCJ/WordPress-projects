<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Ecommerce;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Category_Grid extends Widget_Base {
	protected string $name = 'category-grid';
	protected string $title = 'Category Grid';
	protected string $icon = 'category-grid';
	protected string $category = 'ecommerce';
	protected function get_default_settings(): array {
		return array( 'columns' => 4, 'limit' => 8, 'hideEmpty' => true, 'showCount' => true );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		if ( ! class_exists( 'WooCommerce' ) ) { return ''; }
		$s = $element['settings'];
		$terms = get_terms( array( 'taxonomy' => 'product_cat', 'number' => (int) $s['limit'], 'hide_empty' => ! empty( $s['hideEmpty'] ) ) );
		if ( is_wp_error( $terms ) || empty( $terms ) ) { return ''; }
		$html = sprintf( '<div class="ccpb-category-grid ccpb-cols-%d">', (int) $s['columns'] );
		foreach ( $terms as $term ) {
			$thumb_id = get_term_meta( $term->term_id, 'thumbnail_id', true );
			$img = $thumb_id ? wp_get_attachment_image( (int) $thumb_id, 'medium' ) : '';
			$count = ! empty( $s['showCount'] ) ? sprintf( '<span class="ccpb-cat-count">%d</span>', $term->count ) : '';
			$html .= sprintf( '<a href="%s" class="ccpb-category-card">%s<h4>%s</h4>%s</a>', esc_url( get_term_link( $term ) ), $img, esc_html( $term->name ), $count );
		}
		return $html . '</div>';
	}
}
