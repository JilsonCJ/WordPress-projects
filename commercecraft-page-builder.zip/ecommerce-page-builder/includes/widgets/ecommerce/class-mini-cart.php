<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Ecommerce;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Mini_Cart extends Widget_Base {
	protected string $name = 'mini-cart';
	protected string $title = 'Mini Cart';
	protected string $icon = 'mini-cart';
	protected string $category = 'ecommerce';
	protected function get_default_settings(): array {
		return array( 'style' => 'dropdown', 'showCount' => true, 'showTotal' => true );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		if ( ! class_exists( 'WooCommerce' ) || ! WC()->cart ) { return ''; }
		$count = WC()->cart->get_cart_contents_count();
		$total = WC()->cart->get_cart_total();
		return sprintf(
			'<div class="ccpb-mini-cart" data-ccpb-mini-cart><a href="%s" class="ccpb-mini-cart-toggle"><span class="ccpb-cart-icon"></span><span class="ccpb-cart-count">%d</span><span class="ccpb-cart-total">%s</span></a><div class="ccpb-mini-cart-dropdown">%s</div></div>',
			esc_url( wc_get_cart_url() ),
			$count,
			wp_kses_post( $total ),
			wp_kses_post( woocommerce_mini_cart() )
		);
	}
}
