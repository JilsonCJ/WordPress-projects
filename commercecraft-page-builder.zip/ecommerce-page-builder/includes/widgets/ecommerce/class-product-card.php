<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Ecommerce;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Product_Card extends Widget_Base {
	protected string $name = 'product-card';
	protected string $title = 'Product Card';
	protected string $icon = 'product-card';
	protected string $category = 'ecommerce';
	protected function get_default_settings(): array {
		return array( 'productId' => 0, 'showRating' => true, 'showCart' => true, 'showWishlist' => false, 'showQuickView' => false );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		if ( ! class_exists( 'WooCommerce' ) ) { return ''; }
		$id = (int) ( $element['settings']['productId'] ?: $post_id );
		$product = wc_get_product( $id );
		if ( ! $product ) { return ''; }
		return ( new Product_Grid() )->render_product_card( $product, $element['settings'] );
	}
}
