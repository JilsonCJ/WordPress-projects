<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Ecommerce;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Add_To_Cart extends Widget_Base {
	protected string $name = 'add-to-cart';
	protected string $title = 'Add to Cart';
	protected string $icon = 'cart';
	protected string $category = 'ecommerce';
	protected function get_default_settings(): array {
		return array( 'productId' => 0, 'style' => 'button', 'showQuantity' => true );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		if ( ! class_exists( 'WooCommerce' ) ) { return ''; }
		$id = (int) ( $element['settings']['productId'] ?: $post_id );
		global $product;
		$product = wc_get_product( $id );
		if ( ! $product ) { return ''; }
		ob_start();
		woocommerce_template_single_add_to_cart();
		return '<div class="ccpb-add-to-cart-widget">' . ob_get_clean() . '</div>';
	}
}
