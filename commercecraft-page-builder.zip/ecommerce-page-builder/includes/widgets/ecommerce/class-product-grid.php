<?php
/**
 * Product Grid widget.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Widgets\Ecommerce;

use CommerceCraft\Widgets\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Product_Grid extends Widget_Base {
	protected string $name = 'product-grid';
	protected string $title = 'Product Grid';
	protected string $icon = 'product-grid';
	protected string $category = 'ecommerce';
	protected array $keywords = array( 'woocommerce', 'shop', 'products' );

	protected function get_default_settings(): array {
		return array(
			'columns'   => 4,
			'rows'      => 2,
			'orderby'   => 'date',
			'order'     => 'DESC',
			'category'  => '',
			'tag'       => '',
			'onSale'    => false,
			'featured'  => false,
			'limit'     => 8,
			'showRating' => true,
			'showCart'  => true,
			'showBadge' => true,
		);
	}

	protected function register_controls(): array {
		return array(
			array( 'type' => 'number', 'name' => 'columns', 'label' => 'Columns', 'min' => 1, 'max' => 6 ),
			array( 'type' => 'number', 'name' => 'limit', 'label' => 'Products Limit' ),
			array( 'type' => 'select', 'name' => 'orderby', 'label' => 'Order By', 'options' => array( 'date' => 'Date', 'title' => 'Title', 'price' => 'Price', 'popularity' => 'Popularity', 'rating' => 'Rating' ) ),
			array( 'type' => 'toggle', 'name' => 'onSale', 'label' => 'On Sale Only' ),
			array( 'type' => 'toggle', 'name' => 'featured', 'label' => 'Featured Only' ),
		);
	}

	protected function render_content( array $element, int $post_id = 0 ): string {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return '<p class="ccpb-notice">' . esc_html__( 'WooCommerce is required.', 'commercecraft' ) . '</p>';
		}

		$s = $element['settings'];
		$args = array(
			'post_type'      => 'product',
			'posts_per_page' => (int) $s['limit'],
			'orderby'        => $s['orderby'],
			'order'          => $s['order'],
			'post_status'    => 'publish',
		);

		if ( ! empty( $s['category'] ) ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'product_cat',
				'field'    => 'slug',
				'terms'    => $s['category'],
			);
		}

		if ( ! empty( $s['onSale'] ) ) {
			$args['post__in'] = array_merge( array( 0 ), wc_get_product_ids_on_sale() );
		}

		if ( ! empty( $s['featured'] ) ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'product_visibility',
				'field'    => 'name',
				'terms'    => 'featured',
			);
		}

		$query = new \WP_Query( $args );

		if ( ! $query->have_posts() ) {
			return '';
		}

		$html = sprintf( '<div class="ccpb-product-grid ccpb-cols-%d">', (int) $s['columns'] );

		while ( $query->have_posts() ) {
			$query->the_post();
			$product = wc_get_product( get_the_ID() );

			if ( ! $product ) {
				continue;
			}

			$html .= $this->render_product_card( $product, $s );
		}

		wp_reset_postdata();

		return $html . '</div>';
	}

	/**
	 * @param \WC_Product          $product Product.
	 * @param array<string, mixed> $settings Settings.
	 */
	public function render_product_card( \WC_Product $product, array $settings ): string {
		$id    = $product->get_id();
		$image = $product->get_image( 'woocommerce_thumbnail' );
		$badge = '';

		if ( ! empty( $settings['showBadge'] ) && $product->is_on_sale() ) {
			$badge = '<span class="ccpb-sale-badge">' . esc_html__( 'Sale', 'commercecraft' ) . '</span>';
		}

		$rating = '';
		if ( ! empty( $settings['showRating'] ) && wc_review_ratings_enabled() ) {
			$rating = wc_get_rating_html( $product->get_average_rating() );
		}

		$cart = '';
		if ( ! empty( $settings['showCart'] ) ) {
			$cart = sprintf(
				'<a href="%s" data-product_id="%d" class="ccpb-add-to-cart button add_to_cart_button">%s</a>',
				esc_url( $product->add_to_cart_url() ),
				$id,
				esc_html( $product->add_to_cart_text() )
			);
		}

		return sprintf(
			'<article class="ccpb-product-card"><a href="%1$s" class="ccpb-product-image">%2$s%3$s</a><h3 class="ccpb-product-title"><a href="%1$s">%4$s</a></h3>%5$s<div class="ccpb-product-price">%6$s</div>%7$s</article>',
			esc_url( get_permalink( $id ) ),
			$image,
			$badge,
			esc_html( $product->get_name() ),
			$rating,
			wp_kses_post( $product->get_price_html() ),
			$cart
		);
	}
}
