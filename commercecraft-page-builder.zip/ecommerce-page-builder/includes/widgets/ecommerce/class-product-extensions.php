<?php
/**
 * Extension widget stubs for additional spec widgets.
 * Register via ccpb_register_widget() or the ccpb/register_widgets hook.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Widgets\Ecommerce;

use CommerceCraft\Widgets\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Product List widget. */
class Product_List extends Product_Grid {
	protected string $name = 'product-list';
	protected string $title = 'Product List';
	protected string $icon = 'list';
	protected function get_default_settings(): array {
		$s = parent::get_default_settings();
		$s['columns'] = 1;
		return $s;
	}
}

/** Featured Products widget. */
class Featured_Products extends Product_Grid {
	protected string $name = 'featured-products';
	protected string $title = 'Featured Products';
	protected string $icon = 'star';
	protected function get_default_settings(): array {
		$s = parent::get_default_settings();
		$s['featured'] = true;
		return $s;
	}
}

/** Sale Products widget. */
class Sale_Products extends Product_Grid {
	protected string $name = 'sale-products';
	protected string $title = 'Sale Products';
	protected string $icon = 'sale';
	protected function get_default_settings(): array {
		$s = parent::get_default_settings();
		$s['onSale'] = true;
		return $s;
	}
}

/** Related Products widget. */
class Related_Products extends Widget_Base {
	protected string $name = 'related-products';
	protected string $title = 'Related Products';
	protected string $icon = 'related';
	protected string $category = 'ecommerce';
	protected function get_default_settings(): array {
		return array( 'limit' => 4, 'columns' => 4 );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		if ( ! class_exists( 'WooCommerce' ) || ! $post_id ) {
			return '';
		}
		$grid = new Product_Grid();
		$related = wc_get_related_products( $post_id, (int) $element['settings']['limit'] );
		if ( empty( $related ) ) {
			return '';
		}
		$html = sprintf( '<div class="ccpb-product-grid ccpb-cols-%d">', (int) $element['settings']['columns'] );
		foreach ( $related as $id ) {
			$product = wc_get_product( $id );
			if ( $product ) {
				$html .= $grid->render_product_card( $product, $element['settings'] );
			}
		}
		return $html . '</div>';
	}
}

/** Upsells widget. */
class Upsells extends Related_Products {
	protected string $name = 'upsells';
	protected string $title = 'Upsells';
	protected function render_content( array $element, int $post_id = 0 ): string {
		if ( ! class_exists( 'WooCommerce' ) || ! $post_id ) {
			return '';
		}
		$product = wc_get_product( $post_id );
		if ( ! $product ) {
			return '';
		}
		$upsells = $product->get_upsell_ids();
		if ( empty( $upsells ) ) {
			return '';
		}
		$grid = new Product_Grid();
		$html = sprintf( '<div class="ccpb-product-grid ccpb-cols-%d">', (int) $element['settings']['columns'] );
		foreach ( array_slice( $upsells, 0, (int) $element['settings']['limit'] ) as $id ) {
			$p = wc_get_product( $id );
			if ( $p ) {
				$html .= $grid->render_product_card( $p, $element['settings'] );
			}
		}
		return $html . '</div>';
	}
}

/** Cross Sells widget. */
class Cross_Sells extends Upsells {
	protected string $name = 'cross-sells';
	protected string $title = 'Cross Sells';
	protected function render_content( array $element, int $post_id = 0 ): string {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return '';
		}
		$ids = WC()->cart->get_cross_sells();
		if ( empty( $ids ) ) {
			return '';
		}
		$grid = new Product_Grid();
		$html = sprintf( '<div class="ccpb-product-grid ccpb-cols-%d">', (int) $element['settings']['columns'] );
		foreach ( array_slice( $ids, 0, (int) $element['settings']['limit'] ) as $id ) {
			$p = wc_get_product( $id );
			if ( $p ) {
				$html .= $grid->render_product_card( $p, $element['settings'] );
			}
		}
		return $html . '</div>';
	}
}
