<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Ecommerce;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Product_Slider extends Product_Grid {
	protected string $name = 'product-slider';
	protected string $title = 'Product Slider';
	protected string $icon = 'slider';
	protected function get_default_settings(): array {
		$s = parent::get_default_settings();
		$s['autoplay'] = true;
		$s['slides'] = 4;
		return $s;
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$grid = parent::render_content( $element, $post_id );
		return $grid ? '<div class="ccpb-product-slider" data-ccpb-slider>' . $grid . '</div>' : '';
	}
}
