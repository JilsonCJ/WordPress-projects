<?php
/**
 * Additional widgets — cart, checkout, customer, content.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Widgets\Extensions;

use CommerceCraft\Widgets\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ─── Cart Widgets ───────────────────────────────────────────────

class Cart_Drawer extends Widget_Base {
	protected string $name = 'cart-drawer';
	protected string $title = 'Cart Drawer';
	protected string $icon = 'cart-drawer';
	protected string $category = 'cart';
	protected function render_content( array $element, int $post_id = 0 ): string {
		return class_exists( 'WooCommerce' ) ? '<div class="ccpb-cart-drawer" data-ccpb-cart-drawer><button class="ccpb-cart-drawer-toggle">Cart</button><aside class="ccpb-cart-drawer-panel">' . woocommerce_mini_cart() . '</aside></div>' : '';
	}
}

class Free_Shipping_Progress extends Widget_Base {
	protected string $name = 'free-shipping-progress';
	protected string $title = 'Free Shipping Progress';
	protected string $icon = 'shipping';
	protected string $category = 'cart';
	protected function get_default_settings(): array {
		return array( 'threshold' => 50 );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) { return ''; }
		$threshold = (float) $element['settings']['threshold'];
		$total     = (float) WC()->cart->get_subtotal();
		$percent   = min( 100, ( $total / $threshold ) * 100 );
		$remaining = max( 0, $threshold - $total );
		return sprintf(
			'<div class="ccpb-shipping-progress"><div class="ccpb-progress-bar" style="width:%1$s%%"></div><p>%2$s</p></div>',
			esc_attr( (string) $percent ),
			$remaining > 0
				? sprintf( esc_html__( 'Add %s more for free shipping!', 'commercecraft' ), wc_price( $remaining ) )
				: esc_html__( 'You qualify for free shipping!', 'commercecraft' )
		);
	}
}

class Coupon_Box extends Widget_Base {
	protected string $name = 'coupon-box';
	protected string $title = 'Coupon Box';
	protected string $icon = 'coupon';
	protected string $category = 'cart';
	protected function render_content( array $element, int $post_id = 0 ): string {
		if ( ! function_exists( 'woocommerce_coupon_field' ) ) { return ''; }
		ob_start();
		woocommerce_coupon_field();
		return '<div class="ccpb-coupon-box">' . ob_get_clean() . '</div>';
	}
}

// ─── Checkout Widgets ───────────────────────────────────────────

class Checkout_Billing extends Widget_Base {
	protected string $name = 'checkout-billing';
	protected string $title = 'Billing Form';
	protected string $icon = 'billing';
	protected string $category = 'checkout';
	protected function render_content( array $element, int $post_id = 0 ): string {
		if ( ! function_exists( 'WC' ) ) { return ''; }
		ob_start();
		woocommerce_checkout_billing();
		return '<div class="ccpb-checkout-billing">' . ob_get_clean() . '</div>';
	}
}

class Checkout_Shipping extends Widget_Base {
	protected string $name = 'checkout-shipping';
	protected string $title = 'Shipping Form';
	protected string $icon = 'shipping-form';
	protected string $category = 'checkout';
	protected function render_content( array $element, int $post_id = 0 ): string {
		if ( ! function_exists( 'WC' ) ) { return ''; }
		ob_start();
		woocommerce_checkout_shipping();
		return '<div class="ccpb-checkout-shipping">' . ob_get_clean() . '</div>';
	}
}

class Checkout_Payment extends Widget_Base {
	protected string $name = 'checkout-payment';
	protected string $title = 'Payment Methods';
	protected string $icon = 'payment';
	protected string $category = 'checkout';
	protected function render_content( array $element, int $post_id = 0 ): string {
		if ( ! function_exists( 'WC' ) ) { return ''; }
		ob_start();
		woocommerce_checkout_payment();
		return '<div class="ccpb-checkout-payment">' . ob_get_clean() . '</div>';
	}
}

// ─── Customer Widgets ───────────────────────────────────────────

class Login_Form extends Widget_Base {
	protected string $name = 'login-form';
	protected string $title = 'Login Form';
	protected string $icon = 'login';
	protected string $category = 'customer';
	protected function render_content( array $element, int $post_id = 0 ): string {
		if ( is_user_logged_in() ) {
			return '<p>' . esc_html__( 'You are already logged in.', 'commercecraft' ) . '</p>';
		}
		return '<div class="ccpb-login-form">' . wp_login_form( array( 'echo' => false ) ) . '</div>';
	}
}

class Account_Dashboard extends Widget_Base {
	protected string $name = 'account-dashboard';
	protected string $title = 'Account Dashboard';
	protected string $icon = 'account';
	protected string $category = 'customer';
	protected function render_content( array $element, int $post_id = 0 ): string {
		if ( ! is_user_logged_in() ) {
			return '<p>' . esc_html__( 'Please log in to view your account.', 'commercecraft' ) . '</p>';
		}
		if ( function_exists( 'wc_get_account_menu_items' ) ) {
			$html = '<nav class="ccpb-account-nav"><ul>';
			foreach ( wc_get_account_menu_items() as $endpoint => $label ) {
				$html .= sprintf( '<li><a href="%s">%s</a></li>', esc_url( wc_get_account_endpoint_url( $endpoint ) ), esc_html( $label ) );
			}
			return $html . '</ul></nav>';
		}
		return '';
	}
}

class Wishlist extends Widget_Base {
	protected string $name = 'wishlist';
	protected string $title = 'Wishlist';
	protected string $icon = 'wishlist';
	protected string $category = 'customer';
	protected function render_content( array $element, int $post_id = 0 ): string {
		return '<div class="ccpb-wishlist" data-ccpb-wishlist><p>' . esc_html__( 'Wishlist items will appear here.', 'commercecraft' ) . '</p></div>';
	}
}

// ─── Content Widgets ────────────────────────────────────────────

class Testimonials extends Widget_Base {
	protected string $name = 'testimonials';
	protected string $title = 'Testimonials';
	protected string $icon = 'testimonials';
	protected string $category = 'content';
	protected function get_default_settings(): array {
		return array( 'items' => array(
			array( 'name' => 'Jane Doe', 'text' => 'Amazing products and fast delivery!', 'rating' => 5 ),
			array( 'name' => 'John Smith', 'text' => 'Best online shopping experience.', 'rating' => 5 ),
		) );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$html = '<div class="ccpb-testimonials">';
		foreach ( $element['settings']['items'] as $item ) {
			$stars = str_repeat( '★', (int) ( $item['rating'] ?? 5 ) );
			$html .= sprintf(
				'<blockquote class="ccpb-testimonial"><div class="ccpb-stars">%s</div><p>%s</p><cite>— %s</cite></blockquote>',
				esc_html( $stars ),
				esc_html( $item['text'] ?? '' ),
				esc_html( $item['name'] ?? '' )
			);
		}
		return $html . '</div>';
	}
}

class Pricing_Table extends Widget_Base {
	protected string $name = 'pricing-table';
	protected string $title = 'Pricing Table';
	protected string $icon = 'pricing';
	protected string $category = 'content';
	protected function get_default_settings(): array {
		return array( 'plans' => array(
			array( 'name' => 'Basic', 'price' => '$9', 'features' => array( 'Feature 1', 'Feature 2' ) ),
			array( 'name' => 'Pro', 'price' => '$29', 'features' => array( 'All Basic', 'Feature 3', 'Feature 4' ) ),
		) );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$html = '<div class="ccpb-pricing-table">';
		foreach ( $element['settings']['plans'] as $plan ) {
			$features = '';
			foreach ( $plan['features'] ?? array() as $f ) {
				$features .= '<li>' . esc_html( $f ) . '</li>';
			}
			$html .= sprintf(
				'<div class="ccpb-pricing-plan"><h3>%s</h3><div class="ccpb-price">%s</div><ul>%s</ul><a href="#" class="ccpb-button ccpb-button-primary">Choose Plan</a></div>',
				esc_html( $plan['name'] ?? '' ),
				esc_html( $plan['price'] ?? '' ),
				$features
			);
		}
		return $html . '</div>';
	}
}

class Counter extends Widget_Base {
	protected string $name = 'counter';
	protected string $title = 'Counter';
	protected string $icon = 'counter';
	protected string $category = 'content';
	protected function get_default_settings(): array {
		return array( 'number' => 1000, 'suffix' => '+', 'label' => 'Happy Customers' );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$s = $element['settings'];
		return sprintf(
			'<div class="ccpb-counter" data-ccpb-counter data-target="%1$d"><span class="ccpb-counter-number">0</span><span class="ccpb-counter-suffix">%2$s</span><span class="ccpb-counter-label">%3$s</span></div>',
			(int) $s['number'],
			esc_html( $s['suffix'] ?? '' ),
			esc_html( $s['label'] ?? '' )
		);
	}
}

class Faq extends Widget_Base {
	protected string $name = 'faq';
	protected string $title = 'FAQ';
	protected string $icon = 'faq';
	protected string $category = 'content';
	protected function get_default_settings(): array {
		return array( 'items' => array(
			array( 'question' => 'What is your return policy?', 'answer' => 'We offer 30-day free returns on all orders.' ),
			array( 'question' => 'How long does shipping take?', 'answer' => 'Standard shipping takes 3-5 business days.' ),
		) );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$html = '<div class="ccpb-faq" data-ccpb-accordion>';
		foreach ( $element['settings']['items'] as $item ) {
			$html .= sprintf(
				'<details class="ccpb-accordion-item"><summary>%s</summary><div class="ccpb-accordion-content">%s</div></details>',
				esc_html( $item['question'] ?? '' ),
				wp_kses_post( $item['answer'] ?? '' )
			);
		}
		return $html . '</div>';
	}
}

class Progress_Bar extends Widget_Base {
	protected string $name = 'progress-bar';
	protected string $title = 'Progress Bar';
	protected string $icon = 'progress';
	protected string $category = 'content';
	protected function get_default_settings(): array {
		return array( 'percent' => 75, 'label' => 'Progress', 'color' => '#2563eb' );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$s = $element['settings'];
		return sprintf(
			'<div class="ccpb-progress"><label>%s</label><div class="ccpb-progress-track"><div class="ccpb-progress-fill" style="width:%d%%;background:%s"></div></div></div>',
			esc_html( $s['label'] ?? '' ),
			(int) $s['percent'],
			esc_attr( $s['color'] ?? '#2563eb' )
		);
	}
}

class Icon_Box extends Widget_Base {
	protected string $name = 'icon-box';
	protected string $title = 'Icon Box';
	protected string $icon = 'icon-box';
	protected string $category = 'content';
	protected function get_default_settings(): array {
		return array( 'icon' => 'star', 'title' => 'Feature Title', 'description' => 'Feature description goes here.' );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$s = $element['settings'];
		return sprintf(
			'<div class="ccpb-icon-box"><div class="ccpb-icon-box-icon ccpb-icon-%1$s"></div><h4>%2$s</h4><p>%3$s</p></div>',
			esc_attr( $s['icon'] ),
			esc_html( $s['title'] ),
			esc_html( $s['description'] )
		);
	}
}

class Team extends Widget_Base {
	protected string $name = 'team';
	protected string $title = 'Team';
	protected string $icon = 'team';
	protected string $category = 'content';
	protected function get_default_settings(): array {
		return array( 'members' => array(
			array( 'name' => 'Alex Johnson', 'role' => 'CEO', 'image' => '' ),
			array( 'name' => 'Sam Lee', 'role' => 'Designer', 'image' => '' ),
		) );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$html = '<div class="ccpb-team">';
		foreach ( $element['settings']['members'] as $m ) {
			$img = ! empty( $m['image'] ) ? sprintf( '<img src="%s" alt="%s"/>', esc_url( $m['image'] ), esc_attr( $m['name'] ) ) : '<div class="ccpb-team-placeholder"></div>';
			$html .= sprintf( '<div class="ccpb-team-member">%s<h4>%s</h4><span>%s</span></div>', $img, esc_html( $m['name'] ), esc_html( $m['role'] ) );
		}
		return $html . '</div>';
	}
}

class Timeline extends Widget_Base {
	protected string $name = 'timeline';
	protected string $title = 'Timeline';
	protected string $icon = 'timeline';
	protected string $category = 'content';
	protected function get_default_settings(): array {
		return array( 'events' => array(
			array( 'date' => '2024', 'title' => 'Founded', 'description' => 'Our store was born.' ),
			array( 'date' => '2025', 'title' => 'Expanded', 'description' => 'Opened international shipping.' ),
		) );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$html = '<div class="ccpb-timeline">';
		foreach ( $element['settings']['events'] as $ev ) {
			$html .= sprintf(
				'<div class="ccpb-timeline-event"><time>%s</time><h4>%s</h4><p>%s</p></div>',
				esc_html( $ev['date'] ?? '' ),
				esc_html( $ev['title'] ?? '' ),
				esc_html( $ev['description'] ?? '' )
			);
		}
		return $html . '</div>';
	}
}

class Social_Proof extends Widget_Base {
	protected string $name = 'social-proof';
	protected string $title = 'Social Proof';
	protected string $icon = 'social-proof';
	protected string $category = 'marketing';
	protected function get_default_settings(): array {
		return array( 'message' => 'Sarah from New York just purchased this item', 'interval' => 5 );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$s = $element['settings'];
		return sprintf(
			'<div class="ccpb-social-proof" data-interval="%d"><p>%s</p></div>',
			(int) $s['interval'],
			esc_html( $s['message'] )
		);
	}
}

class Exit_Intent_Popup extends Widget_Base {
	protected string $name = 'exit-intent';
	protected string $title = 'Exit Intent Popup';
	protected string $icon = 'exit-intent';
	protected string $category = 'marketing';
	protected function get_default_settings(): array {
		return array( 'title' => 'Wait! Before you go...', 'content' => 'Get 10% off your first order!', 'buttonText' => 'Get Discount' );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$s = $element['settings'];
		return sprintf(
			'<div class="ccpb-exit-intent" data-ccpb-exit-intent style="display:none"><div class="ccpb-popup-overlay"></div><div class="ccpb-popup-content"><h3>%s</h3><p>%s</p><button class="ccpb-button ccpb-button-primary">%s</button></div></div>',
			esc_html( $s['title'] ),
			esc_html( $s['content'] ),
			esc_html( $s['buttonText'] )
		);
	}
}
