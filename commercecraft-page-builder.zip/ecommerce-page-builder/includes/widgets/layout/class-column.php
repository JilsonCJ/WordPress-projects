<?php
/**
 * Column widget.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Widgets\Layout;

use CommerceCraft\Widgets\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Column extends Widget_Base {
	protected string $name = 'column';
	protected string $title = 'Column';
	protected string $icon = 'column';
	protected string $category = 'layout';
	protected bool $is_container = true;

	protected function get_default_settings(): array {
		return array(
			'width'      => '50',
			'widthUnit'  => '%',
			'flexGrow'   => '0',
			'flexShrink' => '1',
			'flexBasis'  => 'auto',
		);
	}

	protected function render_content( array $element, int $post_id = 0 ): string {
		return '';
	}
}
