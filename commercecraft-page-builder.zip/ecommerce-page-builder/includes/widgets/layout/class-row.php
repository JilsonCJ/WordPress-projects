<?php
/**
 * Row widget.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Widgets\Layout;

use CommerceCraft\Widgets\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Row extends Widget_Base {
	protected string $name = 'row';
	protected string $title = 'Row';
	protected string $icon = 'row';
	protected string $category = 'layout';
	protected bool $is_container = true;

	protected function get_default_settings(): array {
		return array(
			'columns'      => 2,
			'gap'          => '20',
			'equalHeight'  => false,
			'wrap'         => 'wrap',
			'justifyContent' => 'flex-start',
			'alignItems'   => 'stretch',
		);
	}

	protected function render_content( array $element, int $post_id = 0 ): string {
		return '';
	}
}
