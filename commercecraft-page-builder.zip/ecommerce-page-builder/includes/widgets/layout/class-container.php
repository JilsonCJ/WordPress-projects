<?php
/**
 * Container widget.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Widgets\Layout;

use CommerceCraft\Widgets\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Container extends Widget_Base {
	protected string $name = 'container';
	protected string $title = 'Container';
	protected string $icon = 'container';
	protected string $category = 'layout';
	protected bool $is_container = true;

	protected function get_default_settings(): array {
		return array(
			'width'       => 'boxed',
			'minHeight'   => '',
			'display'     => 'flex',
			'flexDirection' => 'column',
			'justifyContent' => 'flex-start',
			'alignItems'  => 'stretch',
			'gap'         => '0',
			'position'    => 'relative',
			'sticky'      => false,
			'overflow'    => 'visible',
			'zIndex'      => '',
		);
	}

	protected function register_controls(): array {
		return array(
			array( 'type' => 'select', 'name' => 'width', 'label' => 'Width', 'options' => array( 'boxed' => 'Boxed', 'full' => 'Full Width' ) ),
			array( 'type' => 'select', 'name' => 'display', 'label' => 'Display', 'options' => array( 'flex' => 'Flexbox', 'grid' => 'Grid', 'block' => 'Block' ) ),
			array( 'type' => 'toggle', 'name' => 'sticky', 'label' => 'Sticky' ),
		);
	}

	protected function render_content( array $element, int $post_id = 0 ): string {
		return '';
	}
}
