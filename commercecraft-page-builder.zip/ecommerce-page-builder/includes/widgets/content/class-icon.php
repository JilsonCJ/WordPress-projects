<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Content;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Icon extends Widget_Base {
	protected string $name = 'icon';
	protected string $title = 'Icon';
	protected string $icon = 'icon';
	protected string $category = 'content';
	protected function get_default_settings(): array {
		return array( 'icon' => 'star', 'size' => '24', 'color' => '#333' );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$s = $element['settings'];
		return sprintf( '<span class="ccpb-icon ccpb-icon-%1$s" style="font-size:%2$spx;color:%3$s"></span>', esc_attr( $s['icon'] ), esc_attr( $s['size'] ), esc_attr( $s['color'] ) );
	}
}
