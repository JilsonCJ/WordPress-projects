<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Content;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Accordion extends Widget_Base {
	protected string $name = 'accordion';
	protected string $title = 'Accordion';
	protected string $icon = 'accordion';
	protected string $category = 'content';
	protected function get_default_settings(): array {
		return array( 'items' => array( array( 'title' => 'Question 1', 'content' => 'Answer 1' ) ) );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$items = $element['settings']['items'] ?? array();
		$html = '<div class="ccpb-accordion" data-ccpb-accordion>';
		foreach ( $items as $item ) {
			$html .= sprintf( '<details class="ccpb-accordion-item"><summary>%s</summary><div class="ccpb-accordion-content">%s</div></details>', esc_html( $item['title'] ?? '' ), wp_kses_post( $item['content'] ?? '' ) );
		}
		return $html . '</div>';
	}
}
