<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Content;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Divider extends Widget_Base {
	protected string $name = 'divider';
	protected string $title = 'Divider';
	protected string $icon = 'divider';
	protected string $category = 'content';
	protected function get_default_settings(): array {
		return array( 'style' => 'solid', 'width' => '100', 'color' => '#ddd', 'thickness' => '1' );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$s = $element['settings'];
		return sprintf( '<hr class="ccpb-divider" style="width:%1$s%%;border-top:%2$spx %3$s %4$s"/>', esc_attr( $s['width'] ), esc_attr( $s['thickness'] ), esc_attr( $s['style'] ), esc_attr( $s['color'] ) );
	}
}
