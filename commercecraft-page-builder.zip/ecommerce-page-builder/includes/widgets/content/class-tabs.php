<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Content;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Tabs extends Widget_Base {
	protected string $name = 'tabs';
	protected string $title = 'Tabs';
	protected string $icon = 'tabs';
	protected string $category = 'content';
	protected function get_default_settings(): array {
		return array( 'items' => array( array( 'title' => 'Tab 1', 'content' => 'Content 1' ), array( 'title' => 'Tab 2', 'content' => 'Content 2' ) ) );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$items = $element['settings']['items'] ?? array();
		if ( empty( $items ) ) { return ''; }
		$html = '<div class="ccpb-tabs" data-ccpb-tabs>';
		$html .= '<div class="ccpb-tabs-nav">';
		foreach ( $items as $i => $item ) {
			$html .= sprintf( '<button class="ccpb-tab-btn%s" data-tab="%d">%s</button>', 0 === $i ? ' active' : '', $i, esc_html( $item['title'] ?? '' ) );
		}
		$html .= '</div><div class="ccpb-tabs-panels">';
		foreach ( $items as $i => $item ) {
			$html .= sprintf( '<div class="ccpb-tab-panel%s" data-panel="%d">%s</div>', 0 === $i ? ' active' : '', $i, wp_kses_post( $item['content'] ?? '' ) );
		}
		return $html . '</div></div>';
	}
}
