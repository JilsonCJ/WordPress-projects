<?php
/**
 * Heading widget.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Widgets\Content;

use CommerceCraft\Widgets\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Heading extends Widget_Base {
	protected string $name = 'heading';
	protected string $title = 'Heading';
	protected string $icon = 'heading';
	protected string $category = 'content';
	protected array $keywords = array( 'title', 'h1', 'h2' );

	protected function get_default_settings(): array {
		return array(
			'text'    => 'Add Your Heading',
			'tag'     => 'h2',
			'align'   => 'left',
			'dynamic' => '',
		);
	}

	protected function register_controls(): array {
		return array(
			array( 'type' => 'text', 'name' => 'text', 'label' => 'Text' ),
			array( 'type' => 'select', 'name' => 'tag', 'label' => 'HTML Tag', 'options' => array( 'h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'h5' => 'H5', 'h6' => 'H6' ) ),
			array( 'type' => 'select', 'name' => 'align', 'label' => 'Alignment', 'options' => array( 'left' => 'Left', 'center' => 'Center', 'right' => 'Right' ) ),
		);
	}

	protected function render_content( array $element, int $post_id = 0 ): string {
		$settings = $element['settings'];
		$tag      = in_array( $settings['tag'], array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) ? $settings['tag'] : 'h2';
		$text     = $settings['text'];

		if ( ! empty( $settings['dynamic'] ) && $post_id ) {
			$text = apply_filters( 'ccpb/dynamic_text', $text, $settings['dynamic'], $post_id );
		}

		return sprintf(
			'<%1$s class="ccpb-heading ccpb-align-%2$s">%3$s</%1$s>',
			$tag,
			esc_attr( $settings['align'] ),
			esc_html( $text )
		);
	}
}
