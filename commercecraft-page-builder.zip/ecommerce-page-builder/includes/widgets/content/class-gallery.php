<?php
/**
 * Gallery widget.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Widgets\Content;

use CommerceCraft\Widgets\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Gallery extends Widget_Base {
	protected string $name = 'gallery';
	protected string $title = 'Gallery';
	protected string $icon = 'gallery';
	protected string $category = 'media';

	protected function get_default_settings(): array {
		return array(
			'images'   => array(),
			'columns'  => 3,
			'lightbox' => true,
			'lazy'     => true,
		);
	}

	protected function render_content( array $element, int $post_id = 0 ): string {
		$settings = $element['settings'];
		$images   = is_array( $settings['images'] ) ? $settings['images'] : array();

		if ( empty( $images ) ) {
			return '';
		}

		$html = sprintf( '<div class="ccpb-gallery ccpb-gallery-cols-%d">', (int) $settings['columns'] );

		foreach ( $images as $image ) {
			if ( empty( $image['url'] ) ) {
				continue;
			}

			$loading = ! empty( $settings['lazy'] ) ? ' loading="lazy"' : '';
			$html   .= sprintf(
				'<figure class="ccpb-gallery-item"><img src="%1$s" alt="%2$s"%3$s/></figure>',
				esc_url( $image['url'] ),
				esc_attr( $image['alt'] ?? '' ),
				$loading
			);
		}

		return $html . '</div>';
	}
}
