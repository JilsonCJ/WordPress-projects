<?php
/**
 * Text widget.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Widgets\Content;

use CommerceCraft\Widgets\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Text extends Widget_Base {
	protected string $name = 'text';
	protected string $title = 'Text';
	protected string $icon = 'text';
	protected string $category = 'content';

	protected function get_default_settings(): array {
		return array(
			'content' => 'Enter your text here.',
			'align'   => 'left',
		);
	}

	protected function render_content( array $element, int $post_id = 0 ): string {
		$settings = $element['settings'];

		return sprintf(
			'<div class="ccpb-text ccpb-align-%1$s"><p>%2$s</p></div>',
			esc_attr( $settings['align'] ),
			wp_kses_post( $settings['content'] )
		);
	}
}
