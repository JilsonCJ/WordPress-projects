<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Content;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Shortcode extends Widget_Base {
	protected string $name = 'shortcode';
	protected string $title = 'Shortcode';
	protected string $icon = 'shortcode';
	protected string $category = 'content';
	protected function get_default_settings(): array {
		return array( 'shortcode' => '' );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$code = $element['settings']['shortcode'] ?? '';
		return $code ? '<div class="ccpb-shortcode">' . do_shortcode( $code ) . '</div>' : '';
	}
}
