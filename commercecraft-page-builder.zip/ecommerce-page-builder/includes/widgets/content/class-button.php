<?php
/**
 * Button widget.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Widgets\Content;

use CommerceCraft\Widgets\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Button extends Widget_Base {
	protected string $name = 'button';
	protected string $title = 'Button';
	protected string $icon = 'button';
	protected string $category = 'content';

	protected function get_default_settings(): array {
		return array(
			'text'   => 'Click Here',
			'url'    => '#',
			'target' => '_self',
			'size'   => 'medium',
			'style'  => 'primary',
			'icon'   => '',
		);
	}

	protected function render_content( array $element, int $post_id = 0 ): string {
		$s = $element['settings'];

		return sprintf(
			'<a href="%1$s" class="ccpb-button ccpb-button-%2$s ccpb-button-%3$s" target="%4$s"><span>%5$s</span></a>',
			esc_url( $s['url'] ),
			esc_attr( $s['style'] ),
			esc_attr( $s['size'] ),
			esc_attr( $s['target'] ),
			esc_html( $s['text'] )
		);
	}
}
