<?php
/**
 * Video widget.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Widgets\Content;

use CommerceCraft\Widgets\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Video extends Widget_Base {
	protected string $name = 'video';
	protected string $title = 'Video';
	protected string $icon = 'video';
	protected string $category = 'media';

	protected function get_default_settings(): array {
		return array(
			'source'   => 'youtube',
			'url'      => '',
			'autoplay' => false,
			'loop'     => false,
			'muted'    => false,
		);
	}

	protected function render_content( array $element, int $post_id = 0 ): string {
		$settings = $element['settings'];
		$url      = $settings['url'];

		if ( ! $url ) {
			return '';
		}

		if ( 'self' === $settings['source'] ) {
			return sprintf(
				'<video class="ccpb-video" controls%s%s%s><source src="%s" type="video/mp4"/></video>',
				! empty( $settings['autoplay'] ) ? ' autoplay' : '',
				! empty( $settings['loop'] ) ? ' loop' : '',
				! empty( $settings['muted'] ) ? ' muted' : '',
				esc_url( $url )
			);
		}

		return sprintf(
			'<div class="ccpb-video-embed"><iframe src="%s" frameborder="0" allowfullscreen loading="lazy"></iframe></div>',
			esc_url( $url )
		);
	}
}
