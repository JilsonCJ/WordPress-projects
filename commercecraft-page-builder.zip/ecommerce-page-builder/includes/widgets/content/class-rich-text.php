<?php
/**
 * Rich text widget.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Widgets\Content;

use CommerceCraft\Widgets\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Rich_Text extends Widget_Base {
	protected string $name = 'rich-text';
	protected string $title = 'Rich Text';
	protected string $icon = 'rich-text';
	protected string $category = 'content';

	protected function get_default_settings(): array {
		return array(
			'content' => '<p>Rich text content with <strong>formatting</strong>.</p>',
		);
	}

	protected function render_content( array $element, int $post_id = 0 ): string {
		return '<div class="ccpb-rich-text">' . wp_kses_post( $element['settings']['content'] ) . '</div>';
	}
}
