<?php
/**
 * Image widget.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Widgets\Content;

use CommerceCraft\Widgets\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Image extends Widget_Base {
	protected string $name = 'image';
	protected string $title = 'Image';
	protected string $icon = 'image';
	protected string $category = 'content';

	protected function get_default_settings(): array {
		return array(
			'url'     => '',
			'alt'     => '',
			'link'    => '',
			'width'   => '100',
			'lazy'    => true,
			'dynamic' => '',
		);
	}

	protected function render_content( array $element, int $post_id = 0 ): string {
		$settings = $element['settings'];
		$url      = $settings['url'];

		if ( ! empty( $settings['dynamic'] ) && $post_id ) {
			$url = apply_filters( 'ccpb/dynamic_image', $url, $settings['dynamic'], $post_id );
		}

		if ( ! $url ) {
			return '';
		}

		$loading = ! empty( $settings['lazy'] ) ? ' loading="lazy"' : '';
		$img     = sprintf(
			'<img src="%1$s" alt="%2$s" style="max-width:%3$s%%;"%4$s />',
			esc_url( $url ),
			esc_attr( $settings['alt'] ),
			esc_attr( $settings['width'] ),
			$loading
		);

		if ( ! empty( $settings['link'] ) ) {
			return sprintf( '<a href="%s" class="ccpb-image-link">%s</a>', esc_url( $settings['link'] ), $img );
		}

		return '<div class="ccpb-image">' . $img . '</div>';
	}
}
