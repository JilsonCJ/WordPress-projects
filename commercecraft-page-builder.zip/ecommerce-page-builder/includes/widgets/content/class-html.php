<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Content;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Html extends Widget_Base {
	protected string $name = 'html';
	protected string $title = 'HTML';
	protected string $icon = 'html';
	protected string $category = 'content';
	protected function get_default_settings(): array {
		return array( 'code' => '<div>Custom HTML</div>' );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		return '<div class="ccpb-html">' . $element['settings']['code'] . '</div>';
	}
}
