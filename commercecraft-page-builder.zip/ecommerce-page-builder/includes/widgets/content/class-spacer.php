<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Content;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Spacer extends Widget_Base {
	protected string $name = 'spacer';
	protected string $title = 'Spacer';
	protected string $icon = 'spacer';
	protected string $category = 'content';
	protected function get_default_settings(): array {
		return array( 'height' => '50', 'unit' => 'px' );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$s = $element['settings'];
		return sprintf( '<div class="ccpb-spacer" style="height:%1$s%2$s"></div>', esc_attr( $s['height'] ), esc_attr( $s['unit'] ) );
	}
}
