<?php
/**
 * Base widget class.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Widgets;

use CommerceCraft\Core\Conditions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Widget_Base
 */
abstract class Widget_Base {

	protected string $name = '';
	protected string $title = '';
	protected string $icon = 'widget';
	protected string $category = 'content';
	protected array $keywords = array();
	protected bool $is_container = false;

	public function get_name(): string {
		return $this->name;
	}

	public function get_title(): string {
		return $this->title;
	}

	public function get_icon(): string {
		return $this->icon;
	}

	public function get_category(): string {
		return $this->category;
	}

	public function get_keywords(): array {
		return $this->keywords;
	}

	public function is_container(): bool {
		return $this->is_container;
	}

	/**
	 * Default element structure.
	 *
	 * @return array<string, mixed>
	 */
	public function get_defaults(): array {
		return array(
			'id'         => wp_generate_uuid4(),
			'type'       => $this->name,
			'settings'   => $this->get_default_settings(),
			'styles'     => $this->get_default_styles(),
			'responsive' => array(),
			'conditions' => array(),
			'children'   => array(),
			'locked'     => false,
			'hidden'     => false,
			'disabled'   => false,
		);
	}

	/**
	 * @return array<string, mixed>
	 */
	protected function get_default_settings(): array {
		return array();
	}

	/**
	 * @return array<string, mixed>
	 */
	protected function get_default_styles(): array {
		return array(
			'margin'     => array( 'top' => '', 'right' => '', 'bottom' => '', 'left' => '', 'unit' => 'px' ),
			'padding'    => array( 'top' => '', 'right' => '', 'bottom' => '', 'left' => '', 'unit' => 'px' ),
			'background' => array( 'type' => 'none' ),
			'border'     => array(),
			'typography' => array(),
			'animation'  => array(),
			'customCss'  => '',
			'cssClasses' => '',
			'cssId'      => '',
		);
	}

	/**
	 * Editor control definitions.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function get_controls(): array {
		return apply_filters( 'ccpb/widget_controls/' . $this->name, $this->register_controls() );
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	protected function register_controls(): array {
		return array();
	}

	/**
	 * Sanitize element data.
	 *
	 * @param array<string, mixed> $element Raw element.
	 * @return array<string, mixed>
	 */
	public function sanitize( array $element ): array {
		$defaults = $this->get_defaults();

		$sanitized = array(
			'id'         => sanitize_text_field( (string) ( $element['id'] ?? $defaults['id'] ) ),
			'type'       => $this->name,
			'settings'   => $this->sanitize_settings( $element['settings'] ?? array() ),
			'styles'     => $this->sanitize_styles( $element['styles'] ?? array() ),
			'responsive' => is_array( $element['responsive'] ?? null ) ? $element['responsive'] : array(),
			'conditions' => is_array( $element['conditions'] ?? null ) ? $element['conditions'] : array(),
			'locked'     => ! empty( $element['locked'] ),
			'hidden'     => ! empty( $element['hidden'] ),
			'disabled'   => ! empty( $element['disabled'] ),
			'children'   => array(),
		);

		if ( $this->is_container && ! empty( $element['children'] ) && is_array( $element['children'] ) ) {
			foreach ( $element['children'] as $child ) {
				if ( ! is_array( $child ) || empty( $child['type'] ) ) {
					continue;
				}

				$child_widget = ccpb()->widgets()->get( (string) $child['type'] );

				if ( $child_widget ) {
					$sanitized['children'][] = $child_widget->sanitize( $child );
				}
			}
		}

		return $sanitized;
	}

	/**
	 * @param array<string, mixed> $settings Settings.
	 * @return array<string, mixed>
	 */
	protected function sanitize_settings( array $settings ): array {
		$defaults = $this->get_default_settings();
		$clean    = array();

		foreach ( $defaults as $key => $default ) {
			$value = $settings[ $key ] ?? $default;

			if ( is_string( $default ) ) {
				$clean[ $key ] = sanitize_text_field( (string) $value );
			} elseif ( is_bool( $default ) ) {
				$clean[ $key ] = (bool) $value;
			} elseif ( is_int( $default ) ) {
				$clean[ $key ] = (int) $value;
			} elseif ( is_array( $default ) ) {
				$clean[ $key ] = is_array( $value ) ? $value : $default;
			} else {
				$clean[ $key ] = $value;
			}
		}

		return $clean;
	}

	/**
	 * @param array<string, mixed> $styles Styles.
	 * @return array<string, mixed>
	 */
	protected function sanitize_styles( array $styles ): array {
		return wp_parse_args( $styles, $this->get_default_styles() );
	}

	/**
	 * Render widget HTML.
	 *
	 * @param array<string, mixed> $element  Element data.
	 * @param int                  $post_id  Post ID.
	 */
	public function render( array $element, int $post_id = 0 ): string {
		if ( ! empty( $element['hidden'] ) || ! empty( $element['disabled'] ) ) {
			return '';
		}

		if ( ! Conditions::evaluate( $element['conditions'] ?? array() ) ) {
			return '';
		}

		$attrs = $this->build_attributes( $element );
		$inner = $this->render_content( $element, $post_id );

		if ( $this->is_container && ! empty( $element['children'] ) ) {
			$inner .= ccpb()->widgets()->render_tree( $element['children'], $post_id );
		}

		return sprintf(
			'<div %s>%s</div>',
			$attrs,
			$inner
		);
	}

	/**
	 * @param array<string, mixed> $element Element data.
	 */
	abstract protected function render_content( array $element, int $post_id = 0 ): string;

	/**
	 * @param array<string, mixed> $element Element data.
	 */
	protected function build_attributes( array $element ): string {
		$classes = array( 'ccpb-element', 'ccpb-' . $this->name );

		if ( ! empty( $element['styles']['cssClasses'] ) ) {
			$classes[] = sanitize_html_class( (string) $element['styles']['cssClasses'] );
		}

		$attrs = array(
			'class'           => implode( ' ', $classes ),
			'data-ccpb-id'    => esc_attr( (string) ( $element['id'] ?? '' ) ),
			'data-ccpb-type'  => esc_attr( $this->name ),
		);

		if ( ! empty( $element['styles']['cssId'] ) ) {
			$attrs['id'] = sanitize_html_class( (string) $element['styles']['cssId'] );
		}

		$style = $this->build_inline_styles( $element['styles'] ?? array() );

		if ( $style ) {
			$attrs['style'] = $style;
		}

		$attr_string = '';

		foreach ( $attrs as $key => $value ) {
			$attr_string .= sprintf( '%s="%s" ', esc_attr( $key ), esc_attr( $value ) );
		}

		return trim( $attr_string );
	}

	/**
	 * @param array<string, mixed> $styles Styles array.
	 */
	protected function build_inline_styles( array $styles ): string {
		$css = array();

		if ( ! empty( $styles['padding'] ) && is_array( $styles['padding'] ) ) {
			$unit = $styles['padding']['unit'] ?? 'px';
			foreach ( array( 'top', 'right', 'bottom', 'left' ) as $side ) {
				if ( isset( $styles['padding'][ $side ] ) && '' !== $styles['padding'][ $side ] ) {
					$css[] = 'padding-' . $side . ':' . $styles['padding'][ $side ] . $unit;
				}
			}
		}

		if ( ! empty( $styles['margin'] ) && is_array( $styles['margin'] ) ) {
			$unit = $styles['margin']['unit'] ?? 'px';
			foreach ( array( 'top', 'right', 'bottom', 'left' ) as $side ) {
				if ( isset( $styles['margin'][ $side ] ) && '' !== $styles['margin'][ $side ] ) {
					$css[] = 'margin-' . $side . ':' . $styles['margin'][ $side ] . $unit;
				}
			}
		}

		if ( ! empty( $styles['background']['color'] ) ) {
			$css[] = 'background-color:' . $styles['background']['color'];
		}

		return implode( ';', $css );
	}

	/**
	 * Export config for editor.
	 *
	 * @return array<string, mixed>
	 */
	public function to_editor_config(): array {
		return array(
			'name'        => $this->name,
			'title'       => $this->title,
			'icon'        => $this->icon,
			'category'    => $this->category,
			'keywords'    => $this->keywords,
			'isContainer' => $this->is_container,
			'defaults'    => $this->get_defaults(),
			'controls'    => $this->get_controls(),
		);
	}
}
