<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Forms;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Contact_Form extends Widget_Base {
	protected string $name = 'contact-form';
	protected string $title = 'Contact Form';
	protected string $icon = 'form';
	protected string $category = 'forms';
	protected function get_default_settings(): array {
		return array( 'fields' => array( 'name', 'email', 'message' ), 'submitText' => 'Send Message', 'recipient' => get_option( 'admin_email' ) );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$s = $element['settings'];
		$action = admin_url( 'admin-post.php' );
		$html = sprintf(
			'<form class="ccpb-contact-form" method="post" action="%s"><input type="hidden" name="action" value="ccpb_contact"/>%s',
			esc_url( $action ),
			wp_nonce_field( 'ccpb_contact', 'ccpb_nonce', true, false )
		);
		foreach ( $s['fields'] as $field ) {
			$type = 'email' === $field ? 'email' : ( 'message' === $field ? 'textarea' : 'text' );
			if ( 'textarea' === $type ) {
				$html .= sprintf( '<div class="ccpb-field"><label>%s</label><textarea name="%s" required></textarea></div>', esc_html( ucfirst( $field ) ), esc_attr( $field ) );
			} else {
				$html .= sprintf( '<div class="ccpb-field"><label>%s</label><input type="%s" name="%s" required/></div>', esc_html( ucfirst( $field ) ), esc_attr( $type ), esc_attr( $field ) );
			}
		}
		return $html . sprintf( '<button type="submit">%s</button></form>', esc_html( $s['submitText'] ) );
	}
}
