<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Forms;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Newsletter_Form extends Widget_Base {
	protected string $name = 'newsletter-form';
	protected string $title = 'Newsletter Form';
	protected string $icon = 'newsletter-form';
	protected string $category = 'forms';
	protected function get_default_settings(): array {
		return array( 'placeholder' => 'Email address', 'buttonText' => 'Subscribe' );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$s = $element['settings'];
		return sprintf(
			'<form class="ccpb-newsletter-form" method="post" action="%s"><input type="hidden" name="action" value="ccpb_newsletter"/>%s<input type="email" name="email" placeholder="%s" required/><button type="submit">%s</button></form>',
			esc_url( admin_url( 'admin-post.php' ) ),
			wp_nonce_field( 'ccpb_newsletter', 'ccpb_nonce', true, false ),
			esc_attr( $s['placeholder'] ),
			esc_html( $s['buttonText'] )
		);
	}
}
