<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Navigation;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Search extends Widget_Base {
	protected string $name = 'search';
	protected string $title = 'Search';
	protected string $icon = 'search';
	protected string $category = 'navigation';
	protected function get_default_settings(): array {
		return array( 'placeholder' => 'Search products...', 'style' => 'inline' );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$s = $element['settings'];
		if ( class_exists( 'WooCommerce' ) ) {
			return '<div class="ccpb-search">' . get_product_search_form( false ) . '</div>';
		}
		return get_search_form( array( 'echo' => false ) ) ?: '';
	}
}
