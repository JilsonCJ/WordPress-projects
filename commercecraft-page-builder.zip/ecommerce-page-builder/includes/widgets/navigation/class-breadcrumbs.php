<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Navigation;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Breadcrumbs extends Widget_Base {
	protected string $name = 'breadcrumbs';
	protected string $title = 'Breadcrumbs';
	protected string $icon = 'breadcrumbs';
	protected string $category = 'navigation';
	protected function get_default_settings(): array {
		return array( 'separator' => '/', 'showHome' => true );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		if ( function_exists( 'woocommerce_breadcrumb' ) ) {
			ob_start();
			woocommerce_breadcrumb( array( 'wrap_before' => '<nav class="ccpb-breadcrumbs">', 'wrap_after' => '</nav>' ) );
			return ob_get_clean() ?: '';
		}
		return '';
	}
}
