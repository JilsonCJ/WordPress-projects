<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Navigation;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Footer_Builder extends Widget_Base {
	protected string $name = 'footer-builder';
	protected string $title = 'Footer Builder';
	protected string $icon = 'footer';
	protected string $category = 'navigation';
	protected bool $is_container = true;
	protected function render_content( array $element, int $post_id = 0 ): string {
		return '<footer class="ccpb-footer" role="contentinfo"></footer>';
	}
}
