<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Navigation;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Header_Builder extends Widget_Base {
	protected string $name = 'header-builder';
	protected string $title = 'Header Builder';
	protected string $icon = 'header';
	protected string $category = 'navigation';
	protected bool $is_container = true;
	protected function get_default_settings(): array {
		return array( 'sticky' => true, 'transparent' => false, 'layout' => 'logo-left' );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		return '<header class="ccpb-header" role="banner"></header>';
	}
}
