<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Marketing;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Trust_Badges extends Widget_Base {
	protected string $name = 'trust-badges';
	protected string $title = 'Trust Badges';
	protected string $icon = 'trust';
	protected string $category = 'marketing';
	protected function get_default_settings(): array {
		return array( 'badges' => array( 'Secure Checkout', 'Free Returns', '24/7 Support' ) );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$badges = $element['settings']['badges'] ?? array();
		if ( empty( $badges ) ) { return ''; }
		$html = '<div class="ccpb-trust-badges">';
		foreach ( $badges as $badge ) {
			$html .= sprintf( '<span class="ccpb-trust-badge">%s</span>', esc_html( is_string( $badge ) ? $badge : ( $badge['text'] ?? '' ) ) );
		}
		return $html . '</div>';
	}
}
