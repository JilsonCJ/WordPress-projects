<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Marketing;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Announcement_Bar extends Widget_Base {
	protected string $name = 'announcement-bar';
	protected string $title = 'Announcement Bar';
	protected string $icon = 'announcement';
	protected string $category = 'marketing';
	protected function get_default_settings(): array {
		return array( 'text' => 'Free shipping on orders over $50!', 'link' => '', 'dismissible' => true );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$s = $element['settings'];
		$content = esc_html( $s['text'] );
		if ( ! empty( $s['link'] ) ) { $content = sprintf( '<a href="%s">%s</a>', esc_url( $s['link'] ), $content ); }
		$dismiss = ! empty( $s['dismissible'] ) ? '<button class="ccpb-dismiss" aria-label="Dismiss">&times;</button>' : '';
		return sprintf( '<div class="ccpb-announcement-bar">%s%s</div>', $content, $dismiss );
	}
}
