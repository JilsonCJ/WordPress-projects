<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Marketing;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Newsletter extends Widget_Base {
	protected string $name = 'newsletter';
	protected string $title = 'Newsletter';
	protected string $icon = 'newsletter';
	protected string $category = 'marketing';
	protected function get_default_settings(): array {
		return array( 'title' => 'Subscribe to our newsletter', 'placeholder' => 'Your email', 'buttonText' => 'Subscribe' );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$s = $element['settings'];
		return sprintf(
			'<form class="ccpb-newsletter" method="post"><h4>%s</h4><input type="email" name="email" placeholder="%s" required/><button type="submit">%s</button></form>',
			esc_html( $s['title'] ), esc_attr( $s['placeholder'] ), esc_html( $s['buttonText'] )
		);
	}
}
