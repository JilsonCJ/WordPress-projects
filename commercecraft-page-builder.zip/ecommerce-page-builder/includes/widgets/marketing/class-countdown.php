<?php
declare(strict_types=1);
namespace CommerceCraft\Widgets\Marketing;
use CommerceCraft\Widgets\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) { exit; }
class Countdown extends Widget_Base {
	protected string $name = 'countdown';
	protected string $title = 'Countdown';
	protected string $icon = 'countdown';
	protected string $category = 'marketing';
	protected function get_default_settings(): array {
		return array( 'targetDate' => '', 'label' => 'Sale ends in' );
	}
	protected function render_content( array $element, int $post_id = 0 ): string {
		$s = $element['settings'];
		if ( empty( $s['targetDate'] ) ) { return ''; }
		return sprintf( '<div class="ccpb-countdown" data-ccpb-countdown data-target="%s"><span class="ccpb-countdown-label">%s</span><div class="ccpb-countdown-timer"></div></div>', esc_attr( $s['targetDate'] ), esc_html( $s['label'] ) );
	}
}
