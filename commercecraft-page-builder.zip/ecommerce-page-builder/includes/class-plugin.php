<?php
/**
 * Main plugin bootstrap.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft;

use CommerceCraft\Admin\Admin;
use CommerceCraft\Admin\Editor;
use CommerceCraft\Api\Rest_Controller;
use CommerceCraft\Core\Builder;
use CommerceCraft\Core\Document;
use CommerceCraft\Core\Revisions;
use CommerceCraft\Core\Templates;
use CommerceCraft\Dynamic\Dynamic_Content;
use CommerceCraft\Developer\Hooks;
use CommerceCraft\Forms\Form_Handler;
use CommerceCraft\Popup\Popup_Builder;
use CommerceCraft\Frontend\Renderer;
use CommerceCraft\Globals\Design_System;
use CommerceCraft\Performance\Optimizer;
use CommerceCraft\ThemeBuilder\Theme_Builder;
use CommerceCraft\Widgets\Widget_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Plugin
 */
final class Plugin {

	private static ?self $instance = null;

	private Builder $builder;

	private Widget_Manager $widgets;

	private Design_System $design_system;

	private Theme_Builder $theme_builder;

	private bool $initialized = false;

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		$this->builder       = new Builder();
		$this->widgets       = new Widget_Manager();
		$this->design_system = new Design_System();
		$this->theme_builder = new Theme_Builder();
	}

	public function init(): void {
		if ( $this->initialized ) {
			return;
		}

		$this->initialized = true;

		load_plugin_textdomain( 'commercecraft', false, dirname( CCPB_PLUGIN_BASENAME ) . '/languages' );

		Hooks::init();
		Dynamic_Content::init();
		Form_Handler::init();
		Popup_Builder::init();

		$this->widgets->register_defaults();
		$this->design_system->init();
		$this->builder->init();
		Document::init();
		Revisions::init();
		Templates::init();
		$this->theme_builder->init();
		Optimizer::init();

		if ( is_admin() ) {
			Admin::init();
			Editor::init();
		}

		Renderer::init();
		Rest_Controller::init();

		do_action( 'ccpb/init', $this );
	}

	public function builder(): Builder {
		return $this->builder;
	}

	public function widgets(): Widget_Manager {
		return $this->widgets;
	}

	public function design_system(): Design_System {
		return $this->design_system;
	}

	public function theme_builder(): Theme_Builder {
		return $this->theme_builder;
	}

	public static function activate(): void {
		Document::register_post_types();
		Templates::register_post_type();
		Popup_Builder::register_post_type();
		flush_rewrite_rules();

		update_option(
			'ccpb_version',
			array(
				'version'     => CCPB_VERSION,
				'activated'   => current_time( 'mysql' ),
				'breakpoints' => array(
					'desktop' => 1200,
					'laptop'  => 1024,
					'tablet'  => 768,
					'mobile'  => 480,
				),
			)
		);
	}

	public static function deactivate(): void {
		flush_rewrite_rules();
	}
}
