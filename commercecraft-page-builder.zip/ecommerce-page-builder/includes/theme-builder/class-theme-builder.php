<?php
/**
 * Theme builder for headers, footers, and WooCommerce templates.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\ThemeBuilder;

use CommerceCraft\Core\Document;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Theme_Builder {

	public const OPTION_KEY = 'ccpb_theme_templates';

	/** @var array<string, string> */
	private array $locations = array(
		'header'       => 'Header',
		'footer'       => 'Footer',
		'homepage'     => 'Homepage',
		'shop'         => 'Shop',
		'product'      => 'Single Product',
		'archive'      => 'Archive',
		'single'       => 'Single Post',
		'cart'         => 'Cart',
		'checkout'     => 'Checkout',
		'myaccount'    => 'My Account',
		'404'          => '404 Page',
		'coming_soon'  => 'Coming Soon',
		'maintenance'  => 'Maintenance',
	);

	public function init(): void {
		add_filter( 'template_include', array( $this, 'override_template' ), 99 );
		add_action( 'get_header', array( $this, 'render_header' ), 0 );
		add_action( 'get_footer', array( $this, 'render_footer' ), 0 );
	}

	/**
	 * @return array<string, string>
	 */
	public function get_locations(): array {
		return apply_filters( 'ccpb/theme_locations', $this->locations );
	}

	public function get_template_id( string $location ): int {
		$templates = get_option( self::OPTION_KEY, array() );
		return (int) ( $templates[ $location ] ?? 0 );
	}

	public function set_template( string $location, int $post_id ): void {
		$templates = get_option( self::OPTION_KEY, array() );
		$templates[ sanitize_key( $location ) ] = $post_id;
		update_option( self::OPTION_KEY, $templates );
	}

	public function override_template( string $template ): string {
		$location = $this->detect_location();

		if ( ! $location ) {
			return $template;
		}

		$post_id = $this->get_template_id( $location );

		if ( $post_id && Document::is_ccpb_enabled( $post_id ) ) {
			$ccpb_template = CCPB_PLUGIN_DIR . 'templates/theme-builder.php';

			if ( file_exists( $ccpb_template ) ) {
				return $ccpb_template;
			}
		}

		return $template;
	}

	public function detect_location(): string {
		if ( is_front_page() ) {
			return 'homepage';
		}
		if ( function_exists( 'is_shop' ) && is_shop() ) {
			return 'shop';
		}
		if ( function_exists( 'is_product' ) && is_product() ) {
			return 'product';
		}
		if ( function_exists( 'is_cart' ) && is_cart() ) {
			return 'cart';
		}
		if ( function_exists( 'is_checkout' ) && is_checkout() ) {
			return 'checkout';
		}
		if ( function_exists( 'is_account_page' ) && is_account_page() ) {
			return 'myaccount';
		}
		if ( is_404() ) {
			return '404';
		}
		if ( is_singular( 'post' ) ) {
			return 'single';
		}
		if ( is_archive() ) {
			return 'archive';
		}

		return '';
	}

	public function render_header(): void {
		$post_id = $this->get_template_id( 'header' );

		if ( $post_id && Document::is_ccpb_enabled( $post_id ) ) {
			echo ccpb()->widgets()->render_tree( Document::get( $post_id )['elements'] ?? array(), $post_id );
		}
	}

	public function render_footer(): void {
		$post_id = $this->get_template_id( 'footer' );

		if ( $post_id && Document::is_ccpb_enabled( $post_id ) ) {
			echo ccpb()->widgets()->render_tree( Document::get( $post_id )['elements'] ?? array(), $post_id );
		}
	}
}
