<?php
/**
 * Dynamic content bindings.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Dynamic;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Dynamic_Content {

	public static function init(): void {
		add_filter( 'ccpb/dynamic_text', array( self::class, 'resolve_text' ), 10, 3 );
		add_filter( 'ccpb/dynamic_image', array( self::class, 'resolve_image' ), 10, 3 );
	}

	public static function resolve_text( string $fallback, string $key, int $post_id ): string {
		switch ( $key ) {
			case 'post_title':
				return get_the_title( $post_id ) ?: $fallback;
			case 'post_excerpt':
				return get_the_excerpt( $post_id ) ?: $fallback;
			case 'author':
				return get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $post_id ) ) ?: $fallback;
			case 'date':
				return get_the_date( '', $post_id ) ?: $fallback;
			case 'product_title':
				if ( class_exists( 'WooCommerce' ) ) {
					$p = wc_get_product( $post_id );
					return $p ? $p->get_name() : $fallback;
				}
				break;
			case 'product_price':
				if ( class_exists( 'WooCommerce' ) ) {
					$p = wc_get_product( $post_id );
					return $p ? wp_strip_all_tags( $p->get_price_html() ) : $fallback;
				}
				break;
			case 'product_sku':
				if ( class_exists( 'WooCommerce' ) ) {
					$p = wc_get_product( $post_id );
					return $p ? ( $p->get_sku() ?: $fallback ) : $fallback;
				}
				break;
			case 'stock_status':
				if ( class_exists( 'WooCommerce' ) ) {
					$p = wc_get_product( $post_id );
					return $p ? wc_get_stock_html( $p ) : $fallback;
				}
				break;
			case 'user_name':
				if ( is_user_logged_in() ) {
					$user = wp_get_current_user();
					return $user->display_name ?: $fallback;
				}
				break;
		}

		$meta = get_post_meta( $post_id, $key, true );
		if ( is_string( $meta ) && $meta ) {
			return $meta;
		}

		return $fallback;
	}

	public static function resolve_image( string $fallback, string $key, int $post_id ): string {
		switch ( $key ) {
			case 'featured':
				$url = get_the_post_thumbnail_url( $post_id, 'full' );
				return $url ?: $fallback;
			case 'product_image':
				if ( class_exists( 'WooCommerce' ) ) {
					$p = wc_get_product( $post_id );
					if ( $p ) {
						$id = $p->get_image_id();
						return $id ? ( wp_get_attachment_image_url( $id, 'full' ) ?: $fallback ) : $fallback;
					}
				}
				break;
			case 'author_avatar':
				$author = (int) get_post_field( 'post_author', $post_id );
				return get_avatar_url( $author ) ?: $fallback;
		}

		return $fallback;
	}
}
