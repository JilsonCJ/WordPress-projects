<?php
/**
 * REST API controller.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Api;

use CommerceCraft\Ai\Ai_Service;
use CommerceCraft\Core\Document;
use CommerceCraft\Core\Revisions;
use CommerceCraft\Core\Templates;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Rest_Controller {

	public static function init(): void {
		add_action( 'rest_api_init', array( self::class, 'register_routes' ) );
	}

	public static function register_routes(): void {
		register_rest_route(
			'commercecraft/v1',
			'/document/(?P<id>\d+)',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( self::class, 'get_document' ),
					'permission_callback' => array( self::class, 'can_edit' ),
				),
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( self::class, 'save_document' ),
					'permission_callback' => array( self::class, 'can_edit' ),
				),
			)
		);

		register_rest_route(
			'commercecraft/v1',
			'/document/(?P<id>\d+)/duplicate',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( self::class, 'duplicate_document' ),
				'permission_callback' => array( self::class, 'can_edit' ),
			)
		);

		register_rest_route(
			'commercecraft/v1',
			'/document/(?P<id>\d+)/revisions',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( self::class, 'get_revisions' ),
				'permission_callback' => array( self::class, 'can_edit' ),
			)
		);

		register_rest_route(
			'commercecraft/v1',
			'/document/(?P<id>\d+)/revisions/(?P<revision_id>[a-zA-Z0-9-]+)/restore',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( self::class, 'restore_revision' ),
				'permission_callback' => array( self::class, 'can_edit' ),
			)
		);

		register_rest_route(
			'commercecraft/v1',
			'/templates',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => static fn() => new WP_REST_Response( Templates::get_library() ),
					'permission_callback' => static fn() => current_user_can( 'edit_posts' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( self::class, 'save_template' ),
					'permission_callback' => static fn() => current_user_can( 'edit_posts' ),
				),
			)
		);

		register_rest_route(
			'commercecraft/v1',
			'/templates/import',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( self::class, 'import_template' ),
				'permission_callback' => static fn() => current_user_can( 'edit_posts' ),
			)
		);

		register_rest_route(
			'commercecraft/v1',
			'/ai/generate',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( self::class, 'ai_generate' ),
				'permission_callback' => static fn() => current_user_can( 'edit_posts' ),
			)
		);

		register_rest_route(
			'commercecraft/v1',
			'/widgets',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => static fn() => new WP_REST_Response( ccpb()->widgets()->get_editor_config() ),
				'permission_callback' => static fn() => current_user_can( 'edit_posts' ),
			)
		);
	}

	public static function can_edit( WP_REST_Request $request ): bool {
		$post_id = (int) $request['id'];
		return current_user_can( 'edit_post', $post_id );
	}

	public static function get_document( WP_REST_Request $request ): WP_REST_Response {
		$post_id = (int) $request['id'];

		return new WP_REST_Response(
			array(
				'document' => Document::get( $post_id ),
				'status'   => Document::get_status( $post_id ),
				'post'     => array(
					'title'  => get_the_title( $post_id ),
					'status' => get_post_status( $post_id ),
				),
			)
		);
	}

	public static function save_document( WP_REST_Request $request ): WP_REST_Response {
		$post_id  = (int) $request['id'];
		$document = $request->get_param( 'document' );
		$status   = sanitize_key( (string) ( $request->get_param( 'status' ) ?? 'draft' ) );
		$autosave = (bool) $request->get_param( 'autosave' );

		if ( ! is_array( $document ) ) {
			return new WP_REST_Response( array( 'error' => 'Invalid document' ), 400 );
		}

		Revisions::add( $post_id, Document::get( $post_id ), $autosave ? 'autosave' : 'manual save' );
		Document::save( $post_id, $document, $status );

		if ( 'publish' === $status ) {
			wp_update_post(
				array(
					'ID'          => $post_id,
					'post_status' => 'publish',
				)
			);
		}

		$scheduled = $request->get_param( 'scheduledDate' );

		if ( $scheduled ) {
			wp_update_post(
				array(
					'ID'            => $post_id,
					'post_status'   => 'future',
					'post_date'     => sanitize_text_field( (string) $scheduled ),
					'post_date_gmt' => get_gmt_from_date( sanitize_text_field( (string) $scheduled ) ),
				)
			);
		}

		return new WP_REST_Response( array( 'success' => true, 'status' => $status ) );
	}

	public static function duplicate_document( WP_REST_Request $request ): WP_REST_Response {
		$result = Document::duplicate( (int) $request['id'] );

		if ( is_wp_error( $result ) ) {
			return new WP_REST_Response( array( 'error' => $result->get_error_message() ), 400 );
		}

		return new WP_REST_Response( array( 'newId' => $result ) );
	}

	public static function get_revisions( WP_REST_Request $request ): WP_REST_Response {
		return new WP_REST_Response( Revisions::get_all( (int) $request['id'] ) );
	}

	public static function restore_revision( WP_REST_Request $request ): WP_REST_Response {
		$result = Revisions::restore( (int) $request['id'], (string) $request['revision_id'] );

		if ( is_wp_error( $result ) ) {
			return new WP_REST_Response( array( 'error' => $result->get_error_message() ), 400 );
		}

		return new WP_REST_Response( array( 'success' => true ) );
	}

	public static function save_template( WP_REST_Request $request ): WP_REST_Response {
		$title    = sanitize_text_field( (string) $request->get_param( 'title' ) );
		$document = $request->get_param( 'document' );
		$type     = sanitize_key( (string) ( $request->get_param( 'type' ) ?? 'section' ) );

		if ( ! is_array( $document ) ) {
			return new WP_REST_Response( array( 'error' => 'Invalid document' ), 400 );
		}

		$id = Templates::save( $title, $document, $type );

		if ( is_wp_error( $id ) ) {
			return new WP_REST_Response( array( 'error' => $id->get_error_message() ), 400 );
		}

		return new WP_REST_Response( array( 'id' => $id ) );
	}

	public static function import_template( WP_REST_Request $request ): WP_REST_Response {
		$json  = (string) $request->get_param( 'json' );
		$title = sanitize_text_field( (string) ( $request->get_param( 'title' ) ?? '' ) );
		$id    = Templates::import( $json, $title );

		if ( is_wp_error( $id ) ) {
			return new WP_REST_Response( array( 'error' => $id->get_error_message() ), 400 );
		}

		return new WP_REST_Response( array( 'id' => $id ) );
	}

	public static function ai_generate( WP_REST_Request $request ): WP_REST_Response {
		$type    = sanitize_key( (string) $request->get_param( 'type' ) );
		$prompt  = sanitize_textarea_field( (string) $request->get_param( 'prompt' ) );
		$context = $request->get_param( 'context' );

		$result = Ai_Service::generate( $type, $prompt, is_array( $context ) ? $context : array() );

		if ( is_wp_error( $result ) ) {
			return new WP_REST_Response( array( 'error' => $result->get_error_message() ), 400 );
		}

		return new WP_REST_Response( array( 'result' => $result ) );
	}
}
