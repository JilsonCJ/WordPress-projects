<?php
/**
 * Template import/export and global templates.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Templates
 */
class Templates {

	public const META_TYPE = '_ccpb_template_type';
	public const META_DATA = '_ccpb_template_data';

	public static function init(): void {
		add_action( 'init', array( self::class, 'register_post_type' ) );
	}

	public static function register_post_type(): void {
		// Registered via Document::register_post_types on activation.
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_library(): array {
		$query = new \WP_Query(
			array(
				'post_type'      => Document::POST_TYPE_TEMPLATE,
				'posts_per_page' => 100,
				'post_status'    => 'publish',
			)
		);

		$templates = array();

		foreach ( $query->posts as $post ) {
			$templates[] = array(
				'id'    => $post->ID,
				'title' => $post->post_title,
				'type'  => get_post_meta( $post->ID, self::META_TYPE, true ),
				'thumb' => get_the_post_thumbnail_url( $post->ID, 'medium' ),
			);
		}

		return $templates;
	}

	/**
	 * @param array<string, mixed> $document Document to save as template.
	 */
	public static function save( string $title, array $document, string $type = 'section' ): int|\WP_Error {
		$post_id = wp_insert_post(
			array(
				'post_title'  => sanitize_text_field( $title ),
				'post_type'   => Document::POST_TYPE_TEMPLATE,
				'post_status' => 'publish',
				'post_author' => get_current_user_id(),
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		update_post_meta( $post_id, self::META_TYPE, sanitize_key( $type ) );
		update_post_meta( $post_id, self::META_DATA, ccpb()->builder()->sanitize_document( $document ) );

		return $post_id;
	}

	/**
	 * @return array<string, mixed>|null
	 */
	public static function get( int $template_id ): ?array {
		$data = get_post_meta( $template_id, self::META_DATA, true );

		return is_array( $data ) ? $data : null;
	}

	/**
	 * Export template as JSON.
	 *
	 * @return string
	 */
	public static function export( int $template_id ): string {
		$data = self::get( $template_id );

		return wp_json_encode(
			array(
				'version'  => CCPB_VERSION,
				'type'     => get_post_meta( $template_id, self::META_TYPE, true ),
				'document' => $data,
			),
			JSON_PRETTY_PRINT
		) ?: '{}';
	}

	/**
	 * Import template from JSON string.
	 *
	 * @return int|\WP_Error
	 */
	public static function import( string $json, string $title = '' ): int|\WP_Error {
		$data = json_decode( $json, true );

		if ( ! is_array( $data ) || empty( $data['document'] ) ) {
			return new \WP_Error( 'invalid_json', __( 'Invalid template JSON.', 'commercecraft' ) );
		}

		$title = $title ?: __( 'Imported Template', 'commercecraft' );
		$type  = sanitize_key( (string) ( $data['type'] ?? 'section' ) );

		return self::save( $title, $data['document'], $type );
	}
}
