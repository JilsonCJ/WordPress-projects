<?php
/**
 * Editor link helper.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Editor_Link
 */
class Editor_Link {

	public static function get( int $post_id, string $mode = 'backend' ): string {
		$args = array(
			'post'   => $post_id,
			'action' => 'ccpb_edit',
			'mode'   => $mode,
		);

		return add_query_arg( $args, admin_url( 'post.php' ) );
	}

	public static function get_frontend( int $post_id ): string {
		$url = get_permalink( $post_id );

		if ( ! $url ) {
			return self::get( $post_id );
		}

		return add_query_arg( 'ccpb-preview', '1', $url );
	}
}
