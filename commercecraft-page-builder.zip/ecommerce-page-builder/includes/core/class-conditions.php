<?php
/**
 * Conditional display engine.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Conditions
 */
class Conditions {

	/**
	 * Evaluate whether an element should render.
	 *
	 * @param array<string, mixed> $conditions Condition rules.
	 */
	public static function evaluate( array $conditions ): bool {
		if ( empty( $conditions ) ) {
			return true;
		}

		$logic = strtoupper( (string) ( $conditions['logic'] ?? 'AND' ) );
		$rules = is_array( $conditions['rules'] ?? null ) ? $conditions['rules'] : array();
		$results = array();

		foreach ( $rules as $rule ) {
			if ( ! is_array( $rule ) ) {
				continue;
			}

			$results[] = self::evaluate_rule( $rule );
		}

		if ( empty( $results ) ) {
			return true;
		}

		if ( 'OR' === $logic ) {
			return in_array( true, $results, true );
		}

		return ! in_array( false, $results, true );
	}

	/**
	 * @param array<string, mixed> $rule Single rule.
	 */
	private static function evaluate_rule( array $rule ): bool {
		$type     = sanitize_key( (string) ( $rule['type'] ?? '' ) );
		$operator = sanitize_key( (string) ( $rule['operator'] ?? 'is' ) );
		$value    = $rule['value'] ?? '';

		switch ( $type ) {
			case 'logged_in':
				return is_user_logged_in();

			case 'logged_out':
				return ! is_user_logged_in();

			case 'user_role':
				if ( ! is_user_logged_in() ) {
					return 'is_not' === $operator;
				}
				$user  = wp_get_current_user();
				$match = in_array( $value, (array) $user->roles, true );
				return 'is_not' === $operator ? ! $match : $match;

			case 'device':
				return self::match_device( (string) $value );

			case 'date':
				return self::match_date( (string) $value, (string) ( $rule['end'] ?? '' ) );

			case 'url':
				$current = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( (string) $_SERVER['REQUEST_URI'] ) ) : '';
				$match   = str_contains( $current, (string) $value );
				return 'is_not' === $operator ? ! $match : $match;

			case 'cart_value':
				if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
					return false;
				}
				$total = (float) WC()->cart->get_total( 'edit' );
				$target = (float) $value;
				return self::compare_numeric( $total, $target, $operator );

			case 'product_category':
				if ( ! is_product() ) {
					return false;
				}
				$terms = wp_get_post_terms( get_the_ID(), 'product_cat', array( 'fields' => 'slugs' ) );
				$match = in_array( $value, $terms, true );
				return 'is_not' === $operator ? ! $match : $match;

			default:
				return apply_filters( 'ccpb/evaluate_condition', true, $rule );
		}
	}

	private static function match_device( string $device ): bool {
		if ( ! function_exists( 'wp_is_mobile' ) ) {
			return true;
		}

		$is_mobile = wp_is_mobile();

		return ( 'mobile' === $device && $is_mobile ) || ( 'desktop' === $device && ! $is_mobile );
	}

	private static function match_date( string $start, string $end ): bool {
		$now = current_time( 'timestamp' );

		if ( $start && $now < strtotime( $start ) ) {
			return false;
		}

		if ( $end && $now > strtotime( $end ) ) {
			return false;
		}

		return true;
	}

	private static function compare_numeric( float $actual, float $target, string $operator ): bool {
		return match ( $operator ) {
			'gt'     => $actual > $target,
			'gte'    => $actual >= $target,
			'lt'     => $actual < $target,
			'lte'    => $actual <= $target,
			'is_not' => $actual !== $target,
			default  => $actual === $target,
		};
	}
}
