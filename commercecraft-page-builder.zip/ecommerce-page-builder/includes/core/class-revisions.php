<?php
/**
 * Revision history manager.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Revisions
 */
class Revisions {

	public const META_KEY = '_ccpb_revisions';
	public const MAX_REVISIONS = 50;

	public static function init(): void {
		// Reserved for scheduled cleanup hooks.
	}

	/**
	 * @param array<string, mixed> $document Document snapshot.
	 */
	public static function add( int $post_id, array $document, string $label = '' ): void {
		$revisions = self::get_all( $post_id );

		array_unshift(
			$revisions,
			array(
				'id'        => wp_generate_uuid4(),
				'timestamp' => current_time( 'mysql' ),
				'author'    => get_current_user_id(),
				'label'     => sanitize_text_field( $label ),
				'document'  => $document,
			)
		);

		if ( count( $revisions ) > self::MAX_REVISIONS ) {
			$revisions = array_slice( $revisions, 0, self::MAX_REVISIONS );
		}

		update_post_meta( $post_id, self::META_KEY, $revisions );
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_all( int $post_id ): array {
		$revisions = get_post_meta( $post_id, self::META_KEY, true );

		return is_array( $revisions ) ? $revisions : array();
	}

	public static function restore( int $post_id, string $revision_id ): bool|\WP_Error {
		foreach ( self::get_all( $post_id ) as $revision ) {
			if ( ( $revision['id'] ?? '' ) === $revision_id && ! empty( $revision['document'] ) ) {
				Document::save( $post_id, $revision['document'], Document::get_status( $post_id ) );
				return true;
			}
		}

		return new \WP_Error( 'not_found', __( 'Revision not found.', 'commercecraft' ) );
	}
}
