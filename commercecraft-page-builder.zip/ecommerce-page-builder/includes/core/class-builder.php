<?php
/**
 * Builder core engine.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Builder
 */
class Builder {

	public const META_KEY       = '_ccpb_document';
	public const STATUS_META_KEY  = '_ccpb_status';
	public const SETTINGS_META    = '_ccpb_settings';

	public function init(): void {
		add_filter( 'the_content', array( $this, 'filter_content' ), 9 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_assets' ) );
	}

	public function filter_content( string $content ): string {
		if ( ! is_singular() || is_admin() ) {
			return $content;
		}

		$post_id = get_the_ID();

		if ( ! $post_id || ! Document::is_ccpb_enabled( $post_id ) ) {
			return $content;
		}

		$document = Document::get( $post_id );

		if ( empty( $document['elements'] ) ) {
			return $content;
		}

		return ccpb()->widgets()->render_tree( $document['elements'], $post_id );
	}

	public function enqueue_frontend_assets(): void {
		if ( ! is_singular() ) {
			return;
		}

		$post_id = get_the_ID();

		if ( ! $post_id || ! Document::is_ccpb_enabled( $post_id ) ) {
			return;
		}

		wp_enqueue_style(
			'ccpb-frontend',
			CCPB_PLUGIN_URL . 'assets/css/frontend.css',
			array(),
			CCPB_VERSION
		);

		wp_enqueue_script(
			'ccpb-frontend',
			CCPB_PLUGIN_URL . 'assets/js/frontend.js',
			array(),
			CCPB_VERSION,
			true
		);

		wp_localize_script(
			'ccpb-frontend',
			'ccpbFrontend',
			array(
				'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
				'restUrl'   => rest_url( 'commercecraft/v1/' ),
				'nonce'     => wp_create_nonce( 'wp_rest' ),
				'postId'    => $post_id,
				'breakpoints' => $this->get_breakpoints(),
			)
		);
	}

	/**
	 * @return array<string, int>
	 */
	public function get_breakpoints(): array {
		$defaults = array(
			'desktop' => 1200,
			'laptop'  => 1024,
			'tablet'  => 768,
			'mobile'  => 480,
		);

		$stored = get_option( 'ccpb_version', array() );

		if ( ! empty( $stored['breakpoints'] ) && is_array( $stored['breakpoints'] ) ) {
			return array_merge( $defaults, $stored['breakpoints'] );
		}

		return $defaults;
	}

	/**
	 * Sanitize document data from editor.
	 *
	 * @param array<string, mixed> $document Raw document.
	 * @return array<string, mixed>
	 */
	public function sanitize_document( array $document ): array {
		$sanitized = array(
			'version'   => sanitize_text_field( (string) ( $document['version'] ?? '1.0' ) ),
			'elements'  => $this->sanitize_elements( $document['elements'] ?? array() ),
			'globals'   => $this->sanitize_globals( $document['globals'] ?? array() ),
			'settings'  => $this->sanitize_settings( $document['settings'] ?? array() ),
		);

		return apply_filters( 'ccpb/sanitize_document', $sanitized, $document );
	}

	/**
	 * @param array<int, mixed> $elements Elements tree.
	 * @return array<int, mixed>
	 */
	private function sanitize_elements( array $elements ): array {
		$clean = array();

		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) || empty( $element['type'] ) ) {
				continue;
			}

			$type = sanitize_key( (string) $element['type'] );
			$widget = ccpb()->widgets()->get( $type );

			if ( ! $widget ) {
				continue;
			}

			$clean[] = $widget->sanitize( $element );
		}

		return $clean;
	}

	/**
	 * @param array<string, mixed> $globals Global settings.
	 * @return array<string, mixed>
	 */
	private function sanitize_globals( array $globals ): array {
		return array(
			'colors'   => is_array( $globals['colors'] ?? null ) ? $globals['colors'] : array(),
			'fonts'    => is_array( $globals['fonts'] ?? null ) ? $globals['fonts'] : array(),
			'buttons'  => is_array( $globals['buttons'] ?? null ) ? $globals['buttons'] : array(),
			'spacing'  => is_array( $globals['spacing'] ?? null ) ? $globals['spacing'] : array(),
		);
	}

	/**
	 * @param array<string, mixed> $settings Page settings.
	 * @return array<string, mixed>
	 */
	private function sanitize_settings( array $settings ): array {
		return array(
			'layout'        => sanitize_key( (string) ( $settings['layout'] ?? 'boxed' ) ),
			'customCss'     => wp_strip_all_tags( (string) ( $settings['customCss'] ?? '' ) ),
			'hideTitle'     => ! empty( $settings['hideTitle'] ),
			'hideHeader'    => ! empty( $settings['hideHeader'] ),
			'hideFooter'    => ! empty( $settings['hideFooter'] ),
			'background'    => is_array( $settings['background'] ?? null ) ? $settings['background'] : array(),
		);
	}
}
