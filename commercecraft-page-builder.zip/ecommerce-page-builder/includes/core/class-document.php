<?php
/**
 * Document storage and post type integration.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Document
 */
class Document {

	public const POST_TYPE_TEMPLATE = 'ccpb_template';

	public static function init(): void {
		add_action( 'init', array( self::class, 'register_post_types' ) );
		add_filter( 'use_block_editor_for_post', array( self::class, 'disable_block_editor' ), 10, 2 );
		add_action( 'add_meta_boxes', array( self::class, 'add_meta_boxes' ) );
	}

	public static function register_post_types(): void {
		register_post_type(
			self::POST_TYPE_TEMPLATE,
			array(
				'labels'              => array(
					'name'          => __( 'CC Templates', 'commercecraft' ),
					'singular_name' => __( 'CC Template', 'commercecraft' ),
				),
				'public'              => false,
				'show_ui'             => true,
				'show_in_menu'        => 'ccpb-dashboard',
				'show_in_rest'        => true,
				'capability_type'     => 'post',
				'map_meta_cap'        => true,
				'supports'            => array( 'title', 'author', 'thumbnail' ),
				'has_archive'         => false,
				'rewrite'             => false,
			)
		);
	}

	/**
	 * @param bool    $use Block editor flag.
	 * @param \WP_Post $post Post object.
	 */
	public static function disable_block_editor( bool $use, \WP_Post $post ): bool {
		if ( self::is_ccpb_enabled( $post->ID ) ) {
			return false;
		}

		return $use;
	}

	public static function add_meta_boxes(): void {
		$post_types = self::get_supported_post_types();

		foreach ( $post_types as $post_type ) {
			add_meta_box(
				'ccpb-document',
				__( 'CommerceCraft Builder', 'commercecraft' ),
				array( self::class, 'render_meta_box' ),
				$post_type,
				'side',
				'high'
			);
		}
	}

	public static function render_meta_box( \WP_Post $post ): void {
		$enabled = self::is_ccpb_enabled( $post->ID );
		$edit_url = Editor_Link::get( $post->ID );

		wp_nonce_field( 'ccpb_enable_document', 'ccpb_enable_nonce' );

		echo '<p><label><input type="checkbox" name="ccpb_enabled" value="1" ' . checked( $enabled, true, false ) . ' /> ';
		esc_html_e( 'Enable CommerceCraft Builder', 'commercecraft' );
		echo '</label></p>';

		if ( $enabled ) {
			echo '<p><a class="button button-primary" href="' . esc_url( $edit_url ) . '">';
			esc_html_e( 'Edit with CommerceCraft', 'commercecraft' );
			echo '</a></p>';
		}
	}

	/**
	 * @return array<int, string>
	 */
	public static function get_supported_post_types(): array {
		$defaults = array( 'page', 'post' );

		if ( class_exists( 'WooCommerce' ) ) {
			$defaults[] = 'product';
		}

		return apply_filters( 'ccpb/supported_post_types', $defaults );
	}

	public static function is_ccpb_enabled( int $post_id ): bool {
		return (bool) get_post_meta( $post_id, '_ccpb_enabled', true );
	}

	public static function set_enabled( int $post_id, bool $enabled ): void {
		update_post_meta( $post_id, '_ccpb_enabled', $enabled ? '1' : '' );
	}

	/**
	 * @return array<string, mixed>
	 */
	public static function get( int $post_id ): array {
		$raw = get_post_meta( $post_id, Builder::META_KEY, true );

		if ( ! is_array( $raw ) ) {
			$raw = array(
				'version'  => '1.0',
				'elements' => array(),
				'globals'  => array(),
				'settings' => array(),
			);
		}

		return apply_filters( 'ccpb/get_document', $raw, $post_id );
	}

	/**
	 * @param array<string, mixed> $document Document data.
	 */
	public static function save( int $post_id, array $document, string $status = 'draft' ): bool {
		$sanitized = ccpb()->builder()->sanitize_document( $document );

		update_post_meta( $post_id, Builder::META_KEY, $sanitized );
		update_post_meta( $post_id, Builder::STATUS_META_KEY, sanitize_key( $status ) );
		update_post_meta( $post_id, '_ccpb_enabled', '1' );

		do_action( 'ccpb/save_document', $post_id, $sanitized, $status );

		return true;
	}

	public static function get_status( int $post_id ): string {
		return (string) get_post_meta( $post_id, Builder::STATUS_META_KEY, true ) ?: 'draft';
	}

	/**
	 * Duplicate a document to a new post.
	 */
	public static function duplicate( int $post_id ): int|\WP_Error {
		$post = get_post( $post_id );

		if ( ! $post ) {
			return new \WP_Error( 'not_found', __( 'Post not found.', 'commercecraft' ) );
		}

		$new_id = wp_insert_post(
			array(
				'post_title'  => $post->post_title . ' (Copy)',
				'post_type'   => $post->post_type,
				'post_status' => 'draft',
				'post_author' => get_current_user_id(),
			),
			true
		);

		if ( is_wp_error( $new_id ) ) {
			return $new_id;
		}

		$document = self::get( $post_id );
		self::save( $new_id, $document, 'draft' );

		return $new_id;
	}
}
