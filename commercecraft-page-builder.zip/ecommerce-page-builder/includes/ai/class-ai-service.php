<?php
/**
 * AI content generation service.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Ai;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ai_Service {

	/**
	 * Generate content via configured AI provider.
	 *
	 * @param array<string, mixed> $context Context data.
	 * @return string|\WP_Error
	 */
	public static function generate( string $type, string $prompt, array $context = array() ) {
		$api_key = get_option( 'ccpb_ai_api_key', '' );

		if ( ! $api_key ) {
			return self::fallback_generate( $type, $prompt, $context );
		}

		$system_prompts = array(
			'layout'      => 'Generate a JSON page layout for an eCommerce store.',
			'heading'     => 'Generate a compelling eCommerce heading.',
			'description' => 'Generate a product description.',
			'faq'         => 'Generate FAQ items as JSON array.',
			'banner'      => 'Generate promotional banner copy.',
			'cta'         => 'Generate call-to-action text.',
			'seo'         => 'Generate SEO meta title and description.',
			'palette'     => 'Generate a color palette as JSON.',
		);

		$response = wp_remote_post(
			'https://api.openai.com/v1/chat/completions',
			array(
				'timeout' => 30,
				'headers' => array(
					'Authorization' => 'Bearer ' . $api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'model'    => 'gpt-4o-mini',
						'messages' => array(
							array( 'role' => 'system', 'content' => $system_prompts[ $type ] ?? 'Generate eCommerce content.' ),
							array( 'role' => 'user', 'content' => $prompt ),
						),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		return $body['choices'][0]['message']['content'] ?? new \WP_Error( 'ai_error', __( 'AI generation failed.', 'commercecraft' ) );
	}

	/**
	 * Offline fallback when no API key is configured.
	 *
	 * @param array<string, mixed> $context Context.
	 */
	private static function fallback_generate( string $type, string $prompt, array $context ): string {
		return match ( $type ) {
			'heading'     => 'Discover Our Latest Collection',
			'description' => 'Premium quality products crafted for your lifestyle. Shop now and enjoy free shipping on orders over $50.',
			'cta'         => 'Shop Now',
			'banner'      => 'Summer Sale — Up to 40% Off',
			'layout'      => wp_json_encode( array(
				array(
					'type' => 'container',
					'settings' => array( 'width' => 'boxed' ),
					'children' => array(
						array( 'type' => 'heading', 'settings' => array( 'text' => 'Welcome to Our Store', 'tag' => 'h1' ) ),
						array( 'type' => 'product-grid', 'settings' => array( 'columns' => 4, 'limit' => 8 ) ),
					),
				),
			) ) ?: '{}',
			'palette'     => wp_json_encode( array(
				array( 'id' => 'primary', 'value' => '#2563eb' ),
				array( 'id' => 'secondary', 'value' => '#64748b' ),
				array( 'id' => 'accent', 'value' => '#f59e0b' ),
			) ) ?: '{}',
			default       => sanitize_text_field( $prompt ),
		};
	}
}
