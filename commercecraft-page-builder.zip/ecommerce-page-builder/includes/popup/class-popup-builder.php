<?php
/**
 * Popup builder module.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Popup;

use CommerceCraft\Core\Document;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Popup_Builder {

	public const POST_TYPE = 'ccpb_popup';
	public const META_TRIGGER = '_ccpb_popup_trigger';
	public const META_SETTINGS = '_ccpb_popup_settings';

	public static function init(): void {
		add_action( 'init', array( self::class, 'register_post_type' ) );
		add_action( 'wp_footer', array( self::class, 'render_popups' ) );
		add_action( 'admin_menu', array( self::class, 'register_menu' ) );
		add_action( 'add_meta_boxes', array( self::class, 'add_meta_boxes' ) );
		add_action( 'save_post_' . self::POST_TYPE, array( self::class, 'save_meta' ) );
		add_filter( 'ccpb/supported_post_types', array( self::class, 'add_post_type' ) );
	}

	/**
	 * @param array<int, string> $types Post types.
	 * @return array<int, string>
	 */
	public static function add_post_type( array $types ): array {
		$types[] = self::POST_TYPE;
		return $types;
	}

	public static function add_meta_boxes(): void {
		add_meta_box(
			'ccpb-popup-settings',
			__( 'Popup Settings', 'commercecraft' ),
			array( self::class, 'render_meta_box' ),
			self::POST_TYPE,
			'side'
		);
	}

	public static function render_meta_box( \WP_Post $post ): void {
		wp_nonce_field( 'ccpb_popup_settings', 'ccpb_popup_nonce' );
		$trigger  = get_post_meta( $post->ID, self::META_TRIGGER, true ) ?: 'load';
		$settings = get_post_meta( $post->ID, self::META_SETTINGS, true ) ?: array();
		$edit_url = \CommerceCraft\Core\Editor_Link::get( $post->ID );

		echo '<p><label>' . esc_html__( 'Trigger', 'commercecraft' ) . '</label><br/>';
		echo '<select name="ccpb_popup_trigger" style="width:100%">';
		foreach ( array( 'load' => 'Page Load', 'exit' => 'Exit Intent', 'scroll' => 'Scroll', 'click' => 'Click' ) as $val => $label ) {
			printf( '<option value="%s" %s>%s</option>', esc_attr( $val ), selected( $trigger, $val, false ), esc_html( $label ) );
		}
		echo '</select></p>';
		printf( '<p><label>%s</label><br/><input type="number" name="ccpb_popup_delay" value="%d" min="0" style="width:100%%"/></p>',
			esc_html__( 'Delay (seconds)', 'commercecraft' ),
			(int) ( $settings['delay'] ?? 0 )
		);
		printf( '<p><a class="button button-primary" href="%s">%s</a></p>', esc_url( $edit_url ), esc_html__( 'Edit with CommerceCraft', 'commercecraft' ) );
	}

	public static function save_meta( int $post_id ): void {
		if ( ! isset( $_POST['ccpb_popup_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST['ccpb_popup_nonce'] ) ), 'ccpb_popup_settings' ) ) {
			return;
		}
		update_post_meta( $post_id, self::META_TRIGGER, sanitize_key( (string) ( $_POST['ccpb_popup_trigger'] ?? 'load' ) ) );
		update_post_meta( $post_id, self::META_SETTINGS, array(
			'delay'         => (int) ( $_POST['ccpb_popup_delay'] ?? 0 ),
			'scrollPercent' => 50,
		) );
		\CommerceCraft\Core\Document::set_enabled( $post_id, true );
	}

	public static function register_post_type(): void {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'       => array(
					'name'          => __( 'Popups', 'commercecraft' ),
					'singular_name' => __( 'Popup', 'commercecraft' ),
					'add_new'       => __( 'Add Popup', 'commercecraft' ),
				),
				'public'       => false,
				'show_ui'      => true,
				'show_in_menu' => 'ccpb-dashboard',
				'show_in_rest' => true,
				'supports'     => array( 'title' ),
			)
		);
	}

	public static function register_menu(): void {
		add_submenu_page(
			'ccpb-dashboard',
			__( 'Popups', 'commercecraft' ),
			__( 'Popups', 'commercecraft' ),
			'edit_posts',
			'edit.php?post_type=' . self::POST_TYPE
		);
	}

	public static function render_popups(): void {
		if ( is_admin() ) {
			return;
		}

		$query = new \WP_Query(
			array(
				'post_type'      => self::POST_TYPE,
				'posts_per_page' => 20,
				'post_status'    => 'publish',
			)
		);

		foreach ( $query->posts as $popup ) {
			$settings = get_post_meta( $popup->ID, self::META_SETTINGS, true );
			$trigger  = get_post_meta( $popup->ID, self::META_TRIGGER, true ) ?: 'load';
			$document = Document::get( $popup->ID );

			if ( empty( $document['elements'] ) ) {
				continue;
			}

			$html = ccpb()->widgets()->render_tree( $document['elements'], $popup->ID );

			printf(
				'<div class="ccpb-popup" id="ccpb-popup-%1$d" data-trigger="%2$s" data-delay="%3$d" data-scroll="%4$d" style="display:none"><div class="ccpb-popup-overlay"></div><div class="ccpb-popup-content">%5$s<button class="ccpb-popup-close">&times;</button></div></div>',
				(int) $popup->ID,
				esc_attr( $trigger ),
				(int) ( $settings['delay'] ?? 0 ),
				(int) ( $settings['scrollPercent'] ?? 50 ),
				$html
			);
		}
	}
}
