<?php
/**
 * PSR-4 style autoloader for CommerceCraft.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Autoloader
 */
final class Autoloader {

	/**
	 * Registered namespace prefixes.
	 *
	 * @var array<string, string>
	 */
	private static array $prefixes = array();

	/**
	 * Register autoloader for a namespace prefix.
	 *
	 * @param string $prefix    Namespace prefix.
	 * @param string $base_dir  Base directory.
	 */
	public static function register( string $prefix, string $base_dir ): void {
		self::$prefixes[ rtrim( $prefix, '\\' ) . '\\' ] = rtrim( $base_dir, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR;

		spl_autoload_register( array( self::class, 'load' ) );
	}

	/**
	 * Load a class file.
	 *
	 * @param string $class Fully qualified class name.
	 */
	public static function load( string $class ): void {
		foreach ( self::$prefixes as $prefix => $base_dir ) {
			if ( 0 !== strpos( $class, $prefix ) ) {
				continue;
			}

			$relative = substr( $class, strlen( $prefix ) );
			$relative = str_replace( '\\', DIRECTORY_SEPARATOR, $relative );
			$relative = strtolower( preg_replace( '/([a-z])([A-Z])/', '$1-$2', $relative ) ?? $relative );
			$relative = str_replace( '_', '-', $relative );

			$parts    = explode( DIRECTORY_SEPARATOR, $relative );
			$class_file = array_pop( $parts );
			$path       = $base_dir;

			if ( ! empty( $parts ) ) {
				$path .= implode( DIRECTORY_SEPARATOR, $parts ) . DIRECTORY_SEPARATOR;
			}

			$file = $path . 'class-' . $class_file . '.php';

			if ( is_readable( $file ) ) {
				require_once $file;
			}

			return;
		}
	}
}
