<?php
/**
 * Admin dashboard and menus.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Admin {

	public static function init(): void {
		add_action( 'admin_menu', array( self::class, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue_assets' ) );
		add_filter( 'post_row_actions', array( self::class, 'add_row_action' ), 10, 2 );
		add_action( 'save_post', array( self::class, 'save_meta' ) );
	}

	public static function register_menu(): void {
		add_menu_page(
			__( 'CommerceCraft', 'commercecraft' ),
			__( 'CommerceCraft', 'commercecraft' ),
			'edit_posts',
			'ccpb-dashboard',
			array( self::class, 'render_dashboard' ),
			'dashicons-layout',
			58
		);

		add_submenu_page(
			'ccpb-dashboard',
			__( 'Templates', 'commercecraft' ),
			__( 'Templates', 'commercecraft' ),
			'edit_posts',
			'edit.php?post_type=ccpb_template'
		);

		add_submenu_page(
			'ccpb-dashboard',
			__( 'Theme Builder', 'commercecraft' ),
			__( 'Theme Builder', 'commercecraft' ),
			'edit_posts',
			'ccpb-theme-builder',
			array( self::class, 'render_theme_builder' )
		);

		add_submenu_page(
			'ccpb-dashboard',
			__( 'Popups', 'commercecraft' ),
			__( 'Popups', 'commercecraft' ),
			'edit_posts',
			'edit.php?post_type=ccpb_popup'
		);

		add_submenu_page(
			'ccpb-dashboard',
			__( 'Global Settings', 'commercecraft' ),
			__( 'Global Settings', 'commercecraft' ),
			'manage_options',
			'ccpb-globals',
			array( self::class, 'render_globals' )
		);
	}

	public static function render_dashboard(): void {
		echo '<div class="wrap ccpb-dashboard">';
		echo '<h1>' . esc_html__( 'CommerceCraft Page Builder', 'commercecraft' ) . '</h1>';
		echo '<p>' . esc_html__( 'Build beautiful eCommerce pages visually. Edit any page with CommerceCraft from the page list or post editor.', 'commercecraft' ) . '</p>';

		echo '<div class="ccpb-dashboard-cards" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin:24px 0;">';
		$cards = array(
			array( admin_url( 'edit.php?post_type=page' ), __( 'Manage Pages', 'commercecraft' ), __( 'Create and edit store pages', 'commercecraft' ) ),
			array( admin_url( 'admin.php?page=ccpb-theme-builder' ), __( 'Theme Builder', 'commercecraft' ), __( 'Assign templates to shop locations', 'commercecraft' ) ),
			array( admin_url( 'edit.php?post_type=ccpb_template' ), __( 'Templates', 'commercecraft' ), __( 'Reusable sections and layouts', 'commercecraft' ) ),
			array( admin_url( 'edit.php?post_type=ccpb_popup' ), __( 'Popups', 'commercecraft' ), __( 'Newsletter, promo, and exit popups', 'commercecraft' ) ),
			array( admin_url( 'admin.php?page=ccpb-globals' ), __( 'Global Settings', 'commercecraft' ), __( 'Colors, fonts, and AI settings', 'commercecraft' ) ),
		);
		foreach ( $cards as $card ) {
			printf(
				'<a href="%s" class="card" style="display:block;padding:20px;background:#fff;border:1px solid #c3c4c7;border-radius:8px;text-decoration:none;color:inherit;"><strong style="font-size:15px;">%s</strong><br><span style="color:#646970;margin-top:6px;display:inline-block;">%s</span></a>',
				esc_url( $card[0] ),
				esc_html( $card[1] ),
				esc_html( $card[2] )
			);
		}
		echo '</div>';

		echo '<a class="button button-primary button-hero" href="' . esc_url( admin_url( 'post-new.php?post_type=page' ) ) . '">' . esc_html__( 'Create New Page', 'commercecraft' ) . '</a>';
		echo '</div>';
	}

	public static function render_theme_builder(): void {
		include CCPB_PLUGIN_DIR . 'templates/admin/theme-builder.php';
	}

	public static function render_globals(): void {
		include CCPB_PLUGIN_DIR . 'templates/admin/globals.php';
	}

	public static function enqueue_assets( string $hook ): void {
		if ( str_contains( $hook, 'ccpb' ) ) {
			wp_enqueue_style( 'ccpb-admin', CCPB_PLUGIN_URL . 'assets/css/admin.css', array(), CCPB_VERSION );
		}
	}

	/**
	 * @param array<string, string> $actions Row actions.
	 * @return array<string, string>
	 */
	public static function add_row_action( array $actions, \WP_Post $post ): array {
		if ( in_array( $post->post_type, \CommerceCraft\Core\Document::get_supported_post_types(), true ) ) {
			$url = \CommerceCraft\Core\Editor_Link::get( $post->ID );
			$actions['ccpb_edit'] = sprintf(
				'<a href="%s">%s</a>',
				esc_url( $url ),
				esc_html__( 'Edit with CommerceCraft', 'commercecraft' )
			);
		}

		return $actions;
	}

	public static function save_meta( int $post_id ): void {
		if ( ! isset( $_POST['ccpb_enable_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST['ccpb_enable_nonce'] ) ), 'ccpb_enable_document' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		$enabled = ! empty( $_POST['ccpb_enabled'] );
		\CommerceCraft\Core\Document::set_enabled( $post_id, $enabled );
	}
}
