<?php
/**
 * Visual editor loader.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Admin;

use CommerceCraft\Core\Document;
use CommerceCraft\Core\Editor_Link;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Editor {

	public static function init(): void {
		add_action( 'admin_init', array( self::class, 'maybe_load_editor' ) );
		add_action( 'template_redirect', array( self::class, 'maybe_load_frontend_editor' ) );
	}

	public static function maybe_load_editor(): void {
		if ( ! isset( $_GET['action'], $_GET['post'] ) || 'ccpb_edit' !== $_GET['action'] ) {
			return;
		}

		$post_id = (int) $_GET['post'];

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			wp_die( esc_html__( 'You do not have permission to edit this page.', 'commercecraft' ) );
		}

		Document::set_enabled( $post_id, true );
		self::render_editor( $post_id, sanitize_key( (string) ( $_GET['mode'] ?? 'backend' ) ) );
		exit;
	}

	public static function maybe_load_frontend_editor(): void {
		if ( ! isset( $_GET['ccpb-preview'] ) || ! is_user_logged_in() ) {
			return;
		}

		$post_id = get_queried_object_id();

		if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( ! Document::is_ccpb_enabled( $post_id ) ) {
			return;
		}

		add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue_editor_assets' ) );
		add_filter( 'show_admin_bar', '__return_false' );
	}

	public static function render_editor( int $post_id, string $mode ): void {
		self::enqueue_editor_assets( $post_id );

		$post = get_post( $post_id );

		include CCPB_PLUGIN_DIR . 'templates/editor.php';
	}

	public static function enqueue_editor_assets( int $post_id = 0 ): void {
		if ( ! $post_id ) {
			$post_id = get_queried_object_id();
		}

		wp_enqueue_style(
			'ccpb-editor',
			CCPB_PLUGIN_URL . 'assets/css/editor.css',
			array(),
			CCPB_VERSION
		);

		wp_enqueue_script(
			'ccpb-editor',
			CCPB_PLUGIN_URL . 'assets/js/editor.js',
			array(),
			CCPB_VERSION,
			true
		);

		wp_localize_script(
			'ccpb-editor',
			'ccpbEditor',
			array(
				'postId'       => $post_id,
				'postTitle'    => get_the_title( $post_id ),
				'restUrl'      => rest_url( 'commercecraft/v1/' ),
				'nonce'        => wp_create_nonce( 'wp_rest' ),
				'previewUrl'   => Editor_Link::get_frontend( $post_id ),
				'adminUrl'     => admin_url(),
				'widgets'      => ccpb()->widgets()->get_editor_config(),
				'breakpoints'  => ccpb()->builder()->get_breakpoints(),
				'globals'      => ccpb()->design_system()->get_all(),
				'templates'    => \CommerceCraft\Core\Templates::get_library(),
				'aiEnabled'    => (bool) get_option( 'ccpb_ai_api_key', '' ),
				'i18n'         => array(
					'save'     => __( 'Save', 'commercecraft' ),
					'publish'  => __( 'Publish', 'commercecraft' ),
					'preview'  => __( 'Preview', 'commercecraft' ),
					'undo'     => __( 'Undo', 'commercecraft' ),
					'redo'     => __( 'Redo', 'commercecraft' ),
				),
			)
		);
	}
}
