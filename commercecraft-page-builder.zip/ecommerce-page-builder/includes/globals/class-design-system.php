<?php
/**
 * Global design system.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Globals;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Design_System {

	public const OPTION_KEY = 'ccpb_globals';

	public function init(): void {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	public function register_settings(): void {
		register_setting( 'ccpb_globals', self::OPTION_KEY, array( $this, 'sanitize' ) );
		register_setting( 'ccpb_globals', 'ccpb_ai_api_key', array(
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
		) );
	}

	/**
	 * @return array<string, mixed>
	 */
	public function get_all(): array {
		$defaults = array(
			'colors'   => array(
				array( 'id' => 'primary', 'value' => '#2563eb', 'label' => 'Primary' ),
				array( 'id' => 'secondary', 'value' => '#64748b', 'label' => 'Secondary' ),
				array( 'id' => 'accent', 'value' => '#f59e0b', 'label' => 'Accent' ),
			),
			'fonts'    => array(
				array( 'id' => 'heading', 'family' => 'Inter, sans-serif', 'label' => 'Heading' ),
				array( 'id' => 'body', 'family' => 'Inter, sans-serif', 'label' => 'Body' ),
			),
			'buttons'  => array(
				'primary' => array( 'bg' => '#2563eb', 'color' => '#fff', 'radius' => '6px' ),
			),
			'spacing'  => array( 'unit' => 'px', 'scale' => array( 4, 8, 16, 24, 32, 48, 64 ) ),
			'shadows'  => array(),
			'icons'    => array(),
		);

		$stored = get_option( self::OPTION_KEY, array() );

		return wp_parse_args( is_array( $stored ) ? $stored : array(), $defaults );
	}

	/**
	 * @param array<string, mixed> $input Raw input.
	 * @return array<string, mixed>
	 */
	public function sanitize( array $input ): array {
		return $input;
	}

	public function get_css_variables(): string {
		$globals = $this->get_all();
		$vars    = array();

		foreach ( $globals['colors'] as $color ) {
			if ( ! empty( $color['id'] ) && ! empty( $color['value'] ) ) {
				$vars[] = '--ccpb-color-' . sanitize_key( $color['id'] ) . ':' . $color['value'];
			}
		}

		foreach ( $globals['fonts'] as $font ) {
			if ( ! empty( $font['id'] ) && ! empty( $font['family'] ) ) {
				$vars[] = '--ccpb-font-' . sanitize_key( $font['id'] ) . ':' . $font['family'];
			}
		}

		return ':root{' . implode( ';', $vars ) . '}';
	}
}
