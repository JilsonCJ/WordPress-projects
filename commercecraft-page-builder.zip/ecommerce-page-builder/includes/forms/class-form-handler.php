<?php
/**
 * Form submission handlers.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Forms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Form_Handler {

	public static function init(): void {
		add_action( 'admin_post_nopriv_ccpb_contact', array( self::class, 'handle_contact' ) );
		add_action( 'admin_post_ccpb_contact', array( self::class, 'handle_contact' ) );
		add_action( 'admin_post_nopriv_ccpb_newsletter', array( self::class, 'handle_newsletter' ) );
		add_action( 'admin_post_ccpb_newsletter', array( self::class, 'handle_newsletter' ) );
	}

	public static function handle_contact(): void {
		check_admin_referer( 'ccpb_contact', 'ccpb_nonce' );

		$name    = sanitize_text_field( wp_unslash( (string) ( $_POST['name'] ?? '' ) ) );
		$email   = sanitize_email( wp_unslash( (string) ( $_POST['email'] ?? '' ) ) );
		$message = sanitize_textarea_field( wp_unslash( (string) ( $_POST['message'] ?? '' ) ) );

		wp_mail(
			get_option( 'admin_email' ),
			sprintf( '[%s] Contact Form', get_bloginfo( 'name' ) ),
			"Name: {$name}\nEmail: {$email}\n\n{$message}"
		);

		wp_safe_redirect( wp_get_referer() ?: home_url( '/' ) );
		exit;
	}

	public static function handle_newsletter(): void {
		check_admin_referer( 'ccpb_newsletter', 'ccpb_nonce' );

		$email = sanitize_email( wp_unslash( (string) ( $_POST['email'] ?? '' ) ) );

		if ( $email ) {
			$subscribers = get_option( 'ccpb_newsletter_subscribers', array() );
			if ( ! is_array( $subscribers ) ) {
				$subscribers = array();
			}
			if ( ! in_array( $email, $subscribers, true ) ) {
				$subscribers[] = $email;
				update_option( 'ccpb_newsletter_subscribers', $subscribers );
			}
		}

		wp_safe_redirect( wp_get_referer() ?: home_url( '/' ) );
		exit;
	}
}
