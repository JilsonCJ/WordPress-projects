<?php
/**
 * Developer hooks and extension API.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Developer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Hooks {

	public static function init(): void {
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			require_once CCPB_PLUGIN_DIR . 'includes/developer/class-cli.php';
			\WP_CLI::add_command( 'ccpb', Cli::class );
		}
	}
}

/**
 * Register a custom widget.
 *
 * @param \CommerceCraft\Widgets\Widget_Base $widget Widget instance.
 */
function ccpb_register_widget( \CommerceCraft\Widgets\Widget_Base $widget ): void {
	ccpb()->widgets()->register( $widget );
}

/**
 * Get document data.
 *
 * @return array<string, mixed>
 */
function ccpb_get_document( int $post_id ): array {
	return \CommerceCraft\Core\Document::get( $post_id );
}

/**
 * Render document.
 */
function ccpb_render_document( int $post_id ): string {
	$document = ccpb_get_document( $post_id );
	return ccpb()->widgets()->render_tree( $document['elements'] ?? array(), $post_id );
}
