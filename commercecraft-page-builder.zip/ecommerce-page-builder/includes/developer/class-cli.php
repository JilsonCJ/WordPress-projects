<?php
/**
 * WP-CLI commands.
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

namespace CommerceCraft\Developer;

use CommerceCraft\Core\Document;
use CommerceCraft\Core\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Cli {

	/**
	 * Export a document to JSON file.
	 *
	 * ## OPTIONS
	 *
	 * <post_id>
	 * : Post ID to export.
	 *
	 * [--file=<file>]
	 * : Output file path.
	 */
	public function export( array $args, array $assoc_args ): void {
		$post_id = (int) $args[0];
		$file    = $assoc_args['file'] ?? 'ccpb-export-' . $post_id . '.json';
		$json    = wp_json_encode( Document::get( $post_id ), JSON_PRETTY_PRINT );
		file_put_contents( $file, $json );
		\WP_CLI::success( "Exported to {$file}" );
	}

	/**
	 * Import a template from JSON file.
	 *
	 * ## OPTIONS
	 *
	 * <file>
	 * : JSON file path.
	 */
	public function import( array $args ): void {
		$json = file_get_contents( $args[0] );
		$id   = Templates::import( $json ?: '{}' );
		if ( is_wp_error( $id ) ) {
			\WP_CLI::error( $id->get_error_message() );
		}
		\WP_CLI::success( "Imported template ID: {$id}" );
	}
}
