<?php
/**
 * Editor shell template.
 *
 * @package CommerceCraft
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo esc_html( get_the_title( $post_id ) ); ?> — CommerceCraft</title>
	<?php wp_head(); ?>
</head>
<body class="ccpb-editor-body">
	<div id="ccpb-editor-root"></div>
	<?php wp_footer(); ?>
</body>
</html>
