<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$location = ccpb()->theme_builder()->detect_location();
$post_id = $location ? ccpb()->theme_builder()->get_template_id( $location ) : 0;
if ( $post_id ) {
	echo ccpb()->widgets()->render_tree( \CommerceCraft\Core\Document::get( $post_id )['elements'] ?? array(), $post_id );
} else {
	the_content();
}
get_footer();
