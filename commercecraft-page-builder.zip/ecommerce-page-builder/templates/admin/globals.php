<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$globals = ccpb()->design_system()->get_all();
?>
<div class="wrap">
	<h1><?php esc_html_e( 'Global Design System', 'commercecraft' ); ?></h1>
	<form method="post" action="options.php">
		<?php settings_fields( 'ccpb_globals' ); ?>
		<h2><?php esc_html_e( 'Global Colors', 'commercecraft' ); ?></h2>
		<table class="form-table">
			<?php foreach ( $globals['colors'] as $i => $color ) : ?>
				<tr>
					<th><?php echo esc_html( $color['label'] ?? $color['id'] ); ?></th>
					<td><input type="color" name="ccpb_globals[colors][<?php echo (int) $i; ?>][value]" value="<?php echo esc_attr( $color['value'] ); ?>"/>
					<input type="hidden" name="ccpb_globals[colors][<?php echo (int) $i; ?>][id]" value="<?php echo esc_attr( $color['id'] ); ?>"/>
					<input type="hidden" name="ccpb_globals[colors][<?php echo (int) $i; ?>][label]" value="<?php echo esc_attr( $color['label'] ?? '' ); ?>"/></td>
				</tr>
			<?php endforeach; ?>
		</table>
		<h2><?php esc_html_e( 'AI Settings', 'commercecraft' ); ?></h2>
		<table class="form-table">
			<tr><th><?php esc_html_e( 'OpenAI API Key', 'commercecraft' ); ?></th>
			<td><input type="password" name="ccpb_ai_api_key" value="<?php echo esc_attr( get_option( 'ccpb_ai_api_key', '' ) ); ?>" class="regular-text"/></td></tr>
		</table>
		<?php submit_button(); ?>
	</form>
</div>
