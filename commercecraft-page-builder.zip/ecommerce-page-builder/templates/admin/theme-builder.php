<?php
/**
 * Theme builder assignment handler.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( isset( $_POST['ccpb_theme_assign'] ) && check_admin_referer( 'ccpb_theme_builder' ) && current_user_can( 'edit_posts' ) ) {
	$templates = array();
	if ( ! empty( $_POST['templates'] ) && is_array( $_POST['templates'] ) ) {
		foreach ( $_POST['templates'] as $location => $page_id ) {
			$templates[ sanitize_key( $location ) ] = (int) $page_id;
		}
	}
	update_option( 'ccpb_theme_templates', $templates );
	echo '<div class="notice notice-success"><p>' . esc_html__( 'Templates assigned.', 'commercecraft' ) . '</p></div>';
}

$locations = ccpb()->theme_builder()->get_locations();
$templates = get_option( 'ccpb_theme_templates', array() );
$pages = get_posts( array( 'post_type' => 'page', 'posts_per_page' => 100, 'post_status' => 'publish' ) );
?>
<div class="wrap ccpb-theme-builder">
	<h1><?php esc_html_e( 'Theme Builder', 'commercecraft' ); ?></h1>
	<p><?php esc_html_e( 'Assign CommerceCraft pages to theme locations.', 'commercecraft' ); ?></p>
	<form method="post">
		<?php wp_nonce_field( 'ccpb_theme_builder' ); ?>
		<table class="widefat">
			<thead><tr><th><?php esc_html_e( 'Location', 'commercecraft' ); ?></th><th><?php esc_html_e( 'Page Template', 'commercecraft' ); ?></th></tr></thead>
			<tbody>
			<?php foreach ( $locations as $key => $label ) : ?>
				<tr>
					<td><strong><?php echo esc_html( $label ); ?></strong></td>
					<td>
						<select name="templates[<?php echo esc_attr( $key ); ?>]">
							<option value="0"><? esc_html_e( '— Default —', 'commercecraft' ); ?></option>
							<?php foreach ( $pages as $page ) : ?>
								<option value="<?php echo (int) $page->ID; ?>" <?php selected( (int) ( $templates[ $key ] ?? 0 ), $page->ID ); ?>>
									<?php echo esc_html( $page->post_title ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p><input type="submit" name="ccpb_theme_assign" class="button button-primary" value="<? esc_attr_e( 'Save Assignments', 'commercecraft' ); ?>"/></p>
	</form>
</div>
