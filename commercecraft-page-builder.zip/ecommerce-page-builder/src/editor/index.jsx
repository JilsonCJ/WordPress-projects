/**
 * React editor entry (optional rebuild via npm run build:react).
 * The plugin ships with a pre-built vanilla JS editor in assets/js/editor.js.
 */
import { createRoot } from 'react-dom/client';

function App() {
	return (
		<div style={{ padding: 40, textAlign: 'center', color: '#fff' }}>
			<h2>CommerceCraft React Editor</h2>
			<p>Run <code>npm run build:react</code> to build. The vanilla JS editor is active by default.</p>
		</div>
	);
}

document.addEventListener('DOMContentLoaded', () => {
	const root = document.getElementById('ccpb-editor-root');
	if (root && window.ccpbUseReact) {
		createRoot(root).render(<App />);
	}
});
