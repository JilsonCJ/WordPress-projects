# CommerceCraft Page Builder

Professional visual drag-and-drop page builder for WordPress eCommerce stores.

## Requirements

- WordPress 6.4+
- PHP 8.1+
- WooCommerce (recommended for eCommerce widgets)

## Installation

1. Copy the `ecommerce-page-builder` folder to your WordPress `wp-content/plugins/` directory
2. Activate **CommerceCraft Page Builder** in WordPress Admin → Plugins
3. Install and activate **WooCommerce** for full store widgets
4. Edit any page → enable CommerceCraft → click **Edit with CommerceCraft**

### LocalWP (site-2.local)

Your environment (PHP 8.4, MySQL 8.0, nginx) is fully supported. Point LocalWP's site plugins folder to this plugin or symlink it.

## Quick Start

1. Go to **Pages → Add New**
2. Check **Enable CommerceCraft Builder** in the sidebar
3. Click **Edit with CommerceCraft**
4. Drag widgets from the left panel onto the canvas
5. Click elements to edit settings in the right panel
6. Use device switcher for responsive preview
7. **Save** or **Publish** when done

## Editor Features

| Feature | Shortcut |
|---------|----------|
| Undo | Ctrl+Z |
| Redo | Ctrl+Y |
| Save | Ctrl+S |
| Copy element | Ctrl+C |
| Paste element | Ctrl+V |
| Duplicate | Ctrl+D |
| Delete | Delete |

## Plugin Structure

```
ecommerce-page-builder/
├── ecommerce-page-builder.php   # Main plugin file
├── includes/
│   ├── core/                    # Builder engine, documents, revisions
│   ├── widgets/                 # All widget classes
│   ├── admin/                   # Editor & dashboard
│   ├── api/                     # REST API
│   ├── theme-builder/           # Theme template overrides
│   ├── globals/                 # Design system
│   ├── ai/                      # AI generation
│   ├── performance/             # Optimizations
│   └── developer/               # Hooks, CLI, extension API
├── assets/
│   ├── css/                     # Editor & frontend styles
│   └── js/                      # Editor & frontend scripts
└── templates/                   # PHP templates
```

## REST API

Base URL: `/wp-json/commercecraft/v1/`

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/document/{id}` | GET/POST | Load/save document |
| `/document/{id}/duplicate` | POST | Duplicate page |
| `/document/{id}/revisions` | GET | List revisions |
| `/templates` | GET/POST | Template library |
| `/ai/generate` | POST | AI content generation |
| `/widgets` | GET | Widget registry |

## Developer Extension

Register custom widgets:

```php
add_action( 'ccpb/register_widgets', function( $manager ) {
    $manager->register( new My_Custom_Widget() );
});
```

Extend a widget:

```php
class My_Custom_Widget extends \CommerceCraft\Widgets\Widget_Base {
    protected string $name = 'my-widget';
    protected string $title = 'My Widget';
    protected string $category = 'content';

    protected function render_content( array $element, int $post_id = 0 ): string {
        return '<div>Hello World</div>';
    }
}
```

## AI Features

Add your OpenAI API key under **CommerceCraft → Global Settings**. Without a key, offline fallback templates are used.

Supported AI types: layout, heading, description, banner, CTA, palette, FAQ, SEO.

## Theme Builder

Assign templates to locations under **CommerceCraft → Theme Builder**:

- Header, Footer, Homepage, Shop, Product, Cart, Checkout, My Account, 404, and more.

## WP-CLI

```bash
wp ccpb export 123 --file=page.json
wp ccpb import template.json
```

## Widget Library (60+)

**Layout:** Container, Row, Column  
**Content:** Heading, Text, Rich Text, Image, Gallery, Video, Button, Icon, Divider, Spacer, Tabs, Accordion, HTML, Shortcode, Testimonials, Pricing Table, Counter, FAQ, Progress Bar, Icon Box, Team, Timeline  
**eCommerce:** Product Grid/List/Slider, Featured, Sale, Related, Upsells, Cross-sells, Product Card, Category Grid, Add to Cart, Mini Cart  
**Cart:** Cart Drawer, Free Shipping Progress, Coupon Box  
**Checkout:** Billing, Shipping, Payment  
**Customer:** Login, Account Dashboard, Wishlist  
**Marketing:** Announcement Bar, Countdown, Newsletter, Trust Badges, Social Proof, Exit Intent  
**Navigation:** Header Builder, Footer Builder, Breadcrumbs, Search  
**Forms:** Contact Form, Newsletter Form  
**Popups:** Full popup builder with triggers (load, exit, scroll)

## Roadmap

v1.0 delivers the complete foundation. Future versions may add advanced form conditional logic, particle backgrounds, Lottie, and deeper WooCommerce checkout customization.
