=== CommerceCraft Page Builder ===
Contributors: commercecraft
Tags: page builder, ecommerce, woocommerce, drag and drop, visual editor
Requires at least: 6.4
Tested up to: 6.7
Requires PHP: 8.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Professional visual drag-and-drop page builder designed specifically for eCommerce stores.

== Description ==

CommerceCraft is a standalone visual page builder built for WooCommerce stores. No Elementor, Gutenberg blocks, Divi, or other page builder required.

**Core Features:**

* Drag and drop visual editor
* True frontend and backend editing
* Live preview with responsive controls (Desktop, Laptop, Tablet, Mobile)
* Undo/Redo with history manager
* Auto-save and revision history
* Copy, paste, duplicate elements
* Save, import, and export templates
* Global design system (colors, fonts, buttons)
* Theme builder for headers, footers, and WooCommerce pages
* Conditional display logic
* AI content generation
* Performance optimization (lazy load, deferred JS)

**eCommerce Widgets:**

* Product Grid, Slider, Carousel
* Category Grid
* Product Card with ratings, pricing, add to cart
* Mini Cart
* Add to Cart
* Announcement Bar, Countdown, Trust Badges
* Header & Footer Builder

**Content Widgets:**

* Heading, Text, Rich Text, Image, Gallery, Video
* Button, Icon, Divider, Spacer
* Tabs, Accordion, HTML, Shortcode
* Contact Form, Newsletter Form

== Installation ==

1. Upload the `ecommerce-page-builder` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Install and activate WooCommerce for full eCommerce features
4. Edit any page and click "Edit with CommerceCraft"

== Frequently Asked Questions ==

= Does this require Elementor or another page builder? =

No. CommerceCraft is a fully standalone page builder.

= Does it work with WooCommerce? =

Yes. Install WooCommerce to unlock all eCommerce widgets.

= Can I use AI features? =

Yes. Add your OpenAI API key in CommerceCraft > Global Settings.

== Changelog ==

= 1.0.0 =
* Initial release
