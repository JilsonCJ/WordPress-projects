# Build a WordPress-compatible plugin ZIP (forward-slash paths only).
$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$pluginFolderName = Split-Path -Leaf $root
$outZip = Join-Path (Split-Path -Parent $root) 'commercecraft-page-builder.zip'
$excludeDirs = @('node_modules', '.git', '.github', '.vscode')

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

if (Test-Path $outZip) {
	Remove-Item $outZip -Force
}

$zip = [System.IO.Compression.ZipFile]::Open($outZip, [System.IO.Compression.ZipArchiveMode]::Create)

try {
	Get-ChildItem -Path $root -Recurse -File -Force | Where-Object {
		$relative = $_.FullName.Substring($root.Length + 1)
		$parts = $relative -split '[\\/]'
		($parts | Where-Object { $_ -in $excludeDirs }).Count -eq 0
	} | ForEach-Object {
		$relative = $_.FullName.Substring($root.Length + 1).Replace('\', '/')
		$entryName = "$pluginFolderName/$relative"
		[void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $_.FullName, $entryName, [System.IO.Compression.CompressionLevel]::Optimal)
	}
}
finally {
	$zip.Dispose()
}

Write-Host "Created WordPress-compatible ZIP: $outZip"
