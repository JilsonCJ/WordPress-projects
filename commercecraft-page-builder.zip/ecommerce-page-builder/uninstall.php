<?php
/**
 * Uninstall cleanup.
 *
 * @package CommerceCraft
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'ccpb_version' );
delete_option( 'ccpb_globals' );
delete_option( 'ccpb_ai_api_key' );
delete_option( 'ccpb_theme_templates' );
delete_option( 'ccpb_newsletter_subscribers' );
