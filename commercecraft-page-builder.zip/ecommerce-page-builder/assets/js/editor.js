/**
 * CommerceCraft Visual Page Builder Editor
 */
(function () {
	'use strict';

	const config = window.ccpbEditor || {};
	const API = config.restUrl;
	const NONCE = config.nonce;
	const POST_ID = config.postId;

	// ─── State Management ───────────────────────────────────────────
	class HistoryManager {
		constructor(limit = 50) {
			this.stack = [];
			this.pointer = -1;
			this.limit = limit;
		}

		push(state) {
			this.stack = this.stack.slice(0, this.pointer + 1);
			this.stack.push(JSON.parse(JSON.stringify(state)));
			if (this.stack.length > this.limit) this.stack.shift();
			this.pointer = this.stack.length - 1;
		}

		undo() {
			if (this.pointer > 0) {
				this.pointer--;
				return JSON.parse(JSON.stringify(this.stack[this.pointer]));
			}
			return null;
		}

		redo() {
			if (this.pointer < this.stack.length - 1) {
				this.pointer++;
				return JSON.parse(JSON.stringify(this.stack[this.pointer]));
			}
			return null;
		}

		canUndo() { return this.pointer > 0; }
		canRedo() { return this.pointer < this.stack.length - 1; }
	}

	class Clipboard {
		constructor() {
			this.element = null;
			this.styles = null;
		}
	}

	// ─── API Client ─────────────────────────────────────────────────
	async function api(method, endpoint, body) {
		const opts = {
			method,
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': NONCE,
			},
		};
		if (body) opts.body = JSON.stringify(body);
		const res = await fetch(API + endpoint, opts);
		if (!res.ok) throw new Error('API error: ' + res.status);
		return res.json();
	}

	// ─── Element Utilities ──────────────────────────────────────────
	function generateId() {
		return 'el-' + Date.now().toString(36) + Math.random().toString(36).substr(2, 6);
	}

	function findWidget(type) {
		return (config.widgets || []).find(w => w.name === type);
	}

	function createElement(type) {
		const widget = findWidget(type);
		if (!widget) return null;
		const el = JSON.parse(JSON.stringify(widget.defaults));
		el.id = generateId();
		return el;
	}

	function findElement(tree, id) {
		for (const el of tree) {
			if (el.id === id) return el;
			if (el.children) {
				const found = findElement(el.children, id);
				if (found) return found;
			}
		}
		return null;
	}

	function findParent(tree, id, parent = null) {
		for (const el of tree) {
			if (el.id === id) return parent;
			if (el.children) {
				const found = findParent(el.children, id, el);
				if (found !== undefined) return found;
			}
		}
		return undefined;
	}

	function removeElement(tree, id) {
		for (let i = 0; i < tree.length; i++) {
			if (tree[i].id === id) {
				tree.splice(i, 1);
				return true;
			}
			if (tree[i].children && removeElement(tree[i].children, id)) return true;
		}
		return false;
	}

	function duplicateElement(el) {
		const copy = JSON.parse(JSON.stringify(el));
		copy.id = generateId();
		if (copy.children) {
			copy.children = copy.children.map(c => {
				const d = duplicateElement(c);
				return d;
			});
		}
		return copy;
	}

	function getAllElements(tree, result = []) {
		for (const el of tree) {
			result.push(el);
			if (el.children) getAllElements(el.children, result);
		}
		return result;
	}

	// ─── Main Editor ────────────────────────────────────────────────
	class CommerceCraftEditor {
		constructor() {
			this.document = { version: '1.0', elements: [], globals: {}, settings: {} };
			this.selectedId = null;
			this.device = 'desktop';
			this.orientation = 'portrait';
			this.history = new HistoryManager();
			this.clipboard = new Clipboard();
			this.favorites = JSON.parse(localStorage.getItem('ccpb_favorites') || '[]');
			this.leftTab = 'widgets';
			this.rightTab = 'settings';
			this.autosaveTimer = null;
			this.isDirty = false;
			this.searchQuery = '';
			this.root = document.getElementById('ccpb-editor-root');
		}

		async init() {
			try {
				const data = await api('GET', 'document/' + POST_ID);
				this.document = data.document || this.document;
				this.history.push(this.document);
			} catch (e) {
				console.warn('Could not load document, starting fresh.', e);
				this.history.push(this.document);
			}
			this.render();
			this.bindKeyboard();
			this.startAutosave();
		}

		render() {
			this.root.innerHTML = `
				<div class="ccpb-toolbar">
					<div class="ccpb-toolbar-left">
						<button class="ccpb-btn ccpb-btn-icon" data-action="undo" title="Undo (Ctrl+Z)">↩</button>
						<button class="ccpb-btn ccpb-btn-icon" data-action="redo" title="Redo (Ctrl+Y)">↪</button>
						<span class="ccpb-status" id="ccpb-status"></span>
					</div>
					<div class="ccpb-toolbar-center">
						<div class="ccpb-device-switcher">
							<button class="ccpb-btn ccpb-btn-icon ${this.device === 'desktop' ? 'active' : ''}" data-device="desktop" title="Desktop">🖥</button>
							<button class="ccpb-btn ccpb-btn-icon ${this.device === 'laptop' ? 'active' : ''}" data-device="laptop" title="Laptop">💻</button>
							<button class="ccpb-btn ccpb-btn-icon ${this.device === 'tablet' ? 'active' : ''}" data-device="tablet" title="Tablet">📱</button>
							<button class="ccpb-btn ccpb-btn-icon ${this.device === 'mobile' ? 'active' : ''}" data-device="mobile" title="Mobile">📲</button>
							<button class="ccpb-btn ccpb-btn-icon" data-action="toggle-orientation" title="Toggle Orientation">🔄</button>
						</div>
					</div>
					<div class="ccpb-toolbar-right">
						<button class="ccpb-btn" data-action="ai">✨ AI</button>
						<button class="ccpb-btn" data-action="templates">Templates</button>
						<button class="ccpb-btn" data-action="preview">${config.i18n?.preview || 'Preview'}</button>
						<button class="ccpb-btn ccpb-btn-primary" data-action="save">${config.i18n?.save || 'Save'}</button>
						<button class="ccpb-btn ccpb-btn-primary" data-action="publish">${config.i18n?.publish || 'Publish'}</button>
					</div>
				</div>
				<div class="ccpb-workspace">
					<div class="ccpb-panel ccpb-panel-left">
						<div class="ccpb-tabs">
							<div class="ccpb-tab ${this.leftTab === 'widgets' ? 'active' : ''}" data-left-tab="widgets">Widgets</div>
							<div class="ccpb-tab ${this.leftTab === 'navigator' ? 'active' : ''}" data-left-tab="navigator">Navigator</div>
						</div>
						<div id="ccpb-left-content"></div>
					</div>
					<div class="ccpb-canvas-wrap">
						<div class="ccpb-canvas" id="ccpb-canvas" data-device="${this.device}" data-orientation="${this.orientation}"></div>
					</div>
					<div class="ccpb-panel ccpb-panel-right">
						<div class="ccpb-tabs">
							<div class="ccpb-tab ${this.rightTab === 'settings' ? 'active' : ''}" data-right-tab="settings">Settings</div>
							<div class="ccpb-tab ${this.rightTab === 'style' ? 'active' : ''}" data-right-tab="style">Style</div>
							<div class="ccpb-tab ${this.rightTab === 'advanced' ? 'active' : ''}" data-right-tab="advanced">Advanced</div>
						</div>
						<div id="ccpb-right-content"></div>
					</div>
				</div>
			`;
			this.renderLeftPanel();
			this.renderCanvas();
			this.renderRightPanel();
			this.bindEvents();
		}

		renderLeftPanel() {
			const container = document.getElementById('ccpb-left-content');
			if (this.leftTab === 'navigator') {
				container.innerHTML = '<div class="ccpb-navigator">' + this.renderNavigator(this.document.elements, 0) + '</div>';
				return;
			}

			const categories = {};
			(config.widgets || []).forEach(w => {
				if (this.searchQuery && !w.title.toLowerCase().includes(this.searchQuery.toLowerCase()) &&
					!(w.keywords || []).some(k => k.includes(this.searchQuery.toLowerCase()))) return;
				if (!categories[w.category]) categories[w.category] = [];
				categories[w.category].push(w);
			});

			let html = `<input type="text" class="ccpb-search" placeholder="Search elements..." value="${this.searchQuery}" id="ccpb-widget-search"/>`;
			html += '<div class="ccpb-widget-list">';

			for (const [cat, widgets] of Object.entries(categories)) {
				html += `<div class="ccpb-widget-category"><div class="ccpb-widget-category-title">${cat}</div>`;
				widgets.forEach(w => {
					const fav = this.favorites.includes(w.name) ? '★' : '☆';
					html += `<div class="ccpb-widget-item" draggable="true" data-widget="${w.name}">
						<div class="ccpb-widget-icon">${w.icon.charAt(0).toUpperCase()}</div>
						<span>${w.title}</span>
						<button class="ccpb-btn ccpb-btn-icon" data-fav="${w.name}" style="margin-left:auto;font-size:12px">${fav}</button>
					</div>`;
				});
				html += '</div>';
			}
			html += '</div>';
			container.innerHTML = html;
		}

		renderNavigator(tree, depth) {
			let html = '';
			tree.forEach(el => {
				const w = findWidget(el.type);
				const active = el.id === this.selectedId ? ' active' : '';
				const pad = depth * 16;
				html += `<div class="ccpb-nav-item${active}" data-select="${el.id}" style="padding-left:${pad + 8}px">${w?.title || el.type}</div>`;
				if (el.children) html += this.renderNavigator(el.children, depth + 1);
			});
			return html;
		}

		renderCanvas() {
			const canvas = document.getElementById('ccpb-canvas');
			if (!this.document.elements.length) {
				canvas.innerHTML = `<div class="ccpb-drop-zone" data-drop="root">
					<div class="ccpb-empty-state"><h3>Start Building</h3><p>Drag widgets here or click a widget to add</p></div>
				</div>`;
				return;
			}
			canvas.innerHTML = this.renderElements(this.document.elements);
		}

		renderElements(tree) {
			return tree.map(el => this.renderElement(el)).join('');
		}

		renderElement(el) {
			const w = findWidget(el.type);
			const selected = el.id === this.selectedId ? ' selected' : '';
			const hidden = el.hidden ? ' style="opacity:0.3"' : '';
			const locked = el.locked ? ' 🔒' : '';

			let preview = this.renderPreview(el);

			let children = '';
			if (el.children && el.children.length) {
				children = `<div class="ccpb-children">${this.renderElements(el.children)}</div>`;
			} else if (w?.isContainer) {
				children = `<div class="ccpb-drop-zone" data-drop="${el.id}">Drop elements here</div>`;
			}

			return `<div class="ccpb-element-wrap${selected}" data-id="${el.id}" data-type="${el.type}"${hidden}>
				<div class="ccpb-element-actions">
					<button data-action="duplicate-el" data-id="${el.id}">Duplicate</button>
					<button data-action="copy-el" data-id="${el.id}">Copy</button>
					<button data-action="delete-el" data-id="${el.id}">Delete</button>
				</div>
				<div class="ccpb-element-preview">${preview}${locked}</div>
				${children}
			</div>`;
		}

		renderPreview(el) {
			const s = el.settings || {};
			switch (el.type) {
				case 'heading': return `<${s.tag || 'h2'}>${s.text || 'Heading'}</${s.tag || 'h2'}>`;
				case 'text': return `<p>${s.content || 'Text'}</p>`;
				case 'rich-text': return s.content || '';
				case 'button': return `<a class="ccpb-button ccpb-button-primary">${s.text || 'Button'}</a>`;
				case 'image': return s.url ? `<img src="${s.url}" alt="${s.alt || ''}" style="max-width:100%"/>` : '<div style="background:#e2e8f0;height:120px;display:flex;align-items:center;justify-content:center">Image</div>';
				case 'divider': return '<hr/>';
				case 'spacer': return `<div style="height:${s.height || 50}px;background:#f1f5f9"></div>`;
				case 'product-grid': return `<div style="background:#f8fafc;padding:20px;text-align:center;border:1px dashed #cbd5e1;border-radius:8px">Product Grid (${s.columns || 4} cols, ${s.limit || 8} products)</div>`;
				case 'product-slider': return `<div style="background:#f8fafc;padding:20px;text-align:center;border:1px dashed #cbd5e1;border-radius:8px">Product Slider</div>`;
				case 'category-grid': return `<div style="background:#f8fafc;padding:20px;text-align:center;border:1px dashed #cbd5e1;border-radius:8px">Category Grid</div>`;
				case 'mini-cart': return '<div style="padding:8px">🛒 Mini Cart</div>';
				case 'announcement-bar': return `<div class="ccpb-announcement-bar">${s.text || 'Announcement'}</div>`;
				case 'countdown': return `<div style="padding:16px;text-align:center">⏱ Countdown: ${s.label || ''}</div>`;
				case 'newsletter': return `<div style="padding:16px"><strong>${s.title || 'Newsletter'}</strong></div>`;
				case 'trust-badges': return `<div class="ccpb-trust-badges">${(s.badges || []).map(b => `<span class="ccpb-trust-badge">${b}</span>`).join('')}</div>`;
				case 'container': return `<div style="padding:8px;border:1px dashed #94a3b8;border-radius:4px;font-size:12px;color:#64748b">Container (${s.width || 'boxed'})</div>`;
				case 'row': return `<div style="padding:4px;font-size:12px;color:#64748b">Row (${s.columns || 2} columns)</div>`;
				case 'column': return `<div style="padding:4px;font-size:12px;color:#64748b">Column (${s.width || 50}%)</div>`;
				case 'header-builder': return '<header style="padding:16px;background:#1e293b;color:#fff">Header Builder</header>';
				case 'footer-builder': return '<footer style="padding:16px;background:#1e293b;color:#fff">Footer Builder</footer>';
				case 'contact-form': return `<div style="padding:16px;border:1px solid #e2e8f0;border-radius:8px">📋 Contact Form</div>`;
				case 'html': return s.code || '<div>HTML</div>';
				case 'video': return `<div style="background:#000;color:#fff;padding:40px;text-align:center">▶ Video</div>`;
				case 'gallery': return `<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:4px">${[1,2,3].map(()=>'<div style="background:#e2e8f0;aspect-ratio:1"></div>').join('')}</div>`;
				case 'tabs': return `<div style="padding:12px">📑 Tabs (${(s.items||[]).length} items)</div>`;
				case 'accordion': return `<div style="padding:12px">📋 Accordion</div>`;
				default: return `<div style="padding:8px;font-size:12px;color:#64748b">${el.type}</div>`;
			}
		}

		renderRightPanel() {
			const container = document.getElementById('ccpb-right-content');
			const el = this.selectedId ? findElement(this.document.elements, this.selectedId) : null;

			if (!el) {
				container.innerHTML = '<div class="ccpb-control-group"><p style="color:var(--ccpb-muted);padding:16px">Select an element to edit its settings.</p></div>';
				return;
			}

			const w = findWidget(el.type);
			let html = `<div class="ccpb-control-group"><h4>${w?.title || el.type}</h4>`;

			if (this.rightTab === 'settings') {
				html += this.renderSettingsControls(el, w);
			} else if (this.rightTab === 'style') {
				html += this.renderStyleControls(el);
			} else {
				html += this.renderAdvancedControls(el);
			}

			html += '</div>';
			container.innerHTML = html;
		}

		renderSettingsControls(el, widget) {
			let html = '';
			const controls = widget?.controls || [];
			const settings = el.settings || {};

			if (controls.length) {
				controls.forEach(c => {
					html += this.renderControl(c, settings);
				});
			} else {
				Object.entries(settings).forEach(([key, val]) => {
					if (typeof val === 'object') return;
					html += `<div class="ccpb-control"><label>${key}</label>
						<input type="text" data-setting="${key}" value="${val ?? ''}"/></div>`;
				});
			}
			return html;
		}

		renderControl(c, settings) {
			const val = settings[c.name] ?? '';
			let input = '';
			switch (c.type) {
				case 'select':
					input = `<select data-setting="${c.name}">${Object.entries(c.options || {}).map(([k,v]) =>
						`<option value="${k}" ${val === k ? 'selected' : ''}>${v}</option>`).join('')}</select>`;
					break;
				case 'toggle':
					input = `<input type="checkbox" data-setting="${c.name}" ${val ? 'checked' : ''}/>`;
					break;
				case 'number':
					input = `<input type="number" data-setting="${c.name}" value="${val}" min="${c.min||''}" max="${c.max||''}"/>`;
					break;
				case 'textarea':
					input = `<textarea data-setting="${c.name}">${val}</textarea>`;
					break;
				default:
					input = `<input type="text" data-setting="${c.name}" value="${val}"/>`;
			}
			return `<div class="ccpb-control"><label>${c.label || c.name}</label>${input}</div>`;
		}

		renderStyleControls(el) {
			const st = el.styles || {};
			return `
				<div class="ccpb-control"><label>CSS Class</label><input type="text" data-style="cssClasses" value="${st.cssClasses || ''}"/></div>
				<div class="ccpb-control"><label>CSS ID</label><input type="text" data-style="cssId" value="${st.cssId || ''}"/></div>
				<div class="ccpb-control"><label>Custom CSS</label><textarea data-style="customCss">${st.customCss || ''}</textarea></div>
				<div class="ccpb-control"><label>Background Color</label><input type="color" data-style="background.color" value="${st.background?.color || '#ffffff'}"/></div>
				<div class="ccpb-control"><label>Padding Top</label><input type="number" data-style="padding.top" value="${st.padding?.top || ''}"/></div>
				<div class="ccpb-control"><label>Margin Top</label><input type="number" data-style="margin.top" value="${st.margin?.top || ''}"/></div>
				<button class="ccpb-btn" data-action="copy-style" style="margin:12px">Copy Style</button>
				<button class="ccpb-btn" data-action="paste-style" style="margin:12px">Paste Style</button>
			`;
		}

		renderAdvancedControls(el) {
			return `
				<div class="ccpb-control"><label><input type="checkbox" data-advanced="hidden" ${el.hidden ? 'checked' : ''}/> Hide</label></div>
				<div class="ccpb-control"><label><input type="checkbox" data-advanced="disabled" ${el.disabled ? 'checked' : ''}/> Disable</label></div>
				<div class="ccpb-control"><label><input type="checkbox" data-advanced="locked" ${el.locked ? 'checked' : ''}/> Lock</label></div>
				<div class="ccpb-control"><label>Animation</label>
					<select data-style="animation.type">
						<option value="">None</option>
						<option value="fade" ${el.styles?.animation?.type === 'fade' ? 'selected' : ''}>Fade</option>
						<option value="slide-up" ${el.styles?.animation?.type === 'slide-up' ? 'selected' : ''}>Slide Up</option>
						<option value="scale" ${el.styles?.animation?.type === 'scale' ? 'selected' : ''}>Scale</option>
					</select>
				</div>
				<div class="ccpb-control"><label>Hide on Desktop</label><input type="checkbox" data-responsive="desktop.hidden"/></div>
				<div class="ccpb-control"><label>Hide on Tablet</label><input type="checkbox" data-responsive="tablet.hidden"/></div>
				<div class="ccpb-control"><label>Hide on Mobile</label><input type="checkbox" data-responsive="mobile.hidden"/></div>
			`;
		}

		bindEvents() {
			this.root.addEventListener('click', e => this.handleClick(e));
			this.root.addEventListener('input', e => this.handleInput(e));
			this.root.addEventListener('change', e => this.handleInput(e));

			// Drag from widget panel
			this.root.addEventListener('dragstart', e => {
				const item = e.target.closest('[data-widget]');
				if (item) {
					e.dataTransfer.setData('widget', item.dataset.widget);
					e.dataTransfer.effectAllowed = 'copy';
				}
			});

			// Drop zones
			this.root.addEventListener('dragover', e => {
				const zone = e.target.closest('[data-drop]');
				if (zone) { e.preventDefault(); zone.classList.add('drag-over'); }
			});

			this.root.addEventListener('dragleave', e => {
				const zone = e.target.closest('[data-drop]');
				if (zone) zone.classList.remove('drag-over');
			});

			this.root.addEventListener('drop', e => {
				const zone = e.target.closest('[data-drop]');
				if (!zone) return;
				e.preventDefault();
				zone.classList.remove('drag-over');

				const widgetType = e.dataTransfer.getData('widget');
				if (widgetType) {
					this.addElement(widgetType, zone.dataset.drop);
				}
			});
		}

		handleClick(e) {
			const target = e.target;

			// Select element
			const wrap = target.closest('[data-id]');
			if (wrap && !target.closest('.ccpb-element-actions') && !target.closest('button')) {
				this.selectedId = wrap.dataset.id;
				this.renderCanvas();
				this.renderRightPanel();
				if (this.leftTab === 'navigator') this.renderLeftPanel();
				return;
			}

			// Navigator select
			const navItem = target.closest('[data-select]');
			if (navItem) {
				this.selectedId = navItem.dataset.select;
				this.renderCanvas();
				this.renderRightPanel();
				this.renderLeftPanel();
				return;
			}

			// Tabs
			const leftTab = target.closest('[data-left-tab]');
			if (leftTab) { this.leftTab = leftTab.dataset.leftTab; this.renderLeftPanel(); return; }
			const rightTab = target.closest('[data-right-tab]');
			if (rightTab) { this.rightTab = rightTab.dataset.rightTab; this.renderRightPanel(); return; }

			// Device
			const deviceBtn = target.closest('[data-device]');
			if (deviceBtn) {
				this.device = deviceBtn.dataset.device;
				document.getElementById('ccpb-canvas').dataset.device = this.device;
				this.root.querySelectorAll('[data-device]').forEach(b => b.classList.toggle('active', b.dataset.device === this.device));
				return;
			}

			// Actions
			const action = target.closest('[data-action]');
			if (!action) return;

			const act = action.dataset.action;
			const id = action.dataset.id;

			switch (act) {
				case 'undo': this.doUndo(); break;
				case 'redo': this.doRedo(); break;
				case 'save': this.save('draft'); break;
				case 'publish': this.save('publish'); break;
				case 'preview': window.open(config.previewUrl, '_blank'); break;
				case 'toggle-orientation':
					this.orientation = this.orientation === 'portrait' ? 'landscape' : 'portrait';
					document.getElementById('ccpb-canvas').dataset.orientation = this.orientation;
					break;
				case 'duplicate-el': this.duplicateEl(id); break;
				case 'copy-el': this.copyEl(id); break;
				case 'delete-el': this.deleteEl(id); break;
				case 'copy-style': this.copyStyle(); break;
				case 'paste-style': this.pasteStyle(); break;
				case 'templates': this.showTemplates(); break;
				case 'ai': this.showAI(); break;
			}

			// Favorites
			const fav = target.closest('[data-fav]');
			if (fav) {
				const name = fav.dataset.fav;
				const idx = this.favorites.indexOf(name);
				if (idx >= 0) this.favorites.splice(idx, 1);
				else this.favorites.push(name);
				localStorage.setItem('ccpb_favorites', JSON.stringify(this.favorites));
				this.renderLeftPanel();
			}
		}

		handleInput(e) {
			const target = e.target;

			if (target.id === 'ccpb-widget-search') {
				this.searchQuery = target.value;
				this.renderLeftPanel();
				return;
			}

			if (!this.selectedId) return;
			const el = findElement(this.document.elements, this.selectedId);
			if (!el) return;

			if (target.dataset.setting) {
				let val = target.type === 'checkbox' ? target.checked : target.value;
				if (target.type === 'number') val = Number(val);
				el.settings[target.dataset.setting] = val;
			}

			if (target.dataset.style) {
				const parts = target.dataset.style.split('.');
				if (!el.styles) el.styles = {};
				let obj = el.styles;
				for (let i = 0; i < parts.length - 1; i++) {
					if (!obj[parts[i]]) obj[parts[i]] = {};
					obj = obj[parts[i]];
				}
				obj[parts[parts.length - 1]] = target.type === 'checkbox' ? target.checked : target.value;
			}

			if (target.dataset.advanced) {
				el[target.dataset.advanced] = target.checked;
			}

			this.commit();
			this.renderCanvas();
		}

		addElement(type, parentId) {
			const el = createElement(type);
			if (!el) return;

			if (parentId === 'root') {
				this.document.elements.push(el);
			} else {
				const parent = findElement(this.document.elements, parentId);
				if (parent) {
					if (!parent.children) parent.children = [];
					parent.children.push(el);
				}
			}

			this.selectedId = el.id;
			this.commit();
			this.render();
		}

		deleteEl(id) {
			removeElement(this.document.elements, id);
			if (this.selectedId === id) this.selectedId = null;
			this.commit();
			this.render();
		}

		duplicateEl(id) {
			const el = findElement(this.document.elements, id);
			if (!el) return;
			const parent = findParent(this.document.elements, id);
			const copy = duplicateElement(el);
			if (parent && parent.children) {
				const idx = parent.children.findIndex(c => c.id === id);
				parent.children.splice(idx + 1, 0, copy);
			} else {
				const idx = this.document.elements.findIndex(c => c.id === id);
				this.document.elements.splice(idx + 1, 0, copy);
			}
			this.selectedId = copy.id;
			this.commit();
			this.render();
		}

		copyEl(id) {
			const el = findElement(this.document.elements, id);
			if (el) this.clipboard.element = JSON.parse(JSON.stringify(el));
		}

		copyStyle() {
			const el = findElement(this.document.elements, this.selectedId);
			if (el) this.clipboard.styles = JSON.parse(JSON.stringify(el.styles || {}));
		}

		pasteStyle() {
			if (!this.clipboard.styles || !this.selectedId) return;
			const el = findElement(this.document.elements, this.selectedId);
			if (el) {
				el.styles = JSON.parse(JSON.stringify(this.clipboard.styles));
				this.commit();
				this.render();
			}
		}

		commit() {
			this.isDirty = true;
			this.history.push(this.document);
		}

		doUndo() {
			const state = this.history.undo();
			if (state) { this.document = state; this.render(); }
		}

		doRedo() {
			const state = this.history.redo();
			if (state) { this.document = state; this.render(); }
		}

		async save(status) {
			const statusEl = document.getElementById('ccpb-status');
			statusEl.textContent = 'Saving...';
			statusEl.className = 'ccpb-status saving';

			try {
				await api('POST', 'document/' + POST_ID, {
					document: this.document,
					status: status,
					autosave: false,
				});
				this.isDirty = false;
				statusEl.textContent = status === 'publish' ? 'Published!' : 'Saved!';
				statusEl.className = 'ccpb-status saved';
				setTimeout(() => { statusEl.textContent = ''; statusEl.className = 'ccpb-status'; }, 2000);
			} catch (e) {
				statusEl.textContent = 'Save failed';
				statusEl.className = 'ccpb-status';
				console.error(e);
			}
		}

		startAutosave() {
			this.autosaveTimer = setInterval(async () => {
				if (!this.isDirty) return;
				try {
					await api('POST', 'document/' + POST_ID, {
						document: this.document,
						status: 'draft',
						autosave: true,
					});
					this.isDirty = false;
					const statusEl = document.getElementById('ccpb-status');
					if (statusEl) { statusEl.textContent = 'Auto-saved'; statusEl.className = 'ccpb-status saved'; }
				} catch (e) { /* silent */ }
			}, 30000);
		}

		bindKeyboard() {
			document.addEventListener('keydown', e => {
				if (e.ctrlKey || e.metaKey) {
					if (e.key === 'z') { e.preventDefault(); this.doUndo(); }
					if (e.key === 'y') { e.preventDefault(); this.doRedo(); }
					if (e.key === 's') { e.preventDefault(); this.save('draft'); }
					if (e.key === 'c' && this.selectedId) { this.copyEl(this.selectedId); }
					if (e.key === 'v' && this.clipboard.element) { this.pasteElement(); }
					if (e.key === 'd' && this.selectedId) { e.preventDefault(); this.duplicateEl(this.selectedId); }
				}
				if (e.key === 'Delete' && this.selectedId) { this.deleteEl(this.selectedId); }
			});
		}

		pasteElement() {
			if (!this.clipboard.element) return;
			const copy = duplicateElement(this.clipboard.element);
			this.document.elements.push(copy);
			this.selectedId = copy.id;
			this.commit();
			this.render();
		}

		showTemplates() {
			const overlay = document.createElement('div');
			overlay.className = 'ccpb-modal-overlay';
			overlay.innerHTML = `<div class="ccpb-modal">
				<h3>Templates</h3>
				<div style="max-height:300px;overflow-y:auto;margin-bottom:16px">
					${(config.templates || []).map(t => `<div style="padding:8px;border-bottom:1px solid var(--ccpb-border);cursor:pointer" data-template="${t.id}">${t.title} (${t.type})</div>`).join('') || '<p>No templates yet.</p>'}
				</div>
				<button class="ccpb-btn" data-action="save-template">Save Current as Template</button>
				<button class="ccpb-btn" data-action="close-modal" style="margin-left:8px">Close</button>
			</div>`;
			document.body.appendChild(overlay);
			overlay.addEventListener('click', async e => {
				if (e.target.dataset.action === 'close-modal' || e.target === overlay) overlay.remove();
				if (e.target.dataset.action === 'save-template') {
					const title = prompt('Template name:');
					if (title) {
						await api('POST', 'templates', { title, document: this.document, type: 'section' });
						overlay.remove();
					}
				}
			});
		}

		showAI() {
			const overlay = document.createElement('div');
			overlay.className = 'ccpb-modal-overlay';
			overlay.innerHTML = `<div class="ccpb-modal">
				<h3>✨ AI Assistant</h3>
				<div class="ccpb-control"><label>Type</label>
					<select id="ccpb-ai-type">
						<option value="layout">Generate Layout</option>
						<option value="heading">Generate Heading</option>
						<option value="description">Product Description</option>
						<option value="banner">Promo Banner</option>
						<option value="cta">Call to Action</option>
						<option value="palette">Color Palette</option>
					</select>
				</div>
				<div class="ccpb-control"><label>Prompt</label><textarea id="ccpb-ai-prompt" placeholder="Describe what you want..."></textarea></div>
				<button class="ccpb-btn ccpb-btn-primary" id="ccpb-ai-generate">Generate</button>
				<button class="ccpb-btn" data-action="close-modal" style="margin-left:8px">Close</button>
				<div id="ccpb-ai-result" style="margin-top:16px;padding:12px;background:var(--ccpb-bg);border-radius:6px;display:none"></div>
			</div>`;
			document.body.appendChild(overlay);

			overlay.querySelector('#ccpb-ai-generate').addEventListener('click', async () => {
				const type = overlay.querySelector('#ccpb-ai-type').value;
				const prompt = overlay.querySelector('#ccpb-ai-prompt').value;
				const resultEl = overlay.querySelector('#ccpb-ai-result');
				resultEl.style.display = 'block';
				resultEl.textContent = 'Generating...';
				try {
					const res = await api('POST', 'ai/generate', { type, prompt });
					resultEl.textContent = res.result;
					if (type === 'layout') {
						try {
							const layout = JSON.parse(res.result);
							if (Array.isArray(layout)) {
								this.document.elements = [...this.document.elements, ...layout.map(el => ({ ...el, id: generateId() }))];
								this.commit();
								this.render();
							}
						} catch (e) { /* not JSON layout */ }
					}
				} catch (e) {
					resultEl.textContent = 'Generation failed.';
				}
			});

			overlay.addEventListener('click', e => {
				if (e.target.dataset.action === 'close-modal' || e.target === overlay) overlay.remove();
			});
		}
	}

	// ─── Boot ───────────────────────────────────────────────────────
	document.addEventListener('DOMContentLoaded', () => {
		const editor = new CommerceCraftEditor();
		editor.init();
	});
})();
