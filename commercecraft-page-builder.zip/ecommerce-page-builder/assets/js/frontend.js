/**
 * CommerceCraft Frontend Scripts
 */
(function () {
	'use strict';

	// Tabs
	document.querySelectorAll('[data-ccpb-tabs]').forEach(tabs => {
		const btns = tabs.querySelectorAll('.ccpb-tab-btn');
		const panels = tabs.querySelectorAll('.ccpb-tab-panel');
		btns.forEach(btn => {
			btn.addEventListener('click', () => {
				const idx = btn.dataset.tab;
				btns.forEach(b => b.classList.remove('active'));
				panels.forEach(p => p.classList.remove('active'));
				btn.classList.add('active');
				tabs.querySelector(`[data-panel="${idx}"]`)?.classList.add('active');
			});
		});
	});

	// Countdown
	document.querySelectorAll('[data-ccpb-countdown]').forEach(el => {
		const target = new Date(el.dataset.target).getTime();
		const timer = el.querySelector('.ccpb-countdown-timer');
		if (!timer || isNaN(target)) return;

		const tick = () => {
			const diff = target - Date.now();
			if (diff <= 0) { timer.textContent = '00:00:00'; return; }
			const d = Math.floor(diff / 86400000);
			const h = Math.floor((diff % 86400000) / 3600000);
			const m = Math.floor((diff % 3600000) / 60000);
			const s = Math.floor((diff % 60000) / 1000);
			timer.textContent = `${d}d ${h}h ${m}m ${s}s`;
		};
		tick();
		setInterval(tick, 1000);
	});

	// Product slider
	document.querySelectorAll('[data-ccpb-slider]').forEach(slider => {
		const grid = slider.querySelector('.ccpb-product-grid');
		if (!grid) return;
		grid.style.display = 'flex';
		grid.style.overflowX = 'auto';
		grid.style.scrollSnapType = 'x mandatory';
		grid.querySelectorAll('.ccpb-product-card').forEach(card => {
			card.style.flex = '0 0 250px';
			card.style.scrollSnapAlign = 'start';
		});
	});

	// Announcement dismiss
	document.querySelectorAll('.ccpb-announcement-bar .ccpb-dismiss').forEach(btn => {
		btn.addEventListener('click', () => {
			btn.closest('.ccpb-announcement-bar')?.remove();
		});
	});

	// Scroll animations
	const observer = new IntersectionObserver(entries => {
		entries.forEach(entry => {
			if (entry.isIntersecting) {
				entry.target.classList.add('ccpb-animated');
			}
		});
	}, { threshold: 0.1 });

	document.querySelectorAll('[data-ccpb-animate]').forEach(el => observer.observe(el));

	// Exit intent
	let exitShown = false;
	document.addEventListener('mouseout', e => {
		if (exitShown || e.clientY > 10) return;
		document.querySelectorAll('[data-ccpb-exit-intent], .ccpb-popup[data-trigger="exit"]').forEach(el => {
			el.style.display = 'block';
			exitShown = true;
		});
	});

	// Popups
	document.querySelectorAll('.ccpb-popup').forEach(popup => {
		const trigger = popup.dataset.trigger || 'load';
		const delay = parseInt(popup.dataset.delay, 10) || 0;
		const scrollPct = parseInt(popup.dataset.scroll, 10) || 50;

		const show = () => { popup.style.display = 'block'; };
		const hide = () => { popup.style.display = 'none'; };

		popup.querySelector('.ccpb-popup-close')?.addEventListener('click', hide);
		popup.querySelector('.ccpb-popup-overlay')?.addEventListener('click', hide);

		if (trigger === 'load') setTimeout(show, delay * 1000);
		if (trigger === 'scroll') {
			window.addEventListener('scroll', () => {
				const pct = (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100;
				if (pct >= scrollPct) show();
			}, { passive: true });
		}
	});

	// Counter animation
	document.querySelectorAll('[data-ccpb-counter]').forEach(el => {
		const target = parseInt(el.dataset.target, 10);
		const numEl = el.querySelector('.ccpb-counter-number');
		if (!numEl) return;
		const obs = new IntersectionObserver(entries => {
			if (!entries[0].isIntersecting) return;
			let current = 0;
			const step = Math.ceil(target / 60);
			const timer = setInterval(() => {
				current += step;
				if (current >= target) { current = target; clearInterval(timer); }
				numEl.textContent = current.toLocaleString();
			}, 20);
			obs.disconnect();
		}, { threshold: 0.5 });
		obs.observe(el);
	});

	// Cart drawer toggle
	document.querySelectorAll('[data-ccpb-cart-drawer]').forEach(drawer => {
		drawer.querySelector('.ccpb-cart-drawer-toggle')?.addEventListener('click', () => {
			drawer.classList.toggle('open');
		});
	});
})();
