const path = require('path');

module.exports = {
	entry: {
		editor: './src/editor/index.jsx',
	},
	output: {
		path: path.resolve(__dirname, 'assets/js'),
		filename: '[name].bundle.js',
	},
	module: {
		rules: [
			{
				test: /\.jsx?$/,
				exclude: /node_modules/,
				use: { loader: 'babel-loader', options: { presets: ['@babel/preset-env', '@babel/preset-react'] } },
			},
		],
	},
	resolve: { extensions: ['.js', '.jsx'] },
	externals: { react: 'React', 'react-dom': 'ReactDOM' },
};
