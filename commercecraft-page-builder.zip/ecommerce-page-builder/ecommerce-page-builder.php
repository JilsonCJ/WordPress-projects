<?php
/**
 * Plugin Name:       CommerceCraft Page Builder
 * Plugin URI:        https://example.com/commercecraft
 * Description:       Professional visual drag-and-drop page builder designed specifically for eCommerce stores. No Elementor, Gutenberg, or third-party builder required.
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Author:            CommerceCraft
 * Author URI:        https://example.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       commercecraft
 * Domain Path:       /languages
 *
 * @package CommerceCraft
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CCPB_VERSION', '1.0.0' );
define( 'CCPB_PLUGIN_FILE', __FILE__ );
define( 'CCPB_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CCPB_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CCPB_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'CCPB_MIN_PHP', '8.1' );
define( 'CCPB_MIN_WP', '6.4' );

if ( version_compare( PHP_VERSION, CCPB_MIN_PHP, '<' ) ) {
	add_action(
		'admin_notices',
		static function (): void {
			echo '<div class="notice notice-error"><p>';
			printf(
				/* translators: %s: minimum PHP version */
				esc_html__( 'CommerceCraft Page Builder requires PHP %s or higher.', 'commercecraft' ),
				esc_html( CCPB_MIN_PHP )
			);
			echo '</p></div>';
		}
	);
	return;
}

require_once CCPB_PLUGIN_DIR . 'includes/class-autoloader.php';

CommerceCraft\Autoloader::register( 'CommerceCraft', CCPB_PLUGIN_DIR . 'includes' );

/**
 * Returns the main plugin instance.
 *
 * @return CommerceCraft\Plugin
 */
function ccpb(): CommerceCraft\Plugin {
	return CommerceCraft\Plugin::instance();
}

register_activation_hook( __FILE__, array( CommerceCraft\Plugin::class, 'activate' ) );
register_deactivation_hook( __FILE__, array( CommerceCraft\Plugin::class, 'deactivate' ) );

ccpb()->init();
